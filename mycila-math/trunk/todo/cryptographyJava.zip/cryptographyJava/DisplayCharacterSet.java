public class DisplayCharacterSet {
   public static void main(String[] args) {
      for (int i=0;i<256;i++) System.out.print(i+" "+(char)i+"\t-");
   }
}
