public class MatricesNonConformableException extends Exception {
  public MatricesNonConformableException() {super();}
  public MatricesNonConformableException(String s) {super(s);}
}
