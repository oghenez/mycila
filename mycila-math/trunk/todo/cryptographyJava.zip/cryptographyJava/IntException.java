public class IntException extends Exception {
   public IntException() {super();}
   public IntException(String s) {super(s);}
}
