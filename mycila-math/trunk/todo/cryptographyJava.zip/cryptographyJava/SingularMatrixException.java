public class SingularMatrixException extends Exception {
  public SingularMatrixException() {super();}
  public SingularMatrixException(String s) {super(s);}
}
