import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

class FontAdjuster
{
  public static Font AdjustFontV(Graphics paramGraphics, Font paramFont, int paramInt)
  {
    while (true)
    {
      FontMetrics localFontMetrics = paramGraphics.getFontMetrics(paramFont);
      int i = localFontMetrics.getAscent();
      if (i < paramInt)
        break;
      int j = ((paramFont.isBold()) ? 1 : 0) + ((paramFont.isItalic()) ? 2 : 0);
      String str = paramFont.getFamily();
      int k = paramFont.getSize();
      paramFont = new Font(str, j, k - 1);
    }
    return paramFont;
  }

  public static Font AdjustFontH(Graphics paramGraphics, Font paramFont, int paramInt, String paramString)
  {
    while (true)
    {
      FontMetrics localFontMetrics = paramGraphics.getFontMetrics(paramFont);
      int i = localFontMetrics.stringWidth(paramString);
      if (i < paramInt)
        break;
      int j = ((paramFont.isBold()) ? 1 : 0) + ((paramFont.isItalic()) ? 2 : 0);
      String str = paramFont.getFamily();
      int k = paramFont.getSize();
      paramFont = new Font(str, j, k - 1);
    }
    return paramFont;
  }
}