import java.awt.Canvas;
import java.awt.Component;

class CTKWinker extends Thread
{
  boolean m_bWink = false;
  Canvas m_Owner;
  mouseTracker m_Eyes;
  int m_Timer = 10000;

  public CTKWinker(Canvas paramCanvas, mouseTracker parammouseTracker)
  {
    this.m_Owner = paramCanvas;
    this.m_Eyes = parammouseTracker;
  }

  public void run()
  {
    try
    {
      Thread.sleep(this.m_Timer);
      if (this.m_bWink)
        this.m_Timer = ((int)(Math.random() * 5000.0D) + 5000);
      else
        this.m_Timer = 1000;
      this.m_Eyes.SetFullEye(this.m_bWink);
      this.m_bWink = (!(this.m_bWink));
      this.m_Owner.repaint();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }
}