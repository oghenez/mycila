import java.awt.AWTEventMulticaster;
import java.awt.Component;
import java.awt.Container;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.util.Hashtable;
import java.util.Vector;

class CTKGroup extends Panel
{
  String m_Selection = null;
  Hashtable m_List;
  Vector m_IndexToName;
  CTKGroupEventListener m_Listener;

  public CTKGroup()
  {
    Init();
  }

  public CTKGroup(LayoutManager paramLayoutManager)
  {
    super(paramLayoutManager);
    Init();
  }

  public void Init()
  {
    this.m_List = new Hashtable();
    this.m_IndexToName = new Vector();
    this.m_Listener = null;
  }

  public void Add(CTKGroupElement paramCTKGroupElement)
  {
    paramCTKGroupElement.SetGroup(this);
    add((Component)paramCTKGroupElement);
    this.m_List.put(paramCTKGroupElement.GetName(), paramCTKGroupElement);
    this.m_IndexToName.addElement(paramCTKGroupElement.GetName());
  }

  public void Select(String paramString)
  {
    Select(paramString, true);
  }

  public void Select(int paramInt)
  {
    Component localComponent = getComponent(paramInt);
    if ((localComponent != null) && (localComponent instanceof CTKGroupElement))
      Select((String)this.m_IndexToName.elementAt(paramInt), true);
  }

  public void Select(String paramString, boolean paramBoolean)
  {
    CTKGroupElement localCTKGroupElement;
    if (this.m_Selection != null)
    {
      localCTKGroupElement = (CTKGroupElement)this.m_List.get(this.m_Selection);
      localCTKGroupElement.Unselect();
      localCTKGroupElement.repaint();
    }
    this.m_Selection = new String(paramString);
    if (this.m_Selection != null)
    {
      localCTKGroupElement = (CTKGroupElement)this.m_List.get(this.m_Selection);
      localCTKGroupElement.Select();
      localCTKGroupElement.repaint();
    }
    if ((paramBoolean) && (this.m_Listener != null))
      this.m_Listener.actionPerformed(new CTKGroupEvent(this, 1001, this.m_Selection));
  }

  public String GetSelection()
  {
    return this.m_Selection;
  }

  protected void finalize()
    throws Throwable
  {
    this.m_Listener = null;
    finalize();
  }

  public synchronized void addActionListener(CTKGroupEventListener paramCTKGroupEventListener)
  {
    if (this.m_Listener != null)
      removeActionListener(this.m_Listener);
    this.m_Listener = ((CTKGroupEventListener)AWTEventMulticaster.add(this.m_Listener, paramCTKGroupEventListener));
  }

  public synchronized void removeActionListener(CTKGroupEventListener paramCTKGroupEventListener)
  {
    this.m_Listener = ((CTKGroupEventListener)AWTEventMulticaster.remove(this.m_Listener, paramCTKGroupEventListener));
  }
}