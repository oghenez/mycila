import java.awt.event.ActionEvent;

public class EndActionEvent extends ActionEvent
{
  public EndActionEvent(Object paramObject, int paramInt, String paramString)
  {
    super(paramObject, paramInt, paramString);
  }

  public EndActionEvent(Object paramObject, int paramInt1, String paramString, int paramInt2)
  {
    super(paramObject, paramInt1, paramString, paramInt2);
  }
}