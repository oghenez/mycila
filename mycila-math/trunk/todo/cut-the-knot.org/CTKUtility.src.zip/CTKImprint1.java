import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.EventObject;

class CTKImprint1 extends Panel
  implements MouseListener
{
  private Font m_CFont;
  private Applet m_Applet;
  private Dimension m_Size = new Dimension(100, 10);
  boolean ReportCopy;
  String Copy = "Copyright CTK Software. All rights reserved.";
  private static final String ctkCom = "cut-the-knot.com";
  private static final String ctkOrg = "cut-the-knot.org";
  private static final String kids = "ctkmathgamesforkids.com";
  private static final String[] Domains = { "cut-the-knot.com", "cut-the-knot.org", "ctkmathgamesforkids.com" };

  public CTKImprint1(Applet paramApplet)
  {
    this.m_Applet = paramApplet;
    try
    {
      setBackground(this.m_Applet.getBackground());
      setForeground(this.m_Applet.getForeground());
    }
    catch (Exception localException1)
    {
      setBackground(Color.white);
      setForeground(Color.black);
    }
    int i = GetDocDomain();
    int j = GetCodeDomain();
    if (i == j)
      if ((i == -1) || (i == 0))
        this.ReportCopy = true;
    else
      try
      {
        this.m_Applet.getAppletContext().showDocument(new URL("http://www.cut-the-knot.org/Terms.shtml"));
      }
      catch (Exception localException2)
      {
        return;
      }
    this.m_CFont = new Font("Serif", 0, 9);
    addMouseListener(this);
  }

  private int GetDocDomain()
  {
    URL localURL = this.m_Applet.getDocumentBase();
    return ((localURL.getProtocol().equals("file")) ? 0 : GetDomain(localURL.toString()));
  }

  private int GetCodeDomain()
  {
    URL localURL = this.m_Applet.getCodeBase();
    return ((localURL.getProtocol().equals("file")) ? 0 : GetDomain(localURL.toString()));
  }

  private int GetDomain(String paramString)
  {
    if (paramString == null)
      return -1;
    for (int i = 0; i < Domains.length; ++i)
      if (paramString.indexOf(Domains[i]) != -1)
        return (i + 1);
    return 0;
  }

  public void paint(Graphics paramGraphics)
  {
    update(paramGraphics);
  }

  public void update(Graphics paramGraphics)
  {
    if (this.ReportCopy)
    {
      paramGraphics.setFont(this.m_CFont);
      Dimension localDimension = getSize();
      paramGraphics.setColor(getBackground());
      paramGraphics.fillRect(0, 0, localDimension.width, localDimension.height);
      paramGraphics.setColor(getForeground());
      paramGraphics.drawString(this.Copy, 5, localDimension.height - 1);
    }
  }

  public Dimension getPreferredSize()
  {
    return this.m_Size;
  }

  public Dimension getMinimumSize()
  {
    return this.m_Size;
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    URL localURL;
    try
    {
      localURL = new URL("http://www.cut-the-knot.org/index.shtml");
      this.m_Applet.getAppletContext().showDocument(localURL, "_top");
    }
    catch (MalformedURLException localMalformedURLException)
    {
      this.m_Applet.showStatus("http://www.cut-the-knot.org/index.shtml");
    }
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }

  class GPanel extends Panel
  {
    private final CTKImprint1 this$0;

    public GPanel()
    {
      this.this$0 = paramCTKImprint1;
    }

    public void paint()
    {
      Dimension localDimension = getSize();
      paramGraphics.setColor(Color.black);
      paramGraphics.drawRect(0, 0, localDimension.width - 1, localDimension.height - 1);
      paramGraphics.setFont(new Font("Verdana", 1, 17));
      FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
      int i = localFontMetrics.getAscent();
      int j = (localDimension.height - 3 * i) / 3 + i;
      String str = "Please get Java 1.5 or better.";
      paramGraphics.drawString(str, (localDimension.width - localFontMetrics.stringWidth(str)) / 2, j);
      j += i;
      str = "Check software downloads at";
      paramGraphics.drawString(str, (localDimension.width - localFontMetrics.stringWidth(str)) / 2, j);
      j += i;
      str = "http://www.java.com";
      paramGraphics.drawString(str, (localDimension.width - localFontMetrics.stringWidth(str)) / 2, j);
    }
  }

  class JavaAlert extends Dialog
  implements ActionListener
  {
    private final CTKImprint1 this$0;

    public JavaAlert()
    {
      super(new Frame(), true);
      this.this$0 = paramCTKImprint1;
      super.setTitle("Java Version Alert!");
      setLayout(new BorderLayout(0, 0));
      Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
      int i = 400;
      int j = 180;
      setLocation((localDimension.width - i) / 2, (localDimension.height - j) / 2);
      setSize(i, j);
      add(new CTKImprint1.GPanel(paramCTKImprint1));
      Panel localPanel = new Panel(new FlowLayout(2, 0, 2));
      add(localPanel, "South");
      Button localButton = new Button("Close");
      localPanel.add(localButton);
      localButton.addActionListener(this);
    }

    public void actionPerformed()
    {
      Object localObject = paramActionEvent.getSource();
      ((Dialog)((Panel)((Button)localObject).getParent()).getParent()).dispose();
    }
  }
}