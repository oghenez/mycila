import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public abstract interface EndActionListener extends ActionListener
{
  public abstract void actionPerformed(ActionEvent paramActionEvent);
}