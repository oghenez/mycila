import java.awt.event.ActionListener;

public abstract interface CTKGroupEventListener extends ActionListener
{
  public abstract void actionPerformed(CTKGroupEvent paramCTKGroupEvent);
}