import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

class mouseTracker
{
  private Graphics m_Graphics;
  private Rectangle m_Position;
  private Point m_Mouse;
  private int m_dEyeRadius;
  private int m_dIrisRadius;
  private Point m_EyeCenterL;
  private Point m_EyeCenterR;
  private boolean m_bFullEye;
  private CTKWinker m_Winker = null;

  public mouseTracker(Graphics paramGraphics, Rectangle paramRectangle)
  {
    this.m_Graphics = paramGraphics;
    this.m_Position = paramRectangle;
    this.m_dEyeRadius = (Math.min(this.m_Position.width, this.m_Position.height) / 2);
    this.m_dIrisRadius = (this.m_dEyeRadius / 2);
    this.m_EyeCenterL = new Point(this.m_Position.x + this.m_dEyeRadius, this.m_Position.y + this.m_dEyeRadius);
    this.m_EyeCenterR = new Point(this.m_Position.x + this.m_Position.width - this.m_dEyeRadius, this.m_Position.y + this.m_dEyeRadius);
    this.m_Mouse = new Point(0, 0);
    this.m_bFullEye = false;
  }

  public void move(Point paramPoint)
  {
    this.m_Mouse = paramPoint;
  }

  public void draw()
  {
    drawEye(this.m_EyeCenterL);
    drawEye(this.m_EyeCenterR);
  }

  void drawEye(Point paramPoint)
  {
    Point localPoint1 = new Point(this.m_Mouse.x - paramPoint.x, this.m_Mouse.y - paramPoint.y);
    double d1 = Math.sqrt(localPoint1.x * localPoint1.x + localPoint1.y * localPoint1.y);
    double d2 = localPoint1.x / d1;
    double d3 = localPoint1.y / d1;
    Point localPoint2 = new Point(paramPoint.x + (int)(d2 * (this.m_dEyeRadius - this.m_dIrisRadius)), paramPoint.y + (int)(d3 * (this.m_dEyeRadius - this.m_dIrisRadius)));
    if (this.m_bFullEye)
      localPoint2 = paramPoint;
    this.m_Graphics.setColor(Color.white);
    if (this.m_bFullEye)
      this.m_Graphics.fillOval(paramPoint.x - this.m_dEyeRadius, paramPoint.y - this.m_dEyeRadius, this.m_dEyeRadius * 2, this.m_dEyeRadius * 2);
    else
      this.m_Graphics.fillArc(paramPoint.x - this.m_dEyeRadius, paramPoint.y - this.m_dEyeRadius, this.m_dEyeRadius * 2, this.m_dEyeRadius * 2, 180, 180);
    this.m_Graphics.setColor(Color.blue);
    this.m_Graphics.fillOval(localPoint2.x - this.m_dIrisRadius, localPoint2.y - this.m_dIrisRadius, this.m_dIrisRadius * 2, this.m_dIrisRadius * 2);
    this.m_Graphics.setColor(Color.black);
    this.m_Graphics.fillOval(localPoint2.x - 2, localPoint2.y - 2, 4, 4);
    this.m_Graphics.setColor(Color.gray);
    if (!(this.m_bFullEye))
      this.m_Graphics.fillArc(paramPoint.x - this.m_dEyeRadius, paramPoint.y - this.m_dEyeRadius, this.m_dEyeRadius * 2, this.m_dEyeRadius * 2, 0, 180);
    this.m_Graphics.setColor(Color.black);
    this.m_Graphics.drawOval(paramPoint.x - this.m_dEyeRadius, paramPoint.y - this.m_dEyeRadius, this.m_dEyeRadius * 2, this.m_dEyeRadius * 2);
  }

  synchronized void SetFullEye(boolean paramBoolean)
  {
    this.m_bFullEye = paramBoolean;
  }

  public synchronized void StartWinking(Canvas paramCanvas)
  {
    this.m_Winker = new CTKWinker(paramCanvas, this);
    if (this.m_Winker != null)
      this.m_Winker.start();
  }

  public synchronized void StopWinking()
  {
    if (this.m_Winker != null)
      this.m_Winker = null;
  }
}