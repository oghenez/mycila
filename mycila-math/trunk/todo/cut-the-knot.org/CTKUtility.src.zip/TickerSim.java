import java.awt.AWTEventMulticaster;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;

class TickerSim extends Canvas
  implements Runnable
{
  Thread MyThread;
  int N;
  boolean Running = false;
  Color FColor;
  static Dimension Dim = new Dimension(200, 20);
  int R;
  int I;
  int DX;
  Font mFont;
  Image mImage;
  String Caption;
  static final String GO = "Go";
  static final String FOO = "Illegal Move";
  static final String IWON = "I won";
  static final String YWON = "You won";
  static final String STOP = "Stop";
  String Action = "Go";
  EndActionListener m_Listener;

  public Dimension getMinimumSize()
  {
    return Dim;
  }

  public Dimension getPreferredSize()
  {
    return Dim;
  }

  public void SetCaption(String paramString)
  {
    this.Caption = paramString;
  }

  public void SetAction(String paramString)
  {
    this.Action = paramString;
    if (this.Action.equals("Stop"))
    {
      this.Running = false;
      this.I = (this.N + 1);
    }
  }

  public TickerSim(Color paramColor)
  {
    this.FColor = paramColor;
    this.R = 8;
    this.N = 5;
    this.I = (this.N + 1);
  }

  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }

  public void paint(Graphics paramGraphics)
  {
    if (this.mImage == null)
    {
      Dimension localDimension = getSize();
      this.mImage = createImage(localDimension.width, localDimension.height);
      this.mFont = new Font("Serif", 1, 20);
    }
    Draw(this.mImage.getGraphics());
    paramGraphics.drawImage(this.mImage, 0, 0, null);
  }

  private void Draw(Graphics paramGraphics)
  {
    paramGraphics.setFont(this.mFont);
    Dimension localDimension = getSize();
    paramGraphics.setColor(Color.green.darker());
    paramGraphics.fillRect(0, 0, localDimension.width, localDimension.height);
    paramGraphics.setColor(Color.black);
    paramGraphics.drawRect(0, -1, localDimension.width - 1, localDimension.height);
    if (this.Running)
      if (this.I <= this.N)
      {
        FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
        int i = localFontMetrics.stringWidth(this.Caption);
        int j = localFontMetrics.getAscent() - localFontMetrics.getDescent();
        int k = 3;
        this.R = (localDimension.height / 2 - k);
        int l = 2 * this.DX / 3;
        int i1 = 2 * this.R;
        int i2 = this.DX / 2;
        for (int i3 = 0; i3 < this.I; ++i3)
        {
          int i4 = this.DX * i3;
          paramGraphics.setColor(this.FColor);
          paramGraphics.fillRect(i4 + i2, k, l, i1);
          paramGraphics.setColor(Color.black);
          paramGraphics.drawRect(i4 + i2, k, l, i1);
        }
        paramGraphics.setColor(Color.black);
        paramGraphics.drawString(this.Caption, (localDimension.width - i) / 2 - 1, (localDimension.height + j) / 2 - 1);
        paramGraphics.setColor(Color.yellow);
        paramGraphics.drawString(this.Caption, (localDimension.width - i) / 2, (localDimension.height + j) / 2);
        this.I += 1;
      }
      else if (this.I > this.N)
      {
        this.Running = false;
        if (this.m_Listener != null)
          this.m_Listener.actionPerformed(new ActionEvent(this, 1, this.Action));
      }
  }

  public void Start()
  {
    Dimension localDimension = getSize();
    this.DX = 10;
    this.N = (localDimension.width / this.DX);
    this.I = 0;
    this.Running = true;
    this.MyThread = new Thread(this);
    this.MyThread.start();
  }

  public void run()
  {
    label0: if (this.Running);
    try
    {
      repaint();
      Thread.sleep(50L);
    }
    catch (Exception localException)
    {
      break label0:
      repaint();
    }
  }

  public synchronized void addActionListener(EndActionListener paramEndActionListener)
  {
    if (this.m_Listener != null)
      removeActionListener(this.m_Listener);
    this.m_Listener = ((EndActionListener)AWTEventMulticaster.add(this.m_Listener, paramEndActionListener));
  }

  public synchronized void removeActionListener(EndActionListener paramEndActionListener)
  {
    this.m_Listener = ((EndActionListener)AWTEventMulticaster.remove(this.m_Listener, paramEndActionListener));
  }
}