abstract interface CTKGroupElement
{
  public abstract String GetName();

  public abstract void Select();

  public abstract void Unselect();

  public abstract void repaint();

  public abstract void SetGroup(CTKGroup paramCTKGroup);

  public abstract void Reset();
}