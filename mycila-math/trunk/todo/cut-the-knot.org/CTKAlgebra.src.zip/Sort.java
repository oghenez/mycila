class Sort
{
  public static int[] SortIt(int[] paramArrayOfInt)
  {
    int[] arrayOfInt = new int[paramArrayOfInt.length];
    for (int i = 0; i < paramArrayOfInt.length; ++i)
      arrayOfInt[i] = paramArrayOfInt[i];
    QuickSort(arrayOfInt, 0, paramArrayOfInt.length - 1);
    return arrayOfInt;
  }

  public static double[] SortIt(double[] paramArrayOfDouble)
  {
    double[] arrayOfDouble = new double[paramArrayOfDouble.length];
    for (int i = 0; i < paramArrayOfDouble.length; ++i)
      arrayOfDouble[i] = paramArrayOfDouble[i];
    QuickSort(arrayOfDouble, 0, paramArrayOfDouble.length - 1);
    return arrayOfDouble;
  }

  public static void QuickSort(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    int j = paramInt2;
    if (paramInt2 > paramInt1)
    {
      int k = paramArrayOfInt[((paramInt1 + paramInt2) / 2)];
      while (true)
      {
        do
        {
          if (i > j)
            break label87;
          while ((i < paramInt2) && (paramArrayOfInt[i] < k))
            ++i;
          while ((j > paramInt1) && (paramArrayOfInt[j] > k))
            --j;
        }
        while (i > j);
        swap(paramArrayOfInt, i, j);
        ++i;
        --j;
      }
      if (paramInt1 < j)
        label87: QuickSort(paramArrayOfInt, paramInt1, j);
      if (i < paramInt2)
        QuickSort(paramArrayOfInt, i, paramInt2);
    }
  }

  public static void QuickSort(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    int j = paramInt2;
    if (paramInt2 > paramInt1)
    {
      double d = paramArrayOfDouble[((paramInt1 + paramInt2) / 2)];
      while (true)
      {
        do
        {
          if (i > j)
            break label89;
          while ((i < paramInt2) && (paramArrayOfDouble[i] < d))
            ++i;
          while ((j > paramInt1) && (paramArrayOfDouble[j] > d))
            --j;
        }
        while (i > j);
        swap(paramArrayOfDouble, i, j);
        ++i;
        --j;
      }
      if (paramInt1 < j)
        label89: QuickSort(paramArrayOfDouble, paramInt1, j);
      if (i < paramInt2)
        QuickSort(paramArrayOfDouble, i, paramInt2);
    }
  }

  private static void swap(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i = paramArrayOfInt[paramInt1];
    paramArrayOfInt[paramInt1] = paramArrayOfInt[paramInt2];
    paramArrayOfInt[paramInt2] = i;
  }

  private static void swap(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
  {
    double d = paramArrayOfDouble[paramInt1];
    paramArrayOfDouble[paramInt1] = paramArrayOfDouble[paramInt2];
    paramArrayOfDouble[paramInt2] = d;
  }
}