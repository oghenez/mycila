import java.awt.Event;

public class NumberChangeEvent extends Event
{
  public NumberChangeEvent(Object paramObject1, int paramInt, Object paramObject2)
  {
    super(paramObject1, paramInt, paramObject2);
  }
}