import java.util.Vector;

class SortedVectorCI extends Vector
{
  private boolean m_bSkipFirst;

  public SortedVectorCI(boolean paramBoolean)
  {
    this.m_bSkipFirst = paramBoolean;
  }

  public SortedVectorCI()
  {
    this.m_bSkipFirst = false;
  }

  public SortedVectorCI(int paramInt)
  {
    super(paramInt);
    this.m_bSkipFirst = false;
  }

  public void addElement(CompareInterface paramCompareInterface)
  {
    int i = super.size();
    for (int j = (this.m_bSkipFirst) ? 1 : 0; j < i; ++j)
    {
      CompareInterface localCompareInterface = (CompareInterface)super.elementAt(j);
      if (paramCompareInterface.Compare(localCompareInterface))
      {
        super.insertElementAt(paramCompareInterface, j);
        return;
      }
    }
    super.addElement(paramCompareInterface);
  }

  public void AddUniqueReverse(CompareInterface paramCompareInterface)
  {
    int i = super.size();
    for (int j = (this.m_bSkipFirst) ? 1 : 0; j < i; ++j)
    {
      CompareInterface localCompareInterface = (CompareInterface)super.elementAt(j);
      if (paramCompareInterface.Equals(localCompareInterface))
        return;
      if (!(paramCompareInterface.Compare(localCompareInterface)))
      {
        super.insertElementAt(paramCompareInterface, j);
        return;
      }
    }
    super.addElement(paramCompareInterface);
  }

  public CompareInterface RouletteSelect()
  {
    float f1 = 0F;
    int i = super.size();
    for (int j = 0; j < i; ++j)
      f1 += ((CompareInterface)super.elementAt(j)).GetValue();
    float f2 = (float)(Math.random() * f1);
    float f3 = 0F;
    for (int k = 0; k < i; ++k)
    {
      f3 += ((CompareInterface)super.elementAt(k)).GetValue();
      if (f2 < f3)
        return ((CompareInterface)super.elementAt(k));
    }
    return ((CompareInterface)null);
  }

  public CompareInterface RouletteSelectOtherThan(CompareInterface paramCompareInterface)
  {
    for (CompareInterface localCompareInterface = RouletteSelect(); (localCompareInterface == paramCompareInterface) && (localCompareInterface != null); localCompareInterface = RouletteSelect());
    return localCompareInterface;
  }
}