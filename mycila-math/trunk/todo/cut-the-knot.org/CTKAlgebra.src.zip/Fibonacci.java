import java.util.Vector;

class Fibonacci
{
  static Vector number = new Vector();

  public static int GetNum(int paramInt)
  {
    int i = number.size();
    if (paramInt < i)
      return ((Integer)number.elementAt(paramInt)).intValue();
    for (int j = i; j <= paramInt; ++j)
    {
      int k = ((Integer)number.elementAt(j - 2)).intValue();
      int l = ((Integer)number.elementAt(j - 1)).intValue();
      number.addElement(new Integer(k + l));
    }
    return ((Integer)number.elementAt(paramInt)).intValue();
  }

  static
  {
    number.addElement(new Integer(1));
    number.addElement(new Integer(1));
  }
}