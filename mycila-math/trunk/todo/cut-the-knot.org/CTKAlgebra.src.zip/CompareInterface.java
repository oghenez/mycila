abstract interface CompareInterface
{
  public abstract boolean Compare(CompareInterface paramCompareInterface);

  public abstract boolean Equals(CompareInterface paramCompareInterface);

  public abstract float GetValue();

  public abstract float Swap(CompareInterface paramCompareInterface);
}