import java.awt.Canvas;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Vector;

class IntegerString
{
  Vector Nums = new Vector();
  int CurrentIndex = -1;
  int Base = 10;
  boolean Connected = true;

  public int GetBase()
  {
    return this.Base;
  }

  public void SetBase(int paramInt)
  {
    this.Base = paramInt;
  }

  public void SetConnected(boolean paramBoolean)
  {
    this.Connected = paramBoolean;
  }

  public IntegerString(long paramLong, int paramInt)
  {
    this.Base = paramInt;
    Init(paramLong);
  }

  public IntegerString(long paramLong)
  {
    Init(paramLong);
  }

  private void Init(long paramLong)
  {
    Canvas localCanvas = new Canvas();
    while (paramLong > -4584371744411746304L)
    {
      int i = (int)(paramLong % this.Base);
      CTKNumberMod localCTKNumberMod = new CTKNumberMod(localCanvas, i);
      localCTKNumberMod.SetModulo(this.Base);
      this.Nums.addElement(localCTKNumberMod);
      paramLong /= this.Base;
    }
  }

  public IntegerString(String paramString)
  {
    Init(paramString);
  }

  public IntegerString(String paramString, int paramInt)
  {
    this.Base = paramInt;
    Init(paramString);
  }

  private void Init(String paramString)
  {
    Canvas localCanvas = new Canvas();
    BaseSys localBaseSys = new BaseSys(this.Base);
    for (int i = paramString.length() - 1; i >= 0; --i)
    {
      String str = paramString.substring(i, i + 1).toUpperCase();
      int j = localBaseSys.Check(str, this.Base);
      if (j == -1)
        j = 0;
      CTKNumberMod localCTKNumberMod = new CTKNumberMod(localCanvas, j);
      localCTKNumberMod.SetModulo(this.Base);
      this.Nums.addElement(localCTKNumberMod);
    }
  }

  public int Length()
  {
    return this.Nums.size();
  }

  public void Add(CTKNumber paramCTKNumber)
  {
    this.Nums.addElement(paramCTKNumber);
  }

  public void Clear()
  {
    this.Nums.removeAllElements();
  }

  public int Update()
  {
    int l;
    CTKNumber localCTKNumber2;
    int i1;
    if (this.CurrentIndex == -1)
      return -1;
    CTKNumber localCTKNumber1 = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    int i = localCTKNumber1.GetIntValue();
    localCTKNumber1.UpdateSlow();
    int j = localCTKNumber1.GetIntValue();
    if (((j != 0) && (j != this.Base - 1)) || (!(this.Connected)))
      return i;
    int k = this.Nums.size();
    if ((i == this.Base - 1) && (this.CurrentIndex < k - 1))
      for (l = this.CurrentIndex + 1; l < k; ++l)
      {
        localCTKNumber2 = (CTKNumber)this.Nums.elementAt(l);
        i1 = localCTKNumber2.GetIntValue();
        if (++i1 == this.Base)
        {
          localCTKNumber2.SetValue(0);
        }
        else
        {
          localCTKNumber2.SetValue(i1);
          break;
        }
      }
    else if ((i == 0) && (this.CurrentIndex < k - 1))
      for (l = this.CurrentIndex + 1; l < k; ++l)
      {
        localCTKNumber2 = (CTKNumber)this.Nums.elementAt(l);
        i1 = localCTKNumber2.GetIntValue();
        if (i1 == 0)
        {
          localCTKNumber2.SetValue(this.Base - 1);
        }
        else
        {
          localCTKNumber2.SetValue(--i1);
          break;
        }
      }
    return i;
  }

  public void DrawString(Graphics paramGraphics, int paramInt1, int paramInt2)
  {
    BaseSys localBaseSys = new BaseSys(this.Base);
    int i = this.Nums.size();
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int j = localFontMetrics.getAscent() - localFontMetrics.getDescent();
    for (int k = 0; k < i; ++k)
    {
      CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(i - k - 1);
      int l = localCTKNumber.GetIntValue();
      String str = localBaseSys.ConvertNum(l);
      paramGraphics.drawString(str, paramInt1, paramInt2);
      int i1 = localFontMetrics.stringWidth(str);
      localCTKNumber.SetBorder(new Rectangle(paramInt1, paramInt2 - j, i1, j));
      paramInt1 += i1;
    }
  }

  public CTKNumber GetDigitAt(int paramInt)
  {
    return ((CTKNumber)this.Nums.elementAt(paramInt));
  }

  public long GetLong()
  {
    long l = -4584371143116324864L;
    int i = this.Nums.size();
    if (i == 0)
      return -4584370559000772608L;
    for (int j = 0; j < i; ++j)
    {
      CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(i - j - 1);
      int k = localCTKNumber.GetIntValue();
      l = l * this.Base + k;
    }
    return l;
  }

  public String toString()
  {
    BaseSys localBaseSys = new BaseSys(this.Base);
    int i = this.Nums.size();
    if (i == 0)
      return "";
    StringBuffer localStringBuffer = new StringBuffer();
    for (int j = 0; j < i; ++j)
    {
      CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(i - j - 1);
      int k = localCTKNumber.GetIntValue();
      String str = localBaseSys.ConvertNum(k);
      localStringBuffer.append(str);
    }
    return localStringBuffer.toString();
  }

  public boolean IsHit(int paramInt1, int paramInt2)
  {
    int i = this.Nums.size();
    for (int j = 0; j < i; ++j)
    {
      CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(j);
      if (localCTKNumber.IsHit(paramInt1, paramInt2))
      {
        this.CurrentIndex = j;
        return true;
      }
    }
    this.CurrentIndex = -1;
    return false;
  }

  public void SetValue(int paramInt1, int paramInt2)
  {
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(paramInt2);
    localCTKNumber.SetValue(paramInt1);
  }
}