import java.awt.Graphics;
import java.util.Enumeration;
import java.util.Vector;

class CTKNumberHolder
{
  Vector Nums = new Vector();
  int CurrentIndex = -1;

  public void Add(CTKNumber paramCTKNumber)
  {
    this.Nums.addElement(paramCTKNumber);
  }

  public void Clear()
  {
    this.Nums.removeAllElements();
  }

  public int Update()
  {
    return UpdateFast();
  }

  public int UpdateFast()
  {
    if (this.CurrentIndex == -1)
      return -1;
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    return localCTKNumber.UpdateFast();
  }

  public int UpdateSlow()
  {
    if (this.CurrentIndex == -1)
      return -1;
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    return localCTKNumber.UpdateSlow();
  }

  public void Draw(Graphics paramGraphics, int paramInt)
  {
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(paramInt);
    localCTKNumber.Draw(paramGraphics);
  }

  public void Draw(Graphics paramGraphics)
  {
    Enumeration localEnumeration = this.Nums.elements();
    while (localEnumeration.hasMoreElements())
    {
      CTKNumber localCTKNumber = (CTKNumber)localEnumeration.nextElement();
      localCTKNumber.Draw(paramGraphics);
    }
  }

  public CTKIntValue GetValue()
  {
    if (this.CurrentIndex == -1)
      return null;
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    return localCTKNumber.GetValue();
  }

  public int GetIntValue()
  {
    if (this.CurrentIndex == -1)
      return -1;
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    return localCTKNumber.GetValue().GetValue();
  }

  public String toString()
  {
    if (this.CurrentIndex == -1)
      return null;
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(this.CurrentIndex);
    return localCTKNumber.GetValue().toString();
  }

  public boolean IsHit(int paramInt1, int paramInt2)
  {
    int i = this.Nums.size();
    for (int j = 0; j < i; ++j)
    {
      CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(j);
      if (localCTKNumber.IsHit(paramInt1, paramInt2))
      {
        this.CurrentIndex = j;
        return true;
      }
    }
    this.CurrentIndex = -1;
    return false;
  }

  public void SetValue(int paramInt1, int paramInt2)
  {
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(paramInt2);
    localCTKNumber.SetValue(paramInt1);
  }
}