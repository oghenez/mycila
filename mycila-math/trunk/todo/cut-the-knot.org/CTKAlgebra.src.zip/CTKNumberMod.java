import java.awt.Canvas;

class CTKNumberMod extends CTKNumber
{
  int Mod = 10;

  public CTKNumberMod(Canvas paramCanvas, int paramInt)
  {
    super(paramCanvas, paramInt);
  }

  public void SetModulo(int paramInt)
  {
    this.Mod = paramInt;
    super.SetValue(super.GetValue().GetValue() % paramInt);
  }

  public int UpdateFast()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
      this.m_Value.SetValue((i + this.incr) % this.Mod);
    else if (!(this.m_bUp))
      this.m_Value.SetValue((this.Mod + i - this.incr) % this.Mod);
    return i;
  }

  public int UpdateSlow()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
      this.m_Value.SetValue((i + 1) % this.Mod);
    else if (!(this.m_bUp))
      this.m_Value.SetValue((this.Mod + i - 1) % this.Mod);
    return i;
  }
}