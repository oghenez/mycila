abstract interface CompareValues
{
  public abstract boolean Compare(CompareValues paramCompareValues);

  public abstract boolean Equals(CompareValues paramCompareValues);

  public abstract float GetValue();
}