import java.awt.Graphics;

class GraphNode extends MoveablePoint
{
  public GraphNode(double paramDouble1, double paramDouble2)
  {
    super(paramDouble1, paramDouble2);
  }

  public void DrawBackground(Graphics paramGraphics)
  {
    paramGraphics.fillOval((int)(this.x - this.m_r), (int)(this.y - this.m_r), 2 * this.m_r, 2 * this.m_r);
  }

  public boolean Inside(int paramInt1, int paramInt2)
  {
    this.m_Defect.x = (this.x - paramInt1);
    this.m_Defect.y = (this.y - paramInt2);
    return (this.m_Defect.x * this.m_Defect.x + this.m_Defect.y * this.m_Defect.y < this.m_r * this.m_r);
  }
}