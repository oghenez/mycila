class Tridiagonal
{
  int N;
  double[] DM;
  double[] D;
  double[] DP;
  double[] A;
  double[] C;

  public Tridiagonal(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    this.N = paramInt;
    this.DM = paramArrayOfDouble1;
    this.D = paramArrayOfDouble2;
    this.DP = paramArrayOfDouble3;
    FindLU();
  }

  public void SetMatrix(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    this.N = paramInt;
    this.DM = paramArrayOfDouble1;
    this.D = paramArrayOfDouble2;
    this.DP = paramArrayOfDouble3;
    FindLU();
  }

  public void SetMatrix(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    this.DM = paramArrayOfDouble1;
    this.D = paramArrayOfDouble2;
    this.DP = paramArrayOfDouble3;
    FindLU();
  }

  public void FindLU()
  {
    this.A = new double[this.N];
    this.C = new double[this.N - 1];
    this.A[0] = this.D[0];
    this.C[0] = (this.DP[0] / this.D[0]);
    for (int i = 1; i < this.N - 1; ++i)
    {
      this.A[i] = (this.D[i] - this.DM[(i - 1)] * this.C[(i - 1)]);
      this.C[i] = (this.DP[i] / this.A[i]);
    }
    this.A[(this.N - 1)] = (this.D[(this.N - 1)] - this.DM[(this.N - 2)] * this.C[(this.N - 2)]);
  }

  public double[] Solve(double[] paramArrayOfDouble)
  {
    double[] arrayOfDouble1 = new double[this.N];
    arrayOfDouble1[0] = (paramArrayOfDouble[0] / this.A[0]);
    for (int i = 1; i < this.N; ++i)
      arrayOfDouble1[i] = ((paramArrayOfDouble[i] - this.DM[(i - 1)] * arrayOfDouble1[(i - 1)]) / this.A[i]);
    double[] arrayOfDouble2 = new double[this.N];
    arrayOfDouble2[(this.N - 1)] = arrayOfDouble1[(this.N - 1)];
    for (int j = this.N - 2; j >= 0; --j)
      arrayOfDouble2[j] = (arrayOfDouble1[j] - this.C[j] * arrayOfDouble2[(j + 1)]);
    return arrayOfDouble2;
  }
}