import java.awt.Graphics;
import java.awt.Point;

class RPolynomial
{
  int N;
  double[] Coef;
  Scale ScaleX = new Scale(1D, 0D);
  Scale ScaleY = new Scale(1D, 0D);

  public void SetXScale(Scale paramScale)
  {
    this.ScaleX = paramScale;
  }

  public void SetYScale(Scale paramScale)
  {
    this.ScaleY = paramScale;
  }

  public RPolynomial(double[] paramArrayOfDouble)
  {
    try
    {
      this.N = (paramArrayOfDouble.length - 1);
      this.Coef = paramArrayOfDouble;
    }
    catch (Exception localException)
    {
      this.N = 0;
      this.Coef = null;
    }
  }

  public void SetPolynomial(double[] paramArrayOfDouble)
  {
    this.N = (paramArrayOfDouble.length - 1);
    this.Coef = paramArrayOfDouble;
  }

  public double Value(double paramDouble)
  {
    paramDouble = this.ScaleX.Do(paramDouble);
    double d = this.Coef[this.N];
    for (int i = this.N - 1; i >= 0; --i)
      d = d * paramDouble + this.Coef[i];
    return this.ScaleY.Reverse(d);
  }

  public void Draw(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt1;
    for (Object localObject = new Point(i, (int)Math.round(Value(i))); i < paramInt2; localObject = localPoint)
    {
      i += paramInt3;
      Point localPoint = new Point(i, (int)Math.round(Value(i)));
      if ((Math.abs(((Point)localObject).y) <= 30000) && (Math.abs(localPoint.y) <= 30000))
        paramGraphics.drawLine(((Point)localObject).x, ((Point)localObject).y, localPoint.x, localPoint.y);
    }
  }
}