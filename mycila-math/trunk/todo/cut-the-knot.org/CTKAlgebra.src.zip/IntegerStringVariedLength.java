import java.util.Vector;

class IntegerStringVariedLength extends IntegerString
{
  public IntegerStringVariedLength(long paramLong, int paramInt)
  {
    super(paramLong, paramInt);
    this.Connected = true;
  }

  public IntegerStringVariedLength(long paramLong)
  {
    super(paramLong);
    this.Connected = true;
  }

  public int Update()
  {
    int l;
    CTKNumber localCTKNumber;
    int i1;
    if (this.CurrentIndex == -1)
      return -1;
    if (!(this.Connected))
      return super.Update();
    CTKNumberMod localCTKNumberMod = (CTKNumberMod)this.Nums.elementAt(this.CurrentIndex);
    int i = localCTKNumberMod.GetIntValue();
    localCTKNumberMod.UpdateSlow();
    int j = localCTKNumberMod.GetIntValue();
    int k = this.Nums.size();
    if ((this.Connected) && (i == 1) && (j == 0) && (this.CurrentIndex == k - 1) && (k > 1))
    {
      this.Nums.remove(localCTKNumberMod);
      return j;
    }
    if (((i == 0) && (j == this.Base - 1)) || ((i == this.Base - 1) && (j == 0) && (this.Connected)))
      return j;
    if ((i == this.Base - 1) && (this.CurrentIndex < k))
      if (this.CurrentIndex == k - 1)
        PrependOne();
      else
        for (l = this.CurrentIndex + 1; l < k; ++l)
        {
          localCTKNumber = (CTKNumber)this.Nums.elementAt(l);
          i1 = localCTKNumber.GetIntValue();
          if (++i1 == this.Base)
          {
            localCTKNumber.SetValue(0);
            if (l == k - 1)
              PrependOne();
          }
          else
          {
            localCTKNumber.SetValue(i1);
            break;
          }
        }
    else if ((i == 0) && (this.CurrentIndex < k))
      for (l = this.CurrentIndex + 1; l < k; ++l)
      {
        localCTKNumber = (CTKNumber)this.Nums.elementAt(l);
        i1 = localCTKNumber.GetIntValue();
        if (i1 == 0)
        {
          localCTKNumber.SetValue(this.Base - 1);
          if ((l == k - 1) && (k > 1))
            this.Nums.remove(localCTKNumber);
        }
        else
        {
          localCTKNumber.SetValue(--i1);
          if ((i1 != 0) || (l != k - 1) || (k <= 1))
            break;
          this.Nums.remove(localCTKNumber);
          break;
        }
      }
    return i;
  }

  private void PrependOne()
  {
    CTKNumber localCTKNumber = (CTKNumber)this.Nums.elementAt(0);
    CTKNumberMod localCTKNumberMod = new CTKNumberMod(localCTKNumber.m_Parent, 1);
    localCTKNumberMod.SetModulo(this.Base);
    this.Nums.addElement(localCTKNumberMod);
  }
}