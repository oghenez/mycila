public class ComputablePoly
{
  double[] Coef;

  public ComputablePoly(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble != null)
    {
      int i = paramArrayOfDouble.length;
      this.Coef = new double[i];
      for (int j = 0; j < i; ++j)
        this.Coef[j] = paramArrayOfDouble[j];
    }
  }

  public ComputablePoly(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt != null)
    {
      int i = paramArrayOfInt.length;
      this.Coef = new double[i];
      for (int j = 0; j < i; ++j)
        this.Coef[j] = paramArrayOfInt[j];
    }
  }

  public double Compute(double paramDouble)
  {
    if (this.Coef == null)
      return (0.0D / 0.0D);
    int i = this.Coef.length;
    if (i == 0)
      return (0.0D / 0.0D);
    if (i == 1)
      return this.Coef[0];
    double d = this.Coef[(i - 1)];
    for (int j = i - 2; j >= 0; --j)
      d = d * paramDouble + this.Coef[j];
    return d;
  }

  static double Compute(double paramDouble, double[] paramArrayOfDouble)
  {
    ComputablePoly localComputablePoly = new ComputablePoly(paramArrayOfDouble);
    return localComputablePoly.Compute(paramDouble);
  }
}