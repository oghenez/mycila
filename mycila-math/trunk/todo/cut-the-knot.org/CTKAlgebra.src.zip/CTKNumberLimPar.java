import java.awt.Canvas;

class CTKNumberLimPar extends CTKNumberLim
{
  public CTKNumberLimPar(Canvas paramCanvas, int paramInt)
  {
    super(paramCanvas, paramInt);
    SetIncrement(2);
  }
}