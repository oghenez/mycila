import java.math.BigInteger;
import java.util.Stack;

class BaseSys
{
  private Stack m_Stack = new Stack();
  private String[] m_Digits = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
  private String[] m_Chars = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
  private int m_Radix;
  private String m_String = new String("");

  public BaseSys(int paramInt)
  {
    this.m_Radix = paramInt;
  }

  public void SetRadix(int paramInt)
  {
    this.m_Radix = paramInt;
  }

  public String ConvertNum(int paramInt)
  {
    return ConvertNum(paramInt);
  }

  public String ConvertNum(BigInteger paramBigInteger)
  {
    ParseNum(paramBigInteger);
    this.m_String = "";
    while (!(this.m_Stack.empty()))
      this.m_String += ((String)(String)this.m_Stack.pop());
    return this.m_String;
  }

  public String ConvertNum(long paramLong)
  {
    ParseNum(paramLong);
    this.m_String = "";
    while (!(this.m_Stack.empty()))
      this.m_String += ((String)(String)this.m_Stack.pop());
    return this.m_String;
  }

  private void ParseNum(int paramInt)
  {
    ParseNum(paramInt);
  }

  private void ParseNum(BigInteger paramBigInteger)
  {
    BigInteger localBigInteger1 = new BigInteger("10", this.m_Radix);
    BigInteger localBigInteger3 = new BigInteger("10");
    while (paramBigInteger.compareTo(localBigInteger1) >= 0)
    {
      BigInteger localBigInteger2 = paramBigInteger.mod(localBigInteger1);
      if ((localBigInteger2.compareTo(localBigInteger3) < 0) || (localBigInteger1.compareTo(localBigInteger3) <= 0))
        this.m_Stack.push(this.m_Digits[localBigInteger2.intValue()]);
      else
        this.m_Stack.push(this.m_Chars[(localBigInteger2.intValue() - 10)]);
      paramBigInteger = paramBigInteger.divide(localBigInteger1);
    }
    if ((paramBigInteger.compareTo(localBigInteger3) < 0) || (localBigInteger1.compareTo(localBigInteger3) <= 0))
      this.m_Stack.push(this.m_Digits[paramBigInteger.intValue()]);
    else
      this.m_Stack.push(this.m_Chars[(paramBigInteger.intValue() - 10)]);
  }

  private void ParseNum(long paramLong)
  {
    while (paramLong >= this.m_Radix)
    {
      int i = (int)(paramLong % this.m_Radix);
      if ((i < 10) || (this.m_Radix <= 10))
        this.m_Stack.push(this.m_Digits[i]);
      else
        this.m_Stack.push(this.m_Chars[(i - 10)]);
      paramLong /= this.m_Radix;
    }
    if (((int)paramLong < 10) || (this.m_Radix <= 10))
      this.m_Stack.push(this.m_Digits[(int)paramLong]);
    else
      this.m_Stack.push(this.m_Chars[((int)paramLong - 10)]);
  }

  public int ConvertTo10(String paramString, int paramInt)
  {
    int i = paramString.length();
    int j = Check(paramString.substring(0, 1).toUpperCase(), paramInt);
    if (j == -1)
      return -1;
    int k = 0;
    for (int l = 1; l < i; ++l)
    {
      String str = paramString.substring(l, l + 1).toUpperCase();
      if ((k = Check(str, paramInt)) == -1)
        return -1;
      j = k + paramInt * j;
    }
    return j;
  }

  public long ConvertTo10(String paramString, int paramInt, boolean paramBoolean)
  {
    int i = paramString.length();
    long l = Check(paramString.substring(0, 1).toUpperCase(), paramInt);
    if (l == -1L)
      return -1L;
    int j = 0;
    for (int k = 1; k < i; ++k)
    {
      String str = paramString.substring(k, k + 1).toUpperCase();
      if ((j = Check(str, paramInt)) == -1)
        return -1L;
      l = j + paramInt * l;
    }
    return l;
  }

  public int Check(String paramString, int paramInt)
  {
    int i = Math.min(10, paramInt);
    for (int j = 0; j < i; ++j)
      if (paramString.compareTo(this.m_Digits[j]) == 0)
        return j;
    for (j = 0; j < paramInt - 10; ++j)
      if (paramString.compareTo(this.m_Chars[j]) == 0)
        return (j + 10);
    return -1;
  }
}