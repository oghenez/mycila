class CTKFormat
{
  static String CutDigits(double paramDouble, int paramInt)
  {
    Object localObject;
    int k;
    String str2;
    for (int i = 0; i < paramInt; ++i)
      paramDouble *= 10.0D;
    paramDouble = Math.round(paramDouble);
    if (paramDouble == 0D)
      return "0";
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = paramDouble;
    int j = str1.indexOf(46);
    if (j == -1)
      j = str1.length();
    if (paramDouble < 0D)
    {
      if (j - paramInt - 1 < 0)
      {
        localObject = new StringBuffer();
        ((StringBuffer)localObject).append("-");
        for (k = 0; k < paramInt - j + 1; ++k)
          ((StringBuffer)localObject).append("0");
        ((StringBuffer)localObject).append(str1);
        str1 = ((StringBuffer)localObject).toString();
      }
    }
    else if (j - paramInt < 0)
    {
      localObject = new StringBuffer();
      for (k = 0; k < paramInt - j; ++k)
      {
        ((StringBuffer)localObject).append("0");
        ++j;
      }
      ((StringBuffer)localObject).append(str1);
      str1 = ((StringBuffer)localObject).toString();
    }
    if (j > paramInt)
    {
      localObject = str1.substring(0, j - paramInt);
      str2 = str1.substring(j - paramInt, j);
    }
    else
    {
      localObject = "";
      str2 = str1.substring(0, j);
    }
    localStringBuffer = new StringBuffer((String)localObject);
    localStringBuffer.append(".").append(str2);
    return ((String)localStringBuffer.toString());
  }
}