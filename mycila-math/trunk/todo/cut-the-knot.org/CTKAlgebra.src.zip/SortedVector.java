import java.util.Vector;

class SortedVector extends Vector
{
  private boolean m_bSkipFirst;

  public SortedVector(boolean paramBoolean)
  {
    this.m_bSkipFirst = paramBoolean;
  }

  public SortedVector()
  {
    this.m_bSkipFirst = false;
  }

  public SortedVector(int paramInt)
  {
    super(paramInt);
    this.m_bSkipFirst = false;
  }

  public void addElement(CompareValues paramCompareValues)
  {
    int i = super.size();
    for (int j = (this.m_bSkipFirst) ? 1 : 0; j < i; ++j)
    {
      CompareValues localCompareValues = (CompareValues)super.elementAt(j);
      if (paramCompareValues.Compare(localCompareValues))
      {
        super.insertElementAt(paramCompareValues, j);
        return;
      }
    }
    super.addElement(paramCompareValues);
  }

  public void AddUniqueReverse(CompareValues paramCompareValues)
  {
    int i = super.size();
    for (int j = (this.m_bSkipFirst) ? 1 : 0; j < i; ++j)
    {
      CompareValues localCompareValues = (CompareValues)super.elementAt(j);
      if (paramCompareValues.Equals(localCompareValues))
        return;
      if (!(paramCompareValues.Compare(localCompareValues)))
      {
        super.insertElementAt(paramCompareValues, j);
        return;
      }
    }
    super.addElement(paramCompareValues);
  }

  public CompareValues RouletteSelect()
  {
    float f1 = 0F;
    int i = super.size();
    for (int j = 0; j < i; ++j)
      f1 += ((CompareValues)super.elementAt(j)).GetValue();
    float f2 = (float)(Math.random() * f1);
    float f3 = 0F;
    for (int k = 0; k < i; ++k)
    {
      f3 += ((CompareValues)super.elementAt(k)).GetValue();
      if (f2 < f3)
        return ((CompareValues)super.elementAt(k));
    }
    return ((CompareValues)null);
  }

  public CompareValues RouletteSelectOtherThan(CompareValues paramCompareValues)
  {
    for (CompareValues localCompareValues = RouletteSelect(); (localCompareValues == paramCompareValues) && (localCompareValues != null); localCompareValues = RouletteSelect());
    return localCompareValues;
  }
}