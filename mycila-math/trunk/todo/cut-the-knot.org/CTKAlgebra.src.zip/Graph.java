import java.applet.Applet;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Enumeration;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;

class Graph extends BetterMover
{
  Vector Edges;
  int CurrentNode = -1;
  Vector Path;
  int NumOfEdges;
  boolean IsFinished = false;
  String Message = null;
  boolean ShowNames = false;
  boolean Which = true;
  Stack Removed = new Stack();

  String GetMessage()
  {
    return this.Message;
  }

  void SetMessage(String paramString)
  {
    this.Message = paramString;
  }

  public void ShowNames(boolean paramBoolean)
  {
    this.ShowNames = paramBoolean;
  }

  public void SetWhich(boolean paramBoolean)
  {
    this.Which = paramBoolean;
    RemoveCurrent();
    this.Removed = new Stack();
  }

  public void RemoveCurrent()
  {
    this.CurrentNode = -1;
    this.Path = new Vector();
  }

  public Graph()
  {
    SetPromote(false);
    RemoveCurrent();
  }

  public void Draw(Graphics paramGraphics, Canvas paramCanvas)
  {
    DrawVisitedNodes(paramGraphics);
    DrawCurrent(paramGraphics);
    DrawEdges(paramGraphics, paramCanvas);
    DrawNodes(paramGraphics, paramCanvas);
    if (this.IsFinished)
      DrawPath(paramGraphics);
  }

  private void DrawPath(Graphics paramGraphics)
  {
    if (this.Path.size() < 2)
      return;
    paramGraphics.setColor(Color.magenta);
    int i = new Integer((String)this.Path.elementAt(0)).intValue();
    Object localObject = (GraphNode)this.Moveables.elementAt(i);
    for (int j = 1; j < this.Path.size(); ++j)
    {
      int k = new Integer((String)this.Path.elementAt(j)).intValue();
      GraphNode localGraphNode = (GraphNode)this.Moveables.elementAt(k);
      GeoSDoub.DrawLine(paramGraphics, (DoubPoint)localObject, localGraphNode);
      i = k;
      localObject = localGraphNode;
    }
  }

  private void DrawCurrent(Graphics paramGraphics)
  {
    if (this.CurrentNode == -1)
      return;
    GraphNode localGraphNode = (GraphNode)this.Moveables.elementAt(this.CurrentNode);
    paramGraphics.setColor(Color.blue);
    localGraphNode.DrawBackground(paramGraphics);
  }

  private void DrawVisitedNodes(Graphics paramGraphics)
  {
    paramGraphics.setColor(Color.red);
    Enumeration localEnumeration = this.Path.elements();
    while (localEnumeration.hasMoreElements())
    {
      Integer localInteger = new Integer((String)localEnumeration.nextElement());
      GraphNode localGraphNode = (GraphNode)this.Moveables.elementAt(localInteger.intValue());
      localGraphNode.DrawBackground(paramGraphics);
    }
  }

  private void DrawEdges(Graphics paramGraphics, Canvas paramCanvas)
  {
    paramGraphics.setColor(paramCanvas.getForeground());
    for (int i = 0; i < this.Edges.size(); ++i)
    {
      Vector localVector = (Vector)this.Edges.elementAt(i);
      GraphNode localGraphNode1 = (GraphNode)this.Moveables.elementAt(i);
      Enumeration localEnumeration = localVector.elements();
      while (localEnumeration.hasMoreElements())
      {
        Integer localInteger = (Integer)localEnumeration.nextElement();
        GraphNode localGraphNode2 = (GraphNode)this.Moveables.elementAt(localInteger.intValue());
        GeoSDoub.DrawLine(paramGraphics, localGraphNode1, localGraphNode2);
      }
    }
  }

  private void DrawNodes(Graphics paramGraphics, Canvas paramCanvas)
  {
    paramGraphics.setColor(paramCanvas.getForeground());
    Enumeration localEnumeration = this.Moveables.elements();
    while (localEnumeration.hasMoreElements())
    {
      GraphNode localGraphNode = (GraphNode)localEnumeration.nextElement();
      localGraphNode.Draw(paramGraphics);
    }
  }

  public void ReadData(Applet paramApplet, Canvas paramCanvas)
  {
    int i;
    try
    {
      i = 0;
      while (true)
      {
        String str1 = paramApplet.getParameter("node[" + i + "]");
        if (str1 == null)
          break;
        ParseNode(str1, paramCanvas);
        ++i;
      }
    }
    catch (Exception localException1)
    {
    }
    int j = this.Moveables.size();
    this.Edges = new Vector();
    for (int k = 0; k < j; ++k)
      this.Edges.addElement(new Vector());
    this.NumOfEdges = 0;
    try
    {
      k = 0;
      while (true)
      {
        String str2 = paramApplet.getParameter("from[" + k + "]");
        if (str2 == null)
          break;
        ParseEdges(str2);
        ++k;
      }
    }
    catch (Exception localException2)
    {
    }
  }

  private void ParseNode(String paramString, Canvas paramCanvas)
  {
    Dimension localDimension = paramCanvas.getSize();
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
    GraphNode localGraphNode = new GraphNode(new Double(localStringTokenizer.nextToken()).doubleValue() * localDimension.width, new Double(localStringTokenizer.nextToken()).doubleValue() * localDimension.height);
    localGraphNode.SetColor(Color.red);
    localGraphNode.SetDraggable(true);
    localGraphNode.SetDrawable(true);
    localGraphNode.ShowName(this.ShowNames);
    localGraphNode.SetName("" + this.Moveables.size());
    localGraphNode.SetDrawingParams(5, Color.red);
    localGraphNode.SetRadius(5);
    AddMoveable(localGraphNode);
  }

  private void ParseEdges(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
    Integer localInteger1 = new Integer(localStringTokenizer.nextToken());
    Vector localVector1 = (Vector)this.Edges.elementAt(localInteger1.intValue());
    while (localStringTokenizer.hasMoreTokens())
    {
      Integer localInteger2 = new Integer(localStringTokenizer.nextToken());
      localVector1.addElement(localInteger2);
      Vector localVector2 = (Vector)this.Edges.elementAt(localInteger2.intValue());
      localVector2.addElement(localInteger1);
      this.NumOfEdges += 1;
    }
  }

  private boolean FirstTime(int paramInt)
  {
    String str1 = "" + paramInt;
    Enumeration localEnumeration = this.Path.elements();
    while (localEnumeration.hasMoreElements())
    {
      String str2 = (String)localEnumeration.nextElement();
      if (str2.equals(str1))
        return false;
    }
    return true;
  }

  private boolean IsLinkedTo(Vector paramVector, int paramInt)
  {
    Enumeration localEnumeration = paramVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      Integer localInteger = (Integer)localEnumeration.nextElement();
      if (paramInt == localInteger.intValue())
        return true;
    }
    return false;
  }

  private void RemoveEdge(Vector paramVector, int paramInt)
  {
    Enumeration localEnumeration = paramVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      Integer localInteger = (Integer)localEnumeration.nextElement();
      if (paramInt == localInteger.intValue())
        paramVector.removeElement(localInteger);
    }
  }

  public boolean Reverse()
  {
    Point localPoint;
    try
    {
      localPoint = (Point)this.Removed.pop();
      Vector localVector = (Vector)this.Edges.elementAt(localPoint.x);
      localVector.addElement(new Integer(localPoint.y));
      localVector = (Vector)this.Edges.elementAt(localPoint.y);
      localVector.addElement(new Integer(localPoint.x));
      if (this.CurrentNode == localPoint.x)
        this.CurrentNode = localPoint.y;
      else
        this.CurrentNode = localPoint.x;
      int i = this.Path.size();
      if (i > 0)
        this.Path.removeElementAt(i - 1);
      this.IsFinished = false;
      this.Selected = -1;
      if (this.Removed.isEmpty())
      {
        this.CurrentNode = -1;
        this.Path.removeElement(this.Path.lastElement());
      }
      return true;
    }
    catch (Exception localException)
    {
    }
    return false;
  }

  public boolean StackIsEmpty()
  {
    return this.Removed.isEmpty();
  }

  public boolean IsMoveAcceptable()
  {
    String str;
    this.IsFinished = false;
    if (this.Selected == -1)
      return false;
    if (this.CurrentNode == -1)
      return true;
    if (this.Selected == this.CurrentNode)
      return false;
    Vector localVector = (Vector)this.Edges.elementAt(this.CurrentNode);
    if (!(IsLinkedTo(localVector, this.Selected)))
    {
      this.Message = "There's no available edge there";
      return false;
    }
    if (this.Which)
    {
      if (this.Path.size() != this.NumOfEdges)
        break label337;
      str = (String)this.Path.firstElement();
      int i = Integer.parseInt(str);
      localVector = (Vector)this.Edges.elementAt(i);
      if ((IsLinkedTo(localVector, this.Selected)) || (this.Selected == i))
        this.Message = "Congratulations, you have found an Euler circuit.";
      else
        this.Message = "Good. You got an Euler path.";
      this.IsFinished = true;
      return true;
    }
    if (!(FirstTime(this.Selected)))
    {
      if (this.Path.size() < this.Moveables.size())
      {
        this.Message = "You are getting a premature circuit";
        return false;
      }
      if (this.Path.size() != this.Moveables.size())
        break label337;
      str = (String)this.Path.firstElement();
      if (Integer.parseInt(str) != this.Selected)
      {
        this.Message = "Are you dizzy?";
        return false;
      }
      this.Message = "Very good. You got a Hamilton circuit.";
      this.IsFinished = true;
      return true;
    }
    if ((!(this.Which)) && (this.Path.size() == this.Moveables.size() - 1))
    {
      str = (String)this.Path.firstElement();
      localVector = (Vector)this.Edges.elementAt(Integer.parseInt(str));
      if (!(IsLinkedTo(localVector, this.Selected)))
      {
        this.Message = "Good. You got a Hamilton path.";
        this.IsFinished = true;
        return true;
      }
    }
    label337: return true;
  }

  public void StopDragging()
  {
    this.Selected = -1;
  }

  public void PerformStep()
  {
    if (this.CurrentNode != -1)
    {
      Vector localVector1 = (Vector)this.Edges.elementAt(this.CurrentNode);
      this.Path.addElement("" + this.Selected);
      RemoveEdge(localVector1, this.Selected);
      Vector localVector2 = (Vector)this.Edges.elementAt(this.Selected);
      RemoveEdge(localVector2, this.CurrentNode);
      this.Removed.push(new Point(this.Selected, this.CurrentNode));
      this.CurrentNode = this.Selected;
    }
    else
    {
      this.CurrentNode = this.Selected;
      this.Path.addElement("" + this.Selected);
    }
  }

  public String PathToString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = this.Path.size();
    for (int j = 0; j < i; ++j)
    {
      localStringBuffer.append((String)this.Path.elementAt(j));
      if (j != i - 1)
        localStringBuffer.append(",");
    }
    return localStringBuffer.toString();
  }
}