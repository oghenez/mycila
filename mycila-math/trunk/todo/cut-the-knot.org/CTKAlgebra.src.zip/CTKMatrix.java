class CTKMatrix
{
  int Rows;
  int Cols;
  double[][] a;

  public CTKMatrix(int paramInt1, int paramInt2)
  {
    this.Rows = paramInt1;
    this.Cols = paramInt2;
    this.a = new double[paramInt1][paramInt2];
  }

  public void SetEntry(int paramInt1, int paramInt2, double paramDouble)
  {
    this.a[paramInt1][paramInt2] = paramDouble;
  }

  public boolean SetCol(int paramInt, double[] paramArrayOfDouble)
  {
    if ((paramArrayOfDouble == null) || (paramInt >= this.Cols) || (paramInt < 0) || (paramArrayOfDouble.length != this.Rows))
      return false;
    for (int i = 0; i < this.Rows; ++i)
      this.a[i][paramInt] = paramArrayOfDouble[i];
    return true;
  }

  public boolean SetRow(int paramInt, double[] paramArrayOfDouble)
  {
    if ((paramArrayOfDouble == null) || (paramInt >= this.Rows) || (paramInt < 0) || (paramArrayOfDouble.length != this.Cols))
      return false;
    for (int i = 0; i < this.Cols; ++i)
      this.a[paramInt][i] = paramArrayOfDouble[i];
    return true;
  }

  public void SetMatrix(double[][] paramArrayOfDouble)
  {
    this.Rows = paramArrayOfDouble.length;
    this.Cols = paramArrayOfDouble[0].length;
    this.a = paramArrayOfDouble;
  }

  public CTKMatrix Times(CTKMatrix paramCTKMatrix)
  {
    if (this.Cols != paramCTKMatrix.Rows)
      return null;
    double[][] arrayOfDouble = new double[this.Rows][paramCTKMatrix.Cols];
    for (int i = 0; i < this.Rows; ++i)
      for (int j = 0; j < paramCTKMatrix.Cols; ++j)
        for (int k = 0; k < this.Cols; ++k)
          arrayOfDouble[i][j] += this.a[i][k] * paramCTKMatrix.a[k][j];
    this.a = arrayOfDouble;
    return this;
  }

  public static CTKMatrix Times(CTKMatrix paramCTKMatrix1, CTKMatrix paramCTKMatrix2)
  {
    if (paramCTKMatrix1.Cols != paramCTKMatrix2.Rows)
      return null;
    double[][] arrayOfDouble = new double[paramCTKMatrix1.Rows][paramCTKMatrix2.Cols];
    for (int i = 0; i < paramCTKMatrix1.Rows; ++i)
      for (int j = 0; j < paramCTKMatrix2.Cols; ++j)
        for (int k = 0; k < paramCTKMatrix1.Cols; ++k)
          arrayOfDouble[i][j] += paramCTKMatrix1.a[i][k] * paramCTKMatrix2.a[k][j];
    CTKMatrix localCTKMatrix = new CTKMatrix(paramCTKMatrix1.Cols, paramCTKMatrix2.Rows);
    localCTKMatrix.SetMatrix(arrayOfDouble);
    return localCTKMatrix;
  }

  public CTKMatrix Plus(CTKMatrix paramCTKMatrix)
  {
    if ((this.Rows != paramCTKMatrix.Rows) || (this.Cols != paramCTKMatrix.Cols))
      return null;
    double[][] arrayOfDouble = new double[this.Rows][paramCTKMatrix.Cols];
    for (int i = 0; i < this.Rows; ++i)
      for (int j = 0; j < paramCTKMatrix.Cols; ++j)
        this.a[i][j] += paramCTKMatrix.a[i][j];
    return this;
  }

  public static CTKMatrix Plus(CTKMatrix paramCTKMatrix1, CTKMatrix paramCTKMatrix2)
  {
    if ((paramCTKMatrix1.Rows != paramCTKMatrix2.Rows) || (paramCTKMatrix1.Cols != paramCTKMatrix2.Cols))
      return null;
    double[][] arrayOfDouble = new double[paramCTKMatrix1.Rows][paramCTKMatrix2.Cols];
    for (int i = 0; i < paramCTKMatrix1.Rows; ++i)
      for (int j = 0; j < paramCTKMatrix1.Cols; ++j)
        arrayOfDouble[i][j] = (paramCTKMatrix1.a[i][j] + paramCTKMatrix2.a[i][j]);
    CTKMatrix localCTKMatrix = new CTKMatrix(paramCTKMatrix1.Rows, paramCTKMatrix1.Cols);
    localCTKMatrix.SetMatrix(arrayOfDouble);
    return localCTKMatrix;
  }

  public double Entry(int paramInt1, int paramInt2)
  {
    return this.a[paramInt1][paramInt2];
  }
}