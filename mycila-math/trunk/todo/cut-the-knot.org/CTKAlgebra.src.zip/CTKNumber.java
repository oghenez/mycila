import java.awt.Canvas;
import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;

class CTKNumber
{
  Rectangle m_Border;
  CTKIntValue m_Value;
  boolean m_bUp;
  Canvas m_Parent;
  int incr = 1;
  boolean m_NegativeInPara = true;
  FontMetrics m_FM;

  public void SetIncrement(int paramInt)
  {
    this.incr = paramInt;
  }

  public void SetNegativeInPara(boolean paramBoolean)
  {
    this.m_NegativeInPara = paramBoolean;
  }

  public CTKNumber(Canvas paramCanvas, int paramInt)
  {
    this.m_Parent = paramCanvas;
    this.m_Border = new Rectangle();
    this.m_Value = new CTKIntValue(paramInt);
  }

  public CTKNumber(Canvas paramCanvas, CTKIntValue paramCTKIntValue)
  {
    this.m_Parent = paramCanvas;
    this.m_Border = new Rectangle();
    this.m_Value = paramCTKIntValue;
  }

  public void SetBorder(Rectangle paramRectangle)
  {
    this.m_Border = paramRectangle;
  }

  public void SetFontMetrics(FontMetrics paramFontMetrics)
  {
    this.m_FM = paramFontMetrics;
  }

  public int Increase(int paramInt)
  {
    return this.m_Value.Add(paramInt).IntValue();
  }

  public int Decrease(int paramInt)
  {
    return this.m_Value.Add(-paramInt).IntValue();
  }

  public int Update()
  {
    return UpdateFast();
  }

  public int UpdateFast()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
      this.m_Value.SetValue(i + this.incr);
    else if (!(this.m_bUp))
      this.m_Value.SetValue(i - this.incr);
    return i;
  }

  public int UpdateSlow()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
      this.m_Value.SetValue(i + 1);
    else if (!(this.m_bUp))
      this.m_Value.SetValue(i - 1);
    return i;
  }

  public void Draw(Graphics paramGraphics)
  {
    String str;
    int i = this.m_Value.IntValue();
    if ((i < 0) && (this.m_NegativeInPara))
      str = "(" + i + ")";
    else
      str = "" + i;
    FontMetrics localFontMetrics = (this.m_FM == null) ? paramGraphics.getFontMetrics() : this.m_FM;
    int j = localFontMetrics.stringWidth(str);
    paramGraphics.setColor(this.m_Parent.getForeground());
    paramGraphics.drawString(str, this.m_Border.x + (this.m_Border.width - j) / 2, this.m_Border.y + (this.m_Border.height + localFontMetrics.getMaxAscent()) / 2);
  }

  public CTKIntValue GetValue()
  {
    return this.m_Value;
  }

  public int GetIntValue()
  {
    return this.m_Value.GetValue();
  }

  public String toString()
  {
    return this.m_Value.toString();
  }

  public boolean IsHit(int paramInt1, int paramInt2)
  {
    this.m_bUp = (paramInt1 > this.m_Border.x + this.m_Border.width / 2);
    return ((paramInt1 > this.m_Border.x) && (paramInt2 > this.m_Border.y) && (paramInt1 < this.m_Border.x + this.m_Border.width) && (paramInt2 < this.m_Border.y + this.m_Border.height));
  }

  public void SetValue(int paramInt)
  {
    this.m_Value.SetValue(paramInt);
  }
}