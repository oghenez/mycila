import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Enumeration;
import java.util.Vector;

class CTKNumberCanvas extends Canvas
  implements MouseListener, MouseMotionListener, ValueCarrier
{
  String Name = null;
  Vector Listeners = new Vector();
  CTKIntValue m_Value;
  Point Range;
  boolean m_bUp;
  int incr = 1;
  boolean m_NegativeInPara = true;
  static FontMetrics m_FM;
  static Font m_Font = new Font("Arial", 1, 18);

  public void SetName(String paramString)
  {
    this.Name = paramString;
  }

  public void SetColor(Color paramColor)
  {
    setForeground(paramColor);
    repaint();
  }

  public Dimension getMinimumSize()
  {
    return new Dimension(20, 20);
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(20, 20);
  }

  public void SetRange(int paramInt1, int paramInt2)
  {
    this.Range = new Point(paramInt1, paramInt2);
  }

  public void SetIncrement(int paramInt)
  {
    this.incr = paramInt;
  }

  public void SetNegativeInPara(boolean paramBoolean)
  {
    this.m_NegativeInPara = paramBoolean;
  }

  public CTKNumberCanvas(int paramInt)
  {
    this.m_Value = new CTKIntValue(paramInt);
    addMouseListener(this);
    addMouseMotionListener(this);
  }

  public CTKNumberCanvas(CTKIntValue paramCTKIntValue)
  {
    this.m_Value = paramCTKIntValue;
    addMouseListener(this);
    addMouseMotionListener(this);
  }

  public void SetFontMetrics(FontMetrics paramFontMetrics)
  {
    m_FM = paramFontMetrics;
  }

  public int Update()
  {
    return UpdateFast();
  }

  public int UpdateFast()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
    {
      i += this.incr;
      if ((this.Range != null) && (i > this.Range.y))
        i = this.Range.x + i - this.Range.y - 1;
      this.m_Value.SetValue(i);
    }
    else if (!(this.m_bUp))
    {
      i -= this.incr;
      if ((this.Range != null) && (i < this.Range.x))
        i = this.Range.y + i - this.Range.x + 1;
      this.m_Value.SetValue(i);
    }
    NotifyListeners();
    return i;
  }

  public int UpdateSlow()
  {
    int i = this.m_Value.IntValue();
    if (this.m_bUp)
    {
      i += this.incr;
      if ((this.Range != null) && (i > this.Range.y))
        i = this.Range.x + i - this.Range.y - 1;
      this.m_Value.SetValue(i);
    }
    else if (!(this.m_bUp))
    {
      i -= this.incr;
      if ((this.Range != null) && (i < this.Range.x))
        i = this.Range.y + i - this.Range.x + 1;
      this.m_Value.SetValue(i);
    }
    NotifyListeners();
    return i;
  }

  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }

  public void paint(Graphics paramGraphics)
  {
    Dimension localDimension = getSize();
    paramGraphics.clearRect(0, 0, localDimension.width, localDimension.height);
    Draw(paramGraphics);
  }

  public void Draw(Graphics paramGraphics)
  {
    String str;
    Dimension localDimension = getSize();
    int i = this.m_Value.IntValue();
    if ((i < 0) && (this.m_NegativeInPara))
      str = "(" + i + ")";
    else
      str = "" + i;
    paramGraphics.setFont(m_Font);
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int j = localFontMetrics.stringWidth(str);
    if (isEnabled())
      paramGraphics.setColor(Color.gray);
    else
      paramGraphics.setColor(getForeground());
    paramGraphics.drawString(str, (localDimension.width - j) / 2, (localDimension.height + localFontMetrics.getMaxAscent()) / 2);
    if (isEnabled())
      paramGraphics.setColor(getForeground());
    else
      paramGraphics.setColor(Color.gray);
    paramGraphics.drawString(str, (localDimension.width - j) / 2 - 1, (localDimension.height + localFontMetrics.getMaxAscent()) / 2 - 1);
  }

  public CTKIntValue GetValue()
  {
    return this.m_Value;
  }

  public int GetIntValue()
  {
    return this.m_Value.GetValue();
  }

  public String toString()
  {
    return this.m_Value.toString();
  }

  public void SetValue(int paramInt)
  {
    this.m_Value.SetValue(paramInt);
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    Dimension localDimension = getSize();
    this.m_bUp = (paramMouseEvent.getX() > localDimension.width / 2);
    UpdateSlow();
    repaint();
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    Dimension localDimension = getSize();
    this.m_bUp = (paramMouseEvent.getX() > localDimension.width / 2);
    UpdateFast();
    repaint();
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
  }

  public synchronized void addNumberChangeListener(NumberChangeListener paramNumberChangeListener)
  {
    if (this.Listeners.contains(paramNumberChangeListener))
      return;
    this.Listeners.addElement(paramNumberChangeListener);
  }

  public synchronized void removeNumberChangeListener(NumberChangeListener paramNumberChangeListener)
  {
    if (!(this.Listeners.contains(paramNumberChangeListener)))
      return;
    this.Listeners.removeElement(paramNumberChangeListener);
  }

  private void NotifyListeners()
  {
    Enumeration localEnumeration = this.Listeners.elements();
    NumberChangeEvent localNumberChangeEvent = new NumberChangeEvent(this, this.m_Value.IntValue(), this.Name);
    while (localEnumeration.hasMoreElements())
    {
      NumberChangeListener localNumberChangeListener = (NumberChangeListener)localEnumeration.nextElement();
      localNumberChangeListener.ProcessNumberChange(localNumberChangeEvent);
    }
  }
}