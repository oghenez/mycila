import java.util.EventListener;

public abstract interface NumberChangeListener extends EventListener
{
  public abstract void ProcessNumberChange(NumberChangeEvent paramNumberChangeEvent);
}