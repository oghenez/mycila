import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;

public class CTKHSlider
{
  MoveableNicePoint MPOrigin;
  MoveableNicePoint MPUnit;
  MoveableNicePoint MPValue;
  static final String O = "O";
  static final String U = "U";
  static final String V = "V";
  static final int A = 4;
  static final String WideString = "00000";
  Point Loc;
  int Length;
  int Unit;
  int Origin;
  double Value;
  String Name;
  int Index;
  int SDigits = 2;

  public void SetUnit(int paramInt)
  {
    if (Math.abs(paramInt - this.Origin) > 1)
      this.MPUnit.x = (this.Loc.x + (this.Unit = paramInt));
  }

  public void SetOrigin(int paramInt)
  {
    this.MPOrigin.x = (this.Loc.x + (this.Origin = paramInt));
  }

  public void SetValue(double paramDouble)
  {
    this.Value = paramDouble;
    UpdateValuePoint();
  }

  public double Value()
  {
    return this.Value;
  }

  public void SetSignificantDigits(int paramInt)
  {
    this.SDigits = paramInt;
  }

  public CTKHSlider(int paramInt1, String paramString, Point paramPoint, int paramInt2)
  {
    this.Index = paramInt1;
    this.Name = paramString;
    this.Loc = paramPoint;
    this.Length = paramInt2;
    this.Value = 0.5D;
    this.Unit = (this.Length - this.Length / 2);
    this.Origin = (this.Length / 2);
    SetMoveable(this.MPOrigin = new MoveableNicePoint(paramPoint.x + this.Origin, paramPoint.y), "O");
    SetMoveable(this.MPUnit = new MoveableNicePoint(this.MPOrigin.x + this.Unit, paramPoint.y), "U");
    SetMoveable(this.MPValue = new MoveableNicePoint((this.MPUnit.x - this.MPOrigin.x) * this.Value + this.MPOrigin.x, paramPoint.y), "V");
  }

  private void SetMoveable(MoveableNicePoint paramMoveableNicePoint, String paramString)
  {
    paramMoveableNicePoint.SetDraggable(true);
    paramMoveableNicePoint.SetName(paramString);
    paramMoveableNicePoint.SetSubscript("" + this.Index);
    paramMoveableNicePoint.SetRadius(4);
    paramMoveableNicePoint.Fix(2);
  }

  public void Draw(Graphics paramGraphics)
  {
    paramGraphics.setColor(Color.black);
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    if (this.Name != null)
    {
      i = localFontMetrics.stringWidth(this.Name);
      paramGraphics.drawString(this.Name, this.Loc.x - i - 2, this.Loc.y + (localFontMetrics.getAscent() - localFontMetrics.getDescent()) / 2);
    }
    paramGraphics.drawLine(this.Loc.x, this.Loc.y, this.Loc.x + this.Length, this.Loc.y);
    int i = (int)Math.round(this.MPOrigin.x);
    int j = (int)Math.round(this.MPUnit.x);
    int k = (int)Math.round(this.MPValue.x);
    ShowDrag(paramGraphics, i, Color.orange);
    ShowDrag(paramGraphics, j, Color.red);
    ShowDrag(paramGraphics, k, Color.blue);
    paramGraphics.setColor(Color.black);
    String str = CTKFormat.CutDigits(this.Value, this.SDigits);
    int l = localFontMetrics.stringWidth("00000") - localFontMetrics.stringWidth(str);
    paramGraphics.drawString(str, this.Loc.x + this.Length + 10 + l, this.Loc.y + (localFontMetrics.getAscent() - localFontMetrics.getDescent()) / 2);
  }

  private void ShowDrag(Graphics paramGraphics, int paramInt)
  {
    ShowDrag(paramGraphics, paramInt, null);
  }

  private void ShowDrag(Graphics paramGraphics, int paramInt, Color paramColor)
  {
    int i = 8;
    int j = 6;
    paramGraphics.drawLine(paramInt, this.Loc.y - j, paramInt, this.Loc.y + j);
    if (paramColor != null)
    {
      paramGraphics.setColor(paramColor);
      paramGraphics.fillOval(paramInt - 4, this.Loc.y - 4, i, i);
    }
    paramGraphics.setColor(Color.black);
    paramGraphics.drawOval(paramInt - 4, this.Loc.y - 4, i, i);
  }

  public void UpdateOrigin()
  {
    UpdateValuePoint();
  }

  public void UpdateUnit()
  {
    UpdateValuePoint();
  }

  public void UpdateValue()
  {
    if (Math.abs(this.MPUnit.x - this.MPOrigin.x) > 1D)
      this.Value = ((this.MPValue.x - this.MPOrigin.x) / (this.MPUnit.x - this.MPOrigin.x));
  }

  private void UpdateValuePoint()
  {
    this.MPValue.P.x = (this.MPValue.x = this.MPOrigin.x + (this.MPUnit.x - this.MPOrigin.x) * this.Value);
  }
}