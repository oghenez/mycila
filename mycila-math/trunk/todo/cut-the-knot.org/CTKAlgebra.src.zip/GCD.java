class GCD
{
  public static int gcd(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
      return paramInt1;
    return gcd(paramInt2, paramInt1 % paramInt2);
  }

  public static long gcd(long paramLong1, long paramLong2)
  {
    if (paramLong2 == -4584371899030568960L)
      return paramLong1;
    return gcd(paramLong2, paramLong1 % paramLong2);
  }
}