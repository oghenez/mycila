public class QuadraticEquation
{
  static boolean ComplexRoots;
  static boolean WantComplexRootsToo;

  public static boolean AreRootsComplex()
  {
    return ComplexRoots;
  }

  static void WantComplexRootsToo()
  {
    WantComplexRootsToo = true;
  }

  static double[] Solve(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    double d2;
    if (Math.abs(paramDouble1) < 0.01D)
      return null;
    double[] arrayOfDouble = new double[2];
    double d1 = paramDouble2 * paramDouble2 - 4.0D * paramDouble1 * paramDouble3;
    if (d1 < 0D)
    {
      if (!(WantComplexRootsToo))
        return null;
      d2 = Math.sqrt(-d1);
      arrayOfDouble[0] = (-paramDouble2 / 2.0D / paramDouble1);
      arrayOfDouble[1] = (d2 / 2.0D / paramDouble1);
      ComplexRoots = true;
    }
    else
    {
      d2 = Math.sqrt(d1);
      arrayOfDouble[0] = ((-paramDouble2 + d2) / 2.0D / paramDouble1);
      arrayOfDouble[1] = ((-paramDouble2 - d2) / 2.0D / paramDouble1);
      ComplexRoots = false;
    }
    return arrayOfDouble;
  }

  static double[] Solve2(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    double d2;
    if (Math.abs(paramDouble1) < 0.01D)
      return null;
    double[] arrayOfDouble = new double[2];
    double d1 = paramDouble2 * paramDouble2 - paramDouble1 * paramDouble3;
    if (d1 < 0D)
    {
      if (!(WantComplexRootsToo))
        return null;
      d2 = Math.sqrt(-d1);
      arrayOfDouble[0] = (-paramDouble2 / paramDouble1);
      arrayOfDouble[1] = (d2 / paramDouble1);
      ComplexRoots = true;
    }
    else
    {
      d2 = Math.sqrt(d1);
      arrayOfDouble[0] = ((-paramDouble2 + d2) / paramDouble1);
      arrayOfDouble[1] = ((-paramDouble2 - d2) / paramDouble1);
      ComplexRoots = false;
    }
    return arrayOfDouble;
  }
}