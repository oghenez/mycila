import java.awt.Canvas;

class CTKNumberLim extends CTKNumber
{
  int min;
  int max;

  public CTKNumberLim(Canvas paramCanvas, int paramInt)
  {
    super(paramCanvas, paramInt);
  }

  public void SetLimits(int paramInt1, int paramInt2)
  {
    this.min = paramInt1;
    this.max = paramInt2;
  }

  public int UpdateFast()
  {
    int i = this.m_Value.IntValue();
    if ((this.m_bUp) && (i < this.max - this.incr + 1))
      this.m_Value.SetValue(i + this.incr);
    else if ((!(this.m_bUp)) && (i > this.min + this.incr - 1))
      this.m_Value.SetValue(i - this.incr);
    return i;
  }

  public int UpdateSlow()
  {
    int i = this.m_Value.IntValue();
    if ((this.m_bUp) && (i < this.max))
      this.m_Value.SetValue(i + 1);
    else if ((!(this.m_bUp)) && (i > this.min))
      this.m_Value.SetValue(i - 1);
    return i;
  }
}