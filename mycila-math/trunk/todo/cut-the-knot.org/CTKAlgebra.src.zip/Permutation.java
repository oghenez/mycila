class Permutation
{
  String m_SpecialChar;
  int m_SpecialInt;
  boolean m_SpecialSet = false;
  final int ReplaceZero = 0;
  final int IgnoreZero = 1;
  final int ShiftUp = 2;
  int m_Mode = 0;
  int m_N = -1;
  int[] m_Values;

  public void SetSpecial(char paramChar, int paramInt)
  {
    this.m_SpecialChar = "" + paramChar;
    this.m_SpecialInt = paramInt;
    this.m_SpecialSet = true;
  }

  public Permutation(int paramInt)
  {
    this.m_Values = new int[this.m_N = paramInt];
  }

  public Permutation(int paramInt, int[] paramArrayOfInt)
  {
    this.m_N = paramInt;
    this.m_Values = paramArrayOfInt;
  }

  public void CreateRandom()
  {
    for (int i = 0; i < this.m_N; ++i)
      switch (this.m_Mode)
      {
      case 2:
      default:
        this.m_Values[i] = (i + 1);
        break;
      case 0:
        if (i == 0)
          this.m_Values[i] = this.m_N;
        else
          this.m_Values[i] = i;
      }
    for (int k = this.m_N; k > 1; --k)
    {
      i = (int)(Math.random() * k);
      int j = this.m_Values[(k - 1)];
      this.m_Values[(k - 1)] = this.m_Values[i];
      this.m_Values[i] = j;
    }
  }

  public int at(int paramInt)
  {
    return this.m_Values[paramInt];
  }

  public int InverseAt(int paramInt)
  {
    int i;
    switch (this.m_Mode)
    {
    case 2:
      i = 0;
      while (true)
      {
        if (i >= this.m_N)
          break label129;
        if (this.m_Values[i] == paramInt)
          return (i + 1);
        ++i;
      }
    case 0:
      i = 0;
      while (true)
      {
        if (i >= this.m_N)
          break label129;
        if (this.m_Values[i] == paramInt)
          return ((i == 0) ? this.m_N : i);
        ++i;
      }
    case 1:
      for (i = 1; i < this.m_N; ++i)
        if (this.m_Values[i] == paramInt)
          return i;
    }
    label129: return 0;
  }

  public void SetPerm(int[] paramArrayOfInt)
  {
    this.m_Values = paramArrayOfInt;
  }

  public void SetMode(int paramInt)
  {
    this.m_Mode = paramInt;
  }

  public String toString()
  {
    String str = new String("{");
    for (int i = 0; i < this.m_N; ++i)
      if (i == this.m_N - 1)
        str = str + this.m_Values[i] + "}";
      else
        str = str + this.m_Values[i] + ", ";
    return str;
  }

  public String toCycles()
  {
    if (this.m_SpecialSet)
      return toCyclesSpec();
    return toCyclesNonSpec();
  }

  public String toCyclesNonSpec()
  {
    String str = new String("");
    boolean[] arrayOfBoolean = new boolean[this.m_N];
    for (int i = 0; i < this.m_N; ++i)
      arrayOfBoolean[i] = false;
    if (this.m_Mode == 1)
      arrayOfBoolean[0] = true;
    i = 0;
    if ((i = FindUnchecked(arrayOfBoolean)) != -1)
    {
      str = str + "(";
      int j = 1;
      while (true)
      {
        if (arrayOfBoolean[i] != 0);
        int k = fromI(i);
        if (j != 0)
        {
          str = str + k;
          j = 0;
        }
        else
        {
          str = str + "  " + k;
        }
        arrayOfBoolean[i] = true;
        i = fromV(this.m_Values[i]);
        if (arrayOfBoolean[i] != 0)
          str = str + ") ";
      }
    }
    return str;
  }

  public String toCyclesSpec()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    boolean[] arrayOfBoolean = new boolean[this.m_N];
    for (int i = 0; i < this.m_N; ++i)
      arrayOfBoolean[i] = false;
    i = 0;
    if ((i = FindUnchecked(arrayOfBoolean)) != -1)
    {
      localStringBuffer.append("(");
      int j = 1;
      while (true)
      {
        if (arrayOfBoolean[i] != 0);
        int k = fromI(i);
        if (j != 0)
          j = 0;
        else
          localStringBuffer.append("  ");
        if (k == this.m_SpecialInt)
          localStringBuffer.append(this.m_SpecialChar);
        else
          localStringBuffer.append(k);
        arrayOfBoolean[i] = true;
        i = fromV(this.m_Values[i]);
        if (arrayOfBoolean[i] != 0)
          localStringBuffer.append(") ");
      }
    }
    return localStringBuffer.toString();
  }

  private int FindUnchecked(boolean[] paramArrayOfBoolean)
  {
    int i;
    if (this.m_Mode == 2)
      for (i = 0; i < this.m_N; ++i)
        if (paramArrayOfBoolean[i] == 0)
          return i;
    else
      for (i = 1; i <= this.m_N; ++i)
      {
        if ((i < this.m_N) && (paramArrayOfBoolean[i] == 0))
          return i;
        if ((this.m_Mode != 1) && (i == this.m_N) && (paramArrayOfBoolean[0] == 0))
          return 0;
      }
    return -1;
  }

  private int fromI(int paramInt)
  {
    if (this.m_Mode == 2)
      return (paramInt + 1);
    return ((paramInt == 0) ? this.m_N : paramInt);
  }

  private int fromV(int paramInt)
  {
    if (this.m_Mode == 2)
      return (paramInt - 1);
    return ((paramInt == this.m_N) ? 0 : paramInt);
  }

  public Permutation Times(Permutation paramPermutation)
  {
    int[] arrayOfInt = new int[this.m_N];
    Permutation localPermutation = null;
    switch (this.m_Mode)
    {
    case 2:
      for (int i = 0; i < this.m_N; ++i)
        arrayOfInt[i] = paramPermutation.at(this.m_Values[i] - 1);
      localPermutation = new Permutation(this.m_N, arrayOfInt);
      localPermutation.getClass();
      localPermutation.SetMode(2);
      break;
    default:
      arrayOfInt = null;
    }
    return localPermutation;
  }

  public Permutation Conjugate(Permutation paramPermutation)
  {
    int[] arrayOfInt = new int[this.m_N];
    Permutation localPermutation = null;
    switch (this.m_Mode)
    {
    case 2:
      for (int i = 0; i < this.m_N; ++i)
        arrayOfInt[i] = paramPermutation.at(this.m_Values[(paramPermutation.InverseAt(i + 1) - 1)] - 1);
      localPermutation = new Permutation(this.m_N, arrayOfInt);
      localPermutation.getClass();
      localPermutation.SetMode(2);
      break;
    default:
      arrayOfInt = null;
    }
    return localPermutation;
  }
}