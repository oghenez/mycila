import java.math.BigInteger;

public class Combination
{
  private int[] a;
  private int n;
  private int r;
  private BigInteger numLeft;
  private BigInteger total;
  private static BigInteger[] Factorials;

  public static void PrepareFactorials(int paramInt)
  {
    Factorials = new BigInteger[paramInt + 1];
    Factorials[0] = BigInteger.ONE;
    for (int i = 1; i <= paramInt; ++i)
      Factorials[i] = Factorials[(i - 1)].multiply(new BigInteger(Integer.toString(i)));
  }

  static BigInteger GetFactorial(int paramInt)
  {
    return ((paramInt < Factorials.length) ? Factorials[paramInt] : Factorials[(Factorials.length - 1)]);
  }

  public Combination(int paramInt1, int paramInt2)
  {
    if (paramInt2 > paramInt1)
      throw new IllegalArgumentException();
    if (paramInt1 < 1)
      throw new IllegalArgumentException();
    this.n = paramInt1;
    this.r = paramInt2;
    this.a = new int[paramInt2];
    BigInteger localBigInteger1 = GetFactorial(paramInt1);
    BigInteger localBigInteger2 = GetFactorial(paramInt2);
    BigInteger localBigInteger3 = GetFactorial(paramInt1 - paramInt2);
    this.total = localBigInteger1.divide(localBigInteger2.multiply(localBigInteger3));
    reset();
  }

  public void reset()
  {
    for (int i = 0; i < this.a.length; ++i)
      this.a[i] = i;
    this.numLeft = new BigInteger(this.total.toString());
  }

  public BigInteger getNumLeft()
  {
    return this.numLeft;
  }

  public boolean hasMore()
  {
    return (this.numLeft.compareTo(BigInteger.ZERO) == 1);
  }

  public BigInteger getTotal()
  {
    return this.total;
  }

  private static BigInteger getFactorial(int paramInt)
  {
    BigInteger localBigInteger = BigInteger.ONE;
    for (int i = paramInt; i > 1; --i)
      localBigInteger = localBigInteger.multiply(new BigInteger(Integer.toString(i)));
    return localBigInteger;
  }

  public int[] getNext()
  {
    if (this.numLeft.equals(this.total))
    {
      this.numLeft = this.numLeft.subtract(BigInteger.ONE);
      return this.a;
    }
    for (int i = this.r - 1; this.a[i] == this.n - this.r + i; --i);
    this.a[i] += 1;
    for (int j = i + 1; j < this.r; ++j)
      this.a[j] = (this.a[i] + j - i);
    this.numLeft = this.numLeft.subtract(BigInteger.ONE);
    return this.a;
  }
}