class CTKIntValue
{
  int m_Value;

  public CTKIntValue(int paramInt)
  {
    this.m_Value = paramInt;
  }

  public CTKIntValue Add(int paramInt)
  {
    this.m_Value += paramInt;
    return this;
  }

  public CTKIntValue SetValue(int paramInt)
  {
    this.m_Value = paramInt;
    return this;
  }

  public int IntValue()
  {
    return this.m_Value;
  }

  public int GetValue()
  {
    return this.m_Value;
  }

  public String toString()
  {
    return "" + this.m_Value;
  }
}