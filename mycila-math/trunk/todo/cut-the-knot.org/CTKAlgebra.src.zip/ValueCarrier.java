abstract interface ValueCarrier
{
  public abstract void SetValue(int paramInt);

  public abstract void repaint();
}