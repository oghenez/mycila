import java.util.Vector;

class SG
{
  static int Mex(Vector paramVector)
  {
    int[] arrayOfInt = new int[paramVector.size()];
    for (int i = 0; i < arrayOfInt.length; ++i)
      arrayOfInt[i] = ((Integer)paramVector.elementAt(i)).intValue();
    Sort.QuickSort(arrayOfInt, 0, arrayOfInt.length - 1);
    i = Math.min(arrayOfInt[0], 0);
    for (int j = 0; j < arrayOfInt.length; ++j)
    {
      if ((j > 0) && (arrayOfInt[j] == arrayOfInt[(j - 1)]))
        break label91:
      if (arrayOfInt[j] > i)
        break;
      label91: ++i;
    }
    return i;
  }

  static int Mex(int[] paramArrayOfInt)
  {
    Sort.QuickSort(paramArrayOfInt, 0, paramArrayOfInt.length - 1);
    int i = Math.min(paramArrayOfInt[0], 0);
    for (int j = 0; j < paramArrayOfInt.length; ++j)
    {
      if ((j > 0) && (paramArrayOfInt[j] == paramArrayOfInt[(j - 1)]))
        break label56:
      if (paramArrayOfInt[j] > i)
        break;
      label56: ++i;
    }
    return i;
  }
}