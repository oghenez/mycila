class CTKRational
{
  int n;
  int d;

  public CTKRational(int paramInt1, int paramInt2)
  {
    if (paramInt2 < 0)
    {
      this.n = (-paramInt1);
      this.d = (-paramInt2);
    }
    else
    {
      this.n = paramInt1;
      this.d = paramInt2;
    }
  }

  public CTKRational(int paramInt)
  {
    this.n = paramInt;
    this.d = 1;
  }

  public CTKRational Plus(CTKRational paramCTKRational)
  {
    return new CTKRational(this.n * paramCTKRational.d + this.d * paramCTKRational.n, this.d * paramCTKRational.d);
  }

  public CTKRational Minus(CTKRational paramCTKRational)
  {
    return new CTKRational(this.n * paramCTKRational.d - this.d * paramCTKRational.n, this.d * paramCTKRational.d);
  }

  public CTKRational Times(CTKRational paramCTKRational)
  {
    return new CTKRational(this.n * paramCTKRational.n, this.d * paramCTKRational.d);
  }

  public CTKRational Over(CTKRational paramCTKRational)
  {
    return new CTKRational(this.n * paramCTKRational.d, this.d * paramCTKRational.n);
  }

  public String toString()
  {
    int i = gcd(this.n, this.d);
    if (i < 0)
      i = -i;
    if (i == 0)
      return "0";
    StringBuffer localStringBuffer = new StringBuffer();
    if (i == this.d)
      localStringBuffer.append(this.n / this.d);
    else
      localStringBuffer.append(this.n / i).append("/").append(this.d / i);
    return localStringBuffer.toString();
  }

  private static int gcd(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
      return paramInt1;
    return gcd(paramInt2, paramInt1 % paramInt2);
  }

  public double Value()
  {
    if (this.d != 0)
      return (this.n / this.d);
    return 0D;
  }
}