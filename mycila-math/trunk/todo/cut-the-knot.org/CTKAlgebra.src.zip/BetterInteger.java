class BetterInteger
{
  int Value;

  public int GetIntValue()
  {
    return this.Value;
  }

  public int Add(int paramInt)
  {
    this.Value += paramInt;
    return this.Value;
  }

  public void Set(int paramInt)
  {
    this.Value = paramInt;
  }

  public BetterInteger(int paramInt)
  {
    this.Value = paramInt;
  }
}