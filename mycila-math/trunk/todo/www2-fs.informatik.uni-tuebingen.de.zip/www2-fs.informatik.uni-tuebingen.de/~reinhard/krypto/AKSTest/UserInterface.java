import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.math.*;

public class UserInterface extends Applet implements ActionListener{


   //************************************************************************
   // Erstellen des Applets
   //************************************************************************

   static TextArea ausgabeFeld = new TextArea();
   TextField eingabeFeld = new TextField(20);
   Label labelEingabeFeld = new Label("Bitte zu testende Zahl eingeben : ");	
   Button startePrimzahlTest = new Button("Start");
   Button primzahlTestAbbrechen = new Button("Stop");
  

   public void init() {
      super.init();
	  setLayout(new BorderLayout());
	  eingabeFeld.addActionListener(this);
	  startePrimzahlTest.addActionListener(this);
	  primzahlTestAbbrechen.addActionListener(this);
	  Panel eingabeLeiste = new Panel(new FlowLayout(FlowLayout.LEFT)); 	
	  eingabeLeiste.add(labelEingabeFeld);
	  eingabeLeiste.add(eingabeFeld); 
	  eingabeLeiste.add(startePrimzahlTest); 
      eingabeLeiste.add(primzahlTestAbbrechen);
      add(eingabeLeiste, BorderLayout.NORTH);
	  add(ausgabeFeld, BorderLayout.CENTER);
	  setVisible(true);   
   }

   //*************************************************************************
   //EventHandling:Es werden nur Actionevent benutzt
   //*************************************************************************

   public void actionPerformed(ActionEvent e) {
        BigInteger zuTestendeZahl = new BigInteger("0");
		
		AKSTest aksTest = new AKSTest();
		Thread t = new Thread(aksTest);
		
        if(e.getSource() == eingabeFeld) 
		  if(aksTest.getRunFlag() == false && aksTest.getToWait() == false){
		   ausgabeFeld.setText("");
	       String s = new String(eingabeFeld.getText());
		   try{
		      zuTestendeZahl = new BigInteger(s);
              aksTest.setN(zuTestendeZahl.abs());
			  t.start();
		   }catch(NumberFormatException nfe){
		      ausgabeFeld.setText("geben sie bitte eine Zahl ein");
		      eingabeFeld.setText("");        
            }
	    }    
		 
	    if(e.getSource()== startePrimzahlTest)
		  if(aksTest.getRunFlag() == false && aksTest.getToWait() == false){
		  ausgabeFeld.setText("");
	       String s = new String(eingabeFeld.getText());
		   try{
		      zuTestendeZahl = new BigInteger(s);
              aksTest.setN(zuTestendeZahl.abs());
			     t.start();
		   }catch(NumberFormatException nfe){
		      ausgabeFeld.setText("geben sie bitte eine Zahl ein");
		      eingabeFeld.setText("");        
		    }
		}
		
		if(e.getSource()== primzahlTestAbbrechen) {
		   if(aksTest.getRunFlag() == true ){  
		     aksTest.setRunFlag(false);
		     aksTest.setToWait(true);
		     ausgabeFeld.append("Bitte warten ... ");
                                 ausgabeFeld.repaint();   
		   }
	    }   
   }
  
  
}