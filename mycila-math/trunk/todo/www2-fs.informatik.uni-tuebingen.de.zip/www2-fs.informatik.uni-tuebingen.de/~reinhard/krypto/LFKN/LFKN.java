import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Random;

/**
 * demo applet LFKN protocol 
 *
 * @author   Holger Schmid
 * @version  23.02.2000
 */
public class LFKN extends Applet implements ActionListener
{
   int step=1;        // counter for steps (=button clicks)
   Matrix M;          // input matrix
   final int sizeM=3; // size of M (#rows)
   Vector subM = new Vector(); // submatrices of M (build by Merlin)
	Vector perSubM = new Vector(); // permanents of subM
	PolynomMatrix D;   // new matrix (build by Arthur)
	Polynom perD;      // permanent of D
   Random rnd = new Random(); // random number generator
   int repl1, repl2;  // randomly selected submatrices
	int N;             // limit for r
	
	// declaration of GUI components
	Panel TopPanel = new Panel();
	Panel InputPanel = new Panel();
	Panel MerlinPanel = new Panel();
	Panel ArthurPanel = new Panel();
	Panel ActionPanel = new Panel();
		
   Label InputLabel = new Label("Input matrix");
	Label MerlinLabel = new Label("Merlin");
	Label ArthurLabel = new Label("Arthur");
	Label NLabel = new Label("   N");

   TextField M00 = new TextField("23");
	TextField M01 = new TextField("19");
   TextField M02 = new TextField("17");
   TextField M10 = new TextField("13");
   TextField M11 = new TextField("11");
   TextField M12 = new TextField("7");
   TextField M20 = new TextField("5");
   TextField M21 = new TextField("3");
   TextField M22 = new TextField("2");
   
	TextField NTextField = new TextField("10");
	
	TextArea MerlinTA = new TextArea("",20,40, java.awt.TextArea.SCROLLBARS_VERTICAL_ONLY);
	TextArea ArthurTA = new TextArea("",20,40, java.awt.TextArea.SCROLLBARS_VERTICAL_ONLY);

	Button goButton = new Button("Next step");
	Button resetButton = new Button("Reset");
	Button summaryButton = new Button("Next summary");
	
   public void init()
   {
   	// set layout
      setLayout (new BorderLayout());
   	InputPanel.setLayout(new GridLayout(3, 3));
   	MerlinPanel.setLayout(new FlowLayout(java.awt.FlowLayout.LEFT));
   	ArthurPanel.setLayout(new FlowLayout(java.awt.FlowLayout.LEFT));
   	
      // add components
   	add("North", TopPanel);
   	add("West", ArthurPanel);
   	add("Center", MerlinPanel);
   	add("South", ActionPanel);
   	
   	TopPanel.add(InputLabel);
   	TopPanel.add(InputPanel);
   	TopPanel.add(NLabel);
   	TopPanel.add(NTextField);

   	InputPanel.add(M00);
   	InputPanel.add(M01);
      InputPanel.add(M02);
      InputPanel.add(M10);
      InputPanel.add(M11);
      InputPanel.add(M12);
      InputPanel.add(M20);
      InputPanel.add(M21);
      InputPanel.add(M22);

   	ArthurPanel.add(ArthurLabel);
   	ArthurPanel.add(ArthurTA);
   	MerlinPanel.add(MerlinLabel);
      MerlinPanel.add(MerlinTA);
   	
   	ActionPanel.add(goButton);
   	ActionPanel.add(summaryButton);
   	ActionPanel.add(resetButton);

      // Aktionen festlegen
      goButton.addActionListener(this);
   	summaryButton.addActionListener(this);
   	resetButton.addActionListener(this);

   	doLayout();
   return;
   }//init

   public void actionPerformed(ActionEvent evt)
   {
      boolean singleStep;
   	TextArea outputM, outputA;
   	
      if (evt.getActionCommand() == goButton.getLabel())
      {
      	singleStep = true;
      	outputA = ArthurTA;
      	outputM = MerlinTA;
      }
   	else
      {
         singleStep = false;
      	outputA = outputM = null;
      }
   		
      if ((evt.getActionCommand() == summaryButton.getLabel()) | (evt.getActionCommand() == goButton.getLabel()))
      {// big step
         if (step==1)
         {
      	   // read values from input fields
            if (!readInputData(outputA))
            {
               ArthurTA.setText("Input data error");
            	return;
            }
         	step++;
         	if (singleStep) return;
         }
      	if (step==2)
         {
            MerlinBuildSubmatrices(outputM);
         	step++;
         	if (singleStep) return;
         }
      	if (step==3)
         {
            ArthurSelect2Matrices(outputA);
         	step++;
         	if (singleStep) return;
         }
         if (step==4)
         {
            MerlinComputePermanentD(outputM);
         	step++;
         	if (singleStep) return;
         }
      	if (step==5)
         {
            boolean truth = ArthurTestIfMerlinLied(outputA);
         	ArthurTA.append("### summary ###\n matrix size: "+M.getRows()+"\n sub matrices: "+subM.size()+"\n");
         	if (!truth)
            {// Merlin lied
               ArthurTA.append(" Merlin lied.\n");
            }
            else
            {
         	   ArthurTA.append(" Merlin said the truth.\n\n");
            }
         	//ArthurTA.append("===========================\n\n");
         	step++;
         	if (singleStep) return;
         }
         if (step==6)
         {
            ArthurReplace2Matrices (outputA);
            if (subM.size()>1)
            {// proceed until only one submatrix left
               step=3;
            }
            else
            {// reduce matrix size
               if (((Matrix)subM.elementAt(0)).getRows()>1)
               {
                  ArthurReduceMatrixSize(outputA);
               	step=2;
               }
               else
               {
                  step=7;//ready
               }
            }
         	if (singleStep) return;
         }
      	if (step>=7)
         {
         	ArthurTA.append("\nReady");
            step++;
         	if (singleStep) return;
         }
      	return;
      }

      if (evt.getActionCommand() == resetButton.getLabel())
      {//reset
         step=1;
         // clear display
         ArthurTA.setText("");
         MerlinTA.setText("");
      	D = null;
      	perD = null;
         subM = new Vector();
         perSubM = new Vector();
      	return;
      }
      return;
   }

   /** Reads the values from the input matrix and the N value
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    *  @return  true      all values read
    *           false     error while reading values
    */
   private boolean readInputData(TextArea outputTA)
   {
      M = new Matrix(sizeM, sizeM);
      try
      {
         N = Integer.valueOf(NTextField.getText()).intValue();
         M.setElement(0, 0, (Double.valueOf(M00.getText()).doubleValue()));
         M.setElement(0, 1, (Double.valueOf(M01.getText()).doubleValue()));
         M.setElement(0, 2, (Double.valueOf(M02.getText()).doubleValue()));
         M.setElement(1, 0, (Double.valueOf(M10.getText()).doubleValue()));
         M.setElement(1, 1, (Double.valueOf(M11.getText()).doubleValue()));
         M.setElement(1, 2, (Double.valueOf(M12.getText()).doubleValue()));               
      	M.setElement(2, 0, (Double.valueOf(M20.getText()).doubleValue()));
         M.setElement(2, 1, (Double.valueOf(M21.getText()).doubleValue()));
         M.setElement(2, 2, (Double.valueOf(M22.getText()).doubleValue()));
         if (outputTA != null)
         {
      	   outputTA.append("*** input matrix M ***\n");
            outputTA.append(M.toString());
         	outputTA.append("N = "+N+"\n\n");
            //outputTA.append("------------------------\n");
         }
      	return true;
      }
      catch (NumberFormatException e)
      {
         if (outputTA != null)
         {
            outputTA.setText("input data error\n");
         }
      	return false;
      }
   }

   /** Merlin: Builds submatrices and computes their permanents
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    */
	private void MerlinBuildSubmatrices(TextArea outputTA)
      {
   	int size;
   	
   	if (subM.size() == 0)
         {// no submatrices exist -> init with size of input matrix
      	outputTA.append("*** building permanent ***\n");
         outputTA.append("per M = "+M.getPermanent()+"\n\n");
      	size = M.getRows();
         }
   	else
         {// in all other cases use # of submatrices
      	size = subM.size();
         }
      if (outputTA != null)
         {
      	outputTA.append("*** building submatrices M[0] to M["+(size-1)+"]\n");
         }
      for (int i=0; i<size; i++)
      {
         subM.addElement(M.subMatrix(0,i));
      	perSubM.addElement(new Double(((Matrix)subM.elementAt(i)).getPermanent()));
         if (outputTA != null)
         {// print results
      	   outputTA.append("M["+i+"]\n");
            outputTA.append(subM.elementAt(i).toString());
            outputTA.append("per M["+i+"] = "+formatOutput(perSubM.elementAt(i))+"\n");
            if (i<size-1)
            {
               outputTA.append("------------------------\n");
            }
         	else
            {
               outputTA.append("\n");
            }
         }
      }
   	return;
   }

   /** Arthur: Select 2 of the submatrices and build new matrix D = x*M[i]+(1-x)M[j]
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    */
	private void ArthurSelect2Matrices(TextArea outputTA)
   {
      if (M.getColumns() == subM.size())
         {
         // on first pass:
         // check if permanents of submatrices are correct
         outputTA.append("*** checking permanents of submatrices***\n");
         outputTA.append("per M = " + M.getPermanent() + " =\n");
         double tempSum = 0;
         int i;
         for (i=0; i<M.getColumns()-1; i++)
            {
            outputTA.append(M.getElement(0,i)+"*"+perSubM.elementAt(i)+" + ");
            tempSum += M.getElement(0,i) * ((Double)perSubM.elementAt(i)).doubleValue();
            }
         outputTA.append(M.getElement(0,i)+"*"+perSubM.elementAt(i));
         tempSum += M.getElement(0,i) * ((Double)perSubM.elementAt(i)).doubleValue();
         if (M.getPermanent() == tempSum)
            {
            outputTA.append(" -> OK\n\n");
            }
         else
            {
            outputTA.append(" -> not OK\n\n");
            }
         }
   
      // select random matrix
   	repl1 = -1;
      while (repl1<0)
      {   
         repl1 = rnd.nextInt()%subM.size();
      }
      repl2 = -1;
      while (repl1==repl2 | repl2<0)
      {
         repl2 = rnd.nextInt()%subM.size(); 
      }
   	// build new matrix D = x*M[i]+(1-x)M[j] = x*M[i]+M[j]-x*M[j]
      D = new PolynomMatrix((Matrix)subM.elementAt(repl1));
      PolynomMatrix tempD = new PolynomMatrix((Matrix)subM.elementAt(repl2));
      D.mulX(1);
      D.add(tempD);
      tempD.mulX(1);
      tempD.changeSign();
      D.add(tempD);
   	if (outputTA != null)
      {// print results
      	outputTA.append("*** select two submatrices ***\n");
      	outputTA.append("choose random: i = "+repl1+",  j = "+repl2+"\n");
         outputTA.append("building matrix D = x*M["+repl1+"] + (1-x)*M["+repl2+"]\n");
         outputTA.append(D.toString()+"\n");
         //outputTA.append("------------------------\n");
      }
   	return;
   }

   /** Merlin: Compute Permanent d(x) = per D
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    */
	private void MerlinComputePermanentD(TextArea outputTA)
   {
      perD = D.getPermanent();
      if (outputTA != null)
      {// print results
         outputTA.append("*** building permanent ***\n");
      	outputTA.append("d(x) = per D = "+perD+"\n\n");
         //outputTA.append("------------------------\n");
      }
   	return;
   }

   /** Arthur: check d(0) and d(1) 
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    *  @return  true      Merlin was right
    *           false     Merlin lied
    */
   private boolean ArthurTestIfMerlinLied (TextArea outputTA) 
   {
      double d0, d1;
   	boolean OkD0 = true, OkD1 = true;
   	
      perD.setX(0);
      d0 = perD.calculateValue();
      perD.setX(1);
      d1 = perD.calculateValue();
      if (d0 != ((Double)perSubM.elementAt(repl2)).doubleValue())
      {// wrong d0
      	OkD0 = false;
      }
      if (d1 != ((Double)perSubM.elementAt(repl1)).doubleValue())
      {// wrong d1
         OkD1 = false;
      }
   	if (outputTA != null)
      {// print results
   	   outputTA.append("*** check if Merlin lied ***\n");
         if (OkD0)
         {
            outputTA.append("d(0) = per M["+repl2+"] = "+formatOutput(d0)+ "   -> OK\n");
         }
         else
         {
            outputTA.append("d(0) = "+d0+" != per M["+repl2+"] = "+formatOutput(perSubM.elementAt(repl2))+"   -> not OK\n");
         }
         if (OkD1)
         {
            outputTA.append("d(1) = per M["+repl1+"] = "+formatOutput(d1)+ "   -> OK\n");
         }
         else
         {
            outputTA.append("d(1) = "+d1+" != per M["+repl1+"] = "+formatOutput(perSubM.elementAt(repl1))+"   -> not OK\n");
         }
         outputTA.append("\n");
      }
      return (OkD0 & OkD1);
   }

   /** Arthur: Replace the previously select matrices
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    */
   private void ArthurReplace2Matrices (TextArea outputTA) 
   {
   	// choose random r<N
      double r = rnd.nextInt()%N;
      if (r<0) r*=-1; // no negative values
      D.setX(r);
      // append new matrix to submatrices   	
   	Matrix newM = D.buildMatrix();
   	subM.addElement(newM);
      perSubM.addElement(new Double(newM.getPermanent()));
      // remove the 2 old matrices
   	subM.removeElementAt(repl1);
   	subM.removeElementAt(repl2);
      perSubM.removeElementAt(repl1);
      perSubM.removeElementAt(repl2);
   	
   	if (outputTA != null)
      {// print results
         outputTA.append("*** replace two submatrices ***\n");
      	outputTA.append("replace M["+repl1+"] and M["+repl2+"] by M' = D(r)\n");
         outputTA.append("chosse random r = "+r+"\n");
         outputTA.append(newM.toString());
         outputTA.append("per M' = "+newM.getPermanent()+"\n\n");
         //outputTA.append("------------------------\n");
      }
   }

   /** Arthur: Replace the matrix M by the last left submatrix (reduce size by one)
    *  @param   outputTA  The TextArea where the results will be printed. If <code>outputTA</code>
    *                     is <code>null</code> nothing will be printed.
    */
	private void ArthurReduceMatrixSize (TextArea outputTA)
   {
      M = (Matrix)subM.elementAt(0);
      subM = new Vector();
      perSubM = new Vector();
   	if (outputTA != null)
      {
         outputTA.append("*** reduce matrix size ***\n");
         outputTA.append("new M = M[0]\n\n");
      }
   	return;
   }

   /** Formats a double value for output
    *  @result   the formated value as string
    *  @param    x   the double value to format
    */
   private String formatOutput(double x)
   {
      Integer temp = new Integer((int) x);
      return temp.toString();
   }
   private String formatOutput(Object x)
   {
      Integer temp = new Integer(((Double)x).intValue());
      return temp.toString();
   }
}