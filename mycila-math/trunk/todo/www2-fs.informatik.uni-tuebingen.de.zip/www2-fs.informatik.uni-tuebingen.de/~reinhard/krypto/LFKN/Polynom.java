import java.util.Vector;

/**
 *  This class implements a polynom. It's always in standard form a0 + a1*x + a2*x^2 + ... + an*x^n <br>
 *  Only the coefficients are stored, in an increasing order starting with index 0. This means, 
 *  that the value at index 0 is the constant, index 1 belongs to x, index 2 to x^2 and so on. <br>
 *
 * @author   Holger Schmid
 * @version  12.07.99
 */
public class Polynom 
{
	double x=0; // the polynom variable
   int n=-1; // maximum index in polynom
   Vector P; // coefficients
   
   /** Constructs an empty polynom.
    */
   public Polynom()
   {
      P = new Vector();
      return;
   }
   
	/** Constructs a new polynom by copying another one
	 *  @param   pol   the polynom to copy
	 */
   public Polynom(Polynom pol)
   {
      P = new Vector();
   	n = pol.getMaxIndex();
   	x = 0;
   	for (int i=0; i<=n; i++)
      {
      	P.addElement(new Double(pol.getCoefficient(i)));
      }
   	return;
   }
   
	/** Sets the value of the polynom variable of this polynom to <code>x</code>. Default is 0.
	 *  @param   x   value to be set
	 */
	public void setX (double x)
   {
   	this.x = x;
   	return;
   }
	
   /** Gets the value of the polynom variable x
    *  @return   the current value of x
    */
   public double getX ()
   {
      return x;
   }

	/** Calcuates the value of the hole polynom, using the current value of the polynom variable x.
	 *  @return   the value of the polynom
	 */
	public double calculateValue()
   {
      double result=0;
   	for (int i=n; i>0; i--)
      {
      	result += ((Double)P.elementAt(i)).doubleValue();
      	result *= x;
      }
   	result += ((Double)P.elementAt(0)).doubleValue();
   	return result;
   }
	 
	/** Returns the value of the coefficient at <code>index</code>. <br>
    *  @return  value of the coefficient
    *  @param   index    the index of the coefficient to be read
    *  @exception   RuntimeException   "Index out of bound". The given index is less than zero
    *     or larger than index of the last coefficient in this polynom or the polynom is empty.
    */
   public double getCoefficient(int index)
   {
      if ((index>n) | (index<0))
      {// index out of bounds
         throw new RuntimeException("Index out of bound.");
      }
      else
      {
         return ((Double)P.elementAt(index)).doubleValue();
      }
   }
   
   /** Sets the coefficient at <code>index</code> to <code>value</code>. If the coefficient allready exists
    *  its value is replaced. If <code>index</code> is greater then the maximum index of the polynom,
    *  the value is written to the correct position and the values between the old maximum index 
    *  and <code>index</code> are set to 0. 
    *  @param   index    the index of the coefficient to be set
    *  @param   value    the value of the coefficient to be set
    *  @exception   RuntimeException   "Index out of bound". The given index is less than zero.
    */
   public void setCoefficient(int index, double value)
   {
      if (index<0)
      {// index out of bounds
         throw new RuntimeException("Index out of bound.");
      }
      else
      {
         if (index>n)
         {// add value
            for (int i=n+1; i<index; i++)
            {// insert elements with value 0
               P.addElement(new Double(0));
               n++;
            }
            P.addElement(new Double(value));
            n++;
         }
         else
         {// replace value
            P.setElementAt(new Double(value), index);
         }
      return;
      }
   }

   /** Returns the largerst coefficient index <br>
    *  @return   index of largest coefficient in this polynom
    *  @exception   RuntimeException   "Polynom is empty".
    */
   public int getMaxIndex()
   {
      if (n<0)
      {
         throw new RuntimeException("Polynom is empty.");
      }
   	else
      {
   	   return n;
      }
   }
         
   /** Returns a string representation of the polynom. The string consists of the coefficient 
    *  values, seperated by tabs.
    *  @return   a string with the values of the coefficients
    */
   public String toString()
   {
      String result="";
      
      for (int i=0; i<=n-1; i++)
      {
         result+=(formatOutput(P.elementAt(i))+"*x^"+i+" + ");
      }
   	result+=(formatOutput(P.elementAt(n))+"*x^"+n);
      return result;
   }

	/** Multiplies all coefficients of this polynom with -1
    */
   public void changeSign()
   {
      for (int i=0; i<=n; i++)
      {
         setCoefficient(i, (-1)*getCoefficient(i));
      }
      return;
   }

	/** Multiplies this polynom with x^<code>exp</code><br>
    *  @param   exp   the exponent of x   
    */
   public void mulX(int exp)
   {
   	for (int i=0; i<exp; i++)
      {
      	P.insertElementAt(new Double(0), 0);
      	n++;
      }
   	return;
   }
	
   /** Adds the specified polynom <code>pol</code> to this polynom.
    *  @param   pol    the polynom to add to this polynom
    */
   public void add(Polynom pol)
   {
      int i;      
      int polSize = pol.getMaxIndex();
      
      if (polSize > n)
      {// added polynom is larger
      for (i=0; i<=n; i++)
         {// add coefficients at same index
            P.setElementAt(new Double(pol.getCoefficient(i)+((Double)P.elementAt(i)).doubleValue()), i);
         }
      for (i=n+1; i<=polSize; i++)
         {// append additional coefficients
            P.addElement(new Double(pol.getCoefficient(i)));
         }
      n=polSize;
      }
      else
      {// added polynom is of less or equal size
      for (i=0; i<=polSize; i++)
         {
            P.setElementAt(new Double(pol.getCoefficient(i)+((Double)P.elementAt(i)).doubleValue()), i);
         }
      }
      return;
   }

  /** Multiplies this polynom with with the specified polynom <code>pol</code>.
   *  @param   pol    the polynom to multiply this polynom with
   */
   public void mul(Polynom pol)
   {
      int p; // result coefficient index 
      int iMax, jMax; // max index of coefficients
      int i, j;
      
      iMax = n;
      jMax = pol.getMaxIndex();
   	double result[] = new double[iMax+jMax+1]  ; // temp results 
   	
      for (p=0; p<=iMax+jMax; p++)
      {// loop over all result coefficients
         result[p]=0;
         for (i=max(0, p-jMax), j=p-i; i<=min(p, iMax); i++, j--)
         {
            result[p] += ((Double)(P.elementAt(i))).doubleValue()*pol.getCoefficient(j);
         }
      }

   	for (p=0; p<=iMax+jMax; p++)
      {// copy result into this polynom
         if (p<=n)
         {
            P.setElementAt(new Double(result[p]), p);
         }
         else
         {
            P.addElement(new Double(result[p]));
            n++;
         }
      }
   }
   
   // return maximum of two int values
   int max(int a, int b)
   {
      if (a>b)
         return a;
      else
         return b;
   }
   
   // return minimum of two int values
   int min(int a, int b)
   {
      if (a<b)
         return a;
      else
         return b;
   }
      
   /** Formats a double value for output
    *  @result   the formated value as string
    *  @param    x   the double value to format
    */
   private String formatOutput(double x)
   {
      Integer temp = new Integer((int) x);
      return temp.toString();
   }
   private String formatOutput(Object x)
   {
      Integer temp = new Integer(((Double)x).intValue());
      return temp.toString();
   }

}//class Polynom