/**
 * This class implements a nxm matrix. The matrix elements are polynoms.
 *
 * @author   Holger Schmid
 * @version  12.07.99
 */
public class PolynomMatrix
{
   int n, m;     // number of rows and columns in matrix
   Polynom M[][]; // matrix values
   
   /** Constructs an empty nxm matrix.
    *  @param   rows   number of rows
    *  @param   columns   number of columns
    */
   public PolynomMatrix(int rows, int columns)
   {
      n = rows;
      m = columns;
      M = new Polynom[n][m];
      return;
   }
   
   /** Constructs a new polynom matrix by copying an ordinary matrix
   /*  @param   mat   the matrix to be copyied
    */
   public PolynomMatrix(Matrix mat)
   {
      int i, j;
      
      n = mat.getRows();
      m = mat.getColumns();
      M = new Polynom[n][m];
      
      for (i=0; i<n; i++)
      {
         for (j=0; j<m; j++)
         {
         	// the matrix elements are the polynom constants
         	M[i][j] = new Polynom();
            M[i][j].setCoefficient(0, mat.getElement(i, j));
         }
      }
      return;
   }
 
   /** Returns the number of rows of the matrix
    *  @return   number of rows
    */
   public int getRows()
   {
      return n;
   }
      
   /** Returns the number of columns of the matrix
    *  @return   number of columns
    */
   public int getColumns()
   {
      return m;
   }

   /** Returns the polynom at the specified matrix position
    *  @param   row   row of element
    *  @param   column   column of element
    */
   public Polynom getElement(int row, int column)
   {
      return M[row][column];
   }
   
   /** Sets the value of a matrix element.
    *  @param   row   row of element
    *  @param   column   column of element
    *  @param   pol   polynom to be set
    */
   public void setElement(int row, int column, Polynom pol)
   {
      M[row][column]=pol;
      return;
   }

	/** Returns a string represantation of the matrix. The string consists of the 
    *  matrix element values, seperated by tabs. The rows of the matrix are seperated
    *  by newlines.
    *  @return   a string with the values of the matrix
    */
   public String toString()
   {
      String result="";
      int i, j;
      for (i=0; i<n; i++)
      {//rows
         for (j=0; j<m; j++)
         {//columns
            result+=(M[i][j]+"\t");
         }
         result+="\n";
      }
      return result;
   }
   
   /** Exchanges two rows of the matrix.
    *  @param   row1   the one row to be exchanged
    *  @param   row2   the other row to be exchanged
    */
   public void exchangeRows(int row1, int row2)
   {
      int i;
      Polynom temp;
      for (i=0; i<m; i++)
      {
         temp=M[row1][i];
         M[row1][i]=M[row2][i];
         M[row2][i]=temp;
      }
      return;
   }

   /** Calculates the determinant of the matrix
    *  @exception   RuntimeException   "Not a square matrix". Determinants can only be calculated
    *     on square matrices.
    *  @return   the determinant of the matrix
    */
   public Polynom getDeterminant() 
   {
      int i;
      Polynom d = new Polynom();
      double sign=1;
      PolynomMatrix tempM;
   	Polynom tempP1, tempP2;

      if (n==m)
      {// only square matrices possible
         if (n==1)
         {
            return M[0][0];
         }
         else
         {// recursion on first row
            for (i=0; i<m; i++)
            {
               tempM = subMatrix(0,i);
            	tempP1 = new Polynom(M[0][i]);
            	tempP2 = tempM.getDeterminant();
            	tempP1.mul(tempP2);
               tempP2 = new Polynom();
            	tempP2.setCoefficient(0, sign);
            	tempP1.mul(tempP2);
               sign *= -1; // swap sign
            	d.add(tempP1);
            }
         }
         return d;
      }
      else
      {
         throw new RuntimeException("PolynomMatrix.getDeterminant: Not a square matrix.");
      }
   }
   
   /** Calculates the permanent of the matrix
    *  @exception   RuntimeException   "Not a square matrix". Permanents can only be calculated
    *     on square matrices.
    *  @return   the permanent of the matrix
    */
   public Polynom getPermanent()
   {
      int i;
      Polynom p = new Polynom();
      PolynomMatrix tempM;
      Polynom tempP1, tempP2;

      if (n==m)
      {// only square matrices possible
         if (n==1)
         {// abort recursion
            return M[0][0];
         }
         else
         {// recursion on first row
            for (i=0; i<m; i++)
            {
               tempM  = subMatrix(0,i);
               tempP1 = new Polynom(M[0][i]);
               tempP2 = tempM.getPermanent();
            	tempP1.mul(tempP2);
            	p.add(tempP1);
            }
         }
         return p;
      }
      else
      {
         throw new RuntimeException("PolynomMatrix.getPermanent: Not a square matrix.");
      }
   }
   
  /** Multiplies all polynoms in this matrix with x^<code>exp</code><br>
    *  @param   exp   the exponent of x
    */
   public void mulX(int exp)
   {
      for (int i=0; i<n; i++)
      {
      	for (int j=0; j<m; j++)
         {
            M[i][j].mulX(exp);
         }
      }
      return;
   }

   /** Sets the value of the polynom variable of all polynoms in this matrix to <code>x</code>.
    *  @param   x   value to be set
    */
   public void setX (double x)
   {
      for (int i=0; i<n; i++)
      {
         for (int j=0; j<m; j++)
         {
            M[i][j].setX(x);
         }
      }
      return;
   }

	/** Multiplies all polynoms in this matrix with -1
    */
   public void changeSign()
   {
      for (int i=0; i<n; i++)
      {
         for (int j=0; j<m; j++)
         {
            M[i][j].changeSign();
         }
      }
      return;
   }
   
	/** Builds a matrix by calculating all polynoms.
	 *  Use the <code>setX</code> first to set the variable of the polynoms.
	 *  @return   the build matrix
	 */
	public Matrix buildMatrix()
   {
   	Matrix tempM = new Matrix(n, m);
      for (int i=0; i<n; i++)
      {
         for (int j=0; j<m; j++)
         {
            tempM.setElement(i, j, M[i][j].calculateValue());
         }
      }
      return tempM;
   }
	
   /** Adds the specified matrix <code>mat</code> to this matrix.
    *  @param   mat    the matrix to add to this one
    */
	public void add (PolynomMatrix mat)
   {
      int i, j;
   	
   	if ((m!=mat.getRows()) | (n!=mat.getColumns()))
      {
      	throw new RuntimeException("PolynomMatrix.add: Diffrent size");
      }
   	else
      {
   	   for (i=0; i<n; i++)
         {
      	   for (j=0; j<m; j++)
            {
         	   M[i][j].add(mat.getElement(i, j));
            }
         }
      }
   	return;
   }
	
   /** Builds a submatrix by deleting one row and one column.
    *  @result  the new matrix
    *  @param   row   row to be eliminated
    *  @param   column   column to be eliminated
    */
   public PolynomMatrix subMatrix (int row, int column)
   {
      int nR, nW, mR, mW;
      PolynomMatrix subM = new PolynomMatrix (n-1, m-1);
      
      for (nR=0, nW=0; nR<n; nR++)
      {// loop over all rows
         if (nR!=row)
         {// ignore the row to be deleted
            for (mR=0, mW=0; mR<m; mR++)
            {// loop over all columns
               if (mR!=column)
               {// ignore column to be deleted
                  subM.setElement(nW, mW, M[nR][mR]);
                  mW++;
               }
            }
            nW++;
         }
      }
      return subM;
   }           
}