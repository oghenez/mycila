package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/Des.java (Des Cipher)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Des extends Applet implements ActionListener {
   TextField plainfield, keyfield, cipherfield, IPofXfield;
   Button ButtonEncrypt;
   TextArea plainBinArea;
   TextArea roundsArea;
   //   String newline = System.getProperty("line.separator");

   //Layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("plaintext")+" x:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(plainfield = new TextField(getParameter("plaintext"), 20), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(ButtonEncrypt = new Button(getParameter("encrypt")), c);
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("key")+" s:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(keyfield = new TextField("01010101010101010101010101010101010101010101010101010101", 56), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("plaintext")+ " x ="), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      add(new Label(" x " + getParameter("binary") + " ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2; c.gridheight = 2;
      //      c.fill = GridBagConstraints.HORIZONTAL;
      add(plainBinArea = new TextArea("", 2, 65, TextArea.SCROLLBARS_NONE), c);
      plainBinArea.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 5; c.anchor = GridBagConstraints.WEST;
      add(new Label("IP(x)=L[0]R[0] ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 5; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;// c.fill = GridBagConstraints.HORIZONTAL;
      add(IPofXfield = new TextField(69), c);
      
      IPofXfield.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 6; c.anchor = GridBagConstraints.WEST;
      add(new Label("L[i]R[i] ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 6; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(roundsArea = new TextArea("", 2, 70, TextArea.SCROLLBARS_VERTICAL_ONLY), c);
      roundsArea.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 7; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("ciphertext") + " e(x) ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 7; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(cipherfield = new TextField(64), c);
      cipherfield.setEditable(false);
      
      // register listeners
      plainfield.addActionListener(this);
      keyfield.addActionListener(this);
      ButtonEncrypt.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      des();
   }

   public void des() {
      String key = keyfield.getText();
      key = fillup(key, 56);
      keyfield.setText(key);

      String plaintext = plainfield.getText();
      plaintext = adapt(plaintext);
      
      // encrypt words of 8 chars each
      int times = plaintext.length() / 8;

      for (int t=0; t < times; t++) {
	 String word = plaintext.substring(t*8, t*8 + 8); // single word of 8 chars
	 String prettyword = pretty(word);
	 plainBinArea.setText(prettyword + "\n");
	 
	 String wordBin = charWordToBinWord(word);
	 plainBinArea.append(wordBin);
	 String IPofX = initialPermutation(wordBin);
	 IPofXfield.setText("     "+IPofX.substring(0,32)+" "+IPofX.substring(32,64));

	 // compute the keys!
	 String keys[] = {"","","","","","","","","","","","","","","","",""};
	 keys = makeKeys(key);

	 String[] L = {"","","","","","","","","","","","","","","","",""};
	 String[] R = L;
	 // 17 elements each
	 L[0] = IPofX.substring(0,32);
	 R[0] = IPofX.substring(32,64);
	 roundsArea.setText("");
	 for (int i=1; i <= 16; i++) {
	    L[i] = R[i-1];
	    R[i] = xor(L[i-1],f(R[i-1],keys[i]));
	    
	    roundsArea.append("(");
	    if (i < 10) { roundsArea.append(" "); }
	    roundsArea.append(i +") "+ L[i]+" "+ R[i]);
	    if (i < 16) { roundsArea.append("\n"); }

	 }
	 String T16 = L[16] + R[16];
	 
	 String ciphertext = finalPermutation(IPofX);  // change to T16
	 cipherfield.setText(ciphertext);
      }
   }
      // fill up to multiple of 8
      public String adapt(String in) {
      String out = in;
      if ((in.length() % 8) != 0) {
	 out += "________".substring(0, 8-(in.length() % 8));
      }
      return out;
   }
   
   // converts String (length 8) into binary representation
   public String charWordToBinWord(String in) {
      String out="";
      byte[] plainint = in.getBytes(); // word as integer (ascii) array
      for (int i=0; i < 8; i++) {
	 out += fillup(Integer.toBinaryString(plainint[i]),8);
      }
      return out;
   }
   
   // inserts blanks to extend to length of binary representation
   public String pretty(String in) {
      String out="";
      for (int i=0; i < 8; i++) {
	 out += ("       "+in.substring(i, i+1));
      }
      return out;
   }
   
   public String xor(String s1, String s2) {
      String out="";
      for (int i=0; i < s1.length(); i++) {
	 if (s1.substring(i,i+1).equals(s2.substring(i,i+1))) { out += "0"; }
	 else { out += "1"; }
      }
      return out;
   }

   public String f(String R, String key) {
      String ER = expand(R);
      String ERxorKey = xor(ER, key);
      String B[] = splitBoxes(ER);
      
      String S[] = {"","","","","","","",""};
      String concatS="";
      for (int i=0; i < 8; i++) {
	 S[i] = Sbox(B[i], i);
	 concatS += S[i];
      }
      String permS = P(concatS);
      return permS;
   }

   // fixed permutation P
   public String P(String in) {
      String out="";
      int p[] = {16,7,20,21,29,12,28,17,1,15,23,26,5,18,3,10,2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25};
      for (int i=0; i < 32; i++) {
	 out += in.substring(p[i]-1,p[i]);
      }
      return out;
   }
   
   // S-Boxes
   public String Sbox(String in, int nr) {
      String out;
      int o=0;
      int row = Integer.parseInt((in.substring(0,1)+in.substring(5,6)), 2);
      int column = Integer.parseInt((in.substring(1,5)), 2);
      int pos = row*4 + column;

      // could be made MUCH nicer with a 3-dim array
      int sbox1[] = {14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7,0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8,4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0,15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13};
      int sbox2[] = {15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10,3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5,0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15,13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9};
      int sbox3[] = {10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8,13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1,13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7,1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12};
      int sbox4[] = {7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15,13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9,10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4,3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14};
      int sbox5[] = {2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9,14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6,4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14,11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3};
      int sbox6[] = {12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11,10,15,4,2,7,12,9,5,66,1,13,14,0,11,3,8,9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6,4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13};
      int sbox7[] = {4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1,13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6,1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2,6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12};
      int sbox8[] = {13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7,1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2,7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8,2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11};

      switch (nr) {
      case 1: o = sbox1[pos]; break;
      case 2: o = sbox2[pos]; break;
      case 3: o = sbox3[pos]; break;
      case 4: o = sbox4[pos]; break;
      case 5: o = sbox5[pos]; break;
      case 6: o = sbox6[pos]; break;
      case 7: o = sbox7[pos]; break;
      case 8: o = sbox8[pos]; break;
      }
      out = fillup(Integer.toBinaryString(o), 4);
      return out;
   }

   // splits input into 8 blocks of 6 bits each
   public String[] splitBoxes(String in) {
      String out[] = {"","","","","","","",""};
      for (int i=0; i < 8; i++) { out[i] = in.substring(i*6, i*6 + 6); }
      return out;
   }
   
   // expands R to 48 bits
   public String expand(String in) {
      String out="";
      int E[] = {32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,16,17,18,19,20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1};
      for (int i=0; i < 48; i++) {
	 out += in.substring(E[i]-1,E[i]);
      }
      return out;
   }

  // exend all strings to desired length by inserting 0s
   public String fillup(String in, int length) {
      if (in.length() < length) {
	 String temp = "";
	 for (int i=0; i < length-in.length(); i++) {
	    temp += "0";
	 }
	 return temp+in;
      }
      else return in;
   }
   

   // initial permutation IP
   public String initialPermutation(String in) {
      String out="";
      int ip[] = {58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7};
      for (int i=0; i < 64; i++) {
	 out += in.substring(ip[i]-1,ip[i]);
      }
      return out;
   }

   // final permutation IP^-1
   public String finalPermutation(String in) {
      String out="";
      int ipinv[] = {40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,38,6,46,14,54,22,62,30,37,5,45,13,53,21,61,29,36,4,44,12,52,20,60,28,35,3,43,11,51,19,59,27,34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25};
      for (int i=0; i < 64; i++) {
	 out += in.substring(ipinv[i]-1,ipinv[i]);
      }
      return out;
   }

   /*
   public String rounds(String in, String K) {
      String Li = in.substring(0,31);
      String Ri = in.substring(32,63);
      
      for (int i=0; i < 16; i++) {
	 String Liplus1 = Ri;
	 String Riplus1 = xor(Li, f(Ri,K));

	 Li = Liplus1;
	 Ri = Riplus1;
      }
      return(Ri + Li);
   }
   */
   
   // compute the 16 keys from key
   public String[] makeKeys(String key) {
      String keys[] = {"","","","","","","","","","","","","","","","",""};
      //      System.out.println(key);

      //      System.out.println(key);

      String keyWithParity = addParity(key);
      String keyPC1 = PC1(keyWithParity);
      keys = leftShifts(keyPC1);
      return keys;
   }
   
   // is there no better way of inverting booleans?
   public boolean not(boolean in) {
      if (in) { return false; }
      else { return true; }
   }
   
   // add redundant parity bits to key
   public String addParity(String in) {
      String out="";
      for (int i=0; i < 8; i++) {
	 boolean even = true;
	 for (int t=0; t < 7; t++) {
	    int pos = t + i*7;
	    String single = in.substring(pos, pos + 1);
	    out += single;
	    if (single.equals("1")) { even = not(even); }
	 }
	 if (even) { out += "0"; }
	 else { out += "1"; };
      }
      return out;
   }
	    
   // first permutation
   public String PC1(String in) {
      String out="";
      int pc1[] = {57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};
      for (int i=0; i < 56; i++) {
         out += in.substring(pc1[i]-1, pc1[i]);
      }
      return out;
   }

   // second permutation
   public String PC2(String in) {
      String out="";
      int pc2[] = {14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32};
      for (int i=0; i < 48; i++) {
	 out += in.substring(pc2[i]-1, pc2[i]);
      }
      return out;
   }
   
   // left shift for C[] and D[]
   public String LS(int i, String in) {
      if ((i==1) || (i==2) || (i==9) || (i==16)) {
	 return in.substring(1,28) + in.substring(0,1);
      }
      else return in.substring(2,28) + in.substring(0,2);
   }

   // last, combined step of key computation
   public String[] leftShifts(String key) {
      String out[] = {"","","","","","","","","","","","","","","","",""};
      String C[] = {"","","","","","","","","","","","","","","","",""};
      String D[] = {"","","","","","","","","","","","","","","","",""};
      C[0] = key.substring(0, 28);
      D[0] = key.substring(28,56);
      for (int i=1; i <= 16; i++) {
	 C[i] = LS(i,C[i-1]);
	 D[i] = LS(i,D[i-1]);
	 out[i] = PC2(C[i] + D[i]);
      }
      return out;
   }
}

