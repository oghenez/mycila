import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;
import java.util.Vector;
import lp.*;

public class ShamirApplet extends Applet implements ActionListener, ItemListener, constant, Runnable
{
  final int maxVisible = 18;
  final int minVisible = 4;
  final int minStart = 1;
  final int maxStart = 31;
  final int precision = 5;

  int visible = maxVisible >> 1;
  int pIndex = 0;
  long currP = 0, numP, maxP;
  long M, U;
  int maxWidth, currWidth, currStart;

  boolean found = false, lock = false;

  Button keyBtn, accPBtn, trapdoorBtn, nextBtn, privKeyBtn, UMBtn;
  Choice ch;
  CheckboxGroup cbg, cbgAccP;
  Checkbox pOne, pAll, cb30, cb50, cb100, cbAll;
  TextField[] tf;
  TextField tfWidth, tfI2, tfDelta, tfSolI1, tfSolI2, tfSolI3, tfSolI4;
  TextField tfM, tfU;
  TextArea taInequal, taAccP, taMinima, taFunction, taInterval, taPrivKey, taNewKey, taNewPub;
  Label lError;

  Knapsack pubKey;
  MH privKey;
  SH sh;

  Thread pThread, printThread;

  Vector pList, sList;
  Rational[] u = new Rational[2];

  public void init()
  {
    Color[] color = {Color.cyan, Color.green, Color.magenta, Color.orange, Color.pink, Color.yellow};

    int col = ((int)Tools.randomNumber(1, (long)3*color.length))%color.length;
    setBackground(color[col]);

    this.showStatus("Never mind the Hosen here's Die Roten Rosen");

    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();

    Panel p;
    String str;

    int gridy = 0;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    add(new Label("Shamir's algorithm breaking the basic Merkle-Hellman Cryptosystem"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;

    p = new Panel();
    p.add(new Label("choose number elements in public key B"));

    ch = new Choice();

    for (int i=minVisible; i<=maxVisible; i++)
      ch.add(Integer.toString(i));

    if (visible < minVisible)
      visible = minVisible;

    if (visible > maxVisible)
      visible = maxVisible;

    ch.select(Integer.toString(visible));
    p.add(ch);

    add(p, c);

    p = new Panel();
    gridy = c.gridy;

    c = new GridBagConstraints();    
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;

    tf = new TextField[maxVisible];

    for (int i=0; i<maxVisible; i++)
    {
      c.insets = new Insets(0,0,0,20);
      p = new Panel();

      str = "b(" +Integer.toString(i+1) +")";

      tf[i] = new TextField(10);
      tf[i].setBackground(Color.lightGray);
      tf[i].setEditable(true);

      p.add(new Label(str));
      p.add(tf[i]);

      if (i%3 == 2)
        c.insets = new Insets(0,0,0,0);

      if (i%3 == 0)
      {
        c.gridy++;
        c.gridx=0;
      }

      add(p, c);
      c.gridx++;
    }

    gridy = c.gridy;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.insets = new Insets(10,0,0,20);
    c.anchor = GridBagConstraints.EAST;
    p = new Panel();
    p.add(new Label("delta ="));
    tfDelta = new TextField(10);
    tfDelta.setBackground(Color.lightGray);
    tfDelta.setEditable(false);
    p.add(tfDelta);
    add(p, c);

    c.gridx++;
    tfWidth = new TextField(10);
    tfWidth.setBackground(Color.white);
    p = new Panel();
    p.add(new Label("width"));
    p.add(tfWidth);
    add(p, c);

    c.gridx++;
    c.insets = new Insets(10,0,0,0);
    keyBtn = new Button("new key");
    keyBtn.setActionCommand("key");
    add(keyBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.CENTER;
    c.gridwidth = GridBagConstraints.REMAINDER;
    p = new Panel();
    p.add(new Label("number accumulation points"));
    cbgAccP = new CheckboxGroup();
    cb30 = new Checkbox("30", cbgAccP, false);
    cb50 = new Checkbox("50", cbgAccP, true);
    cb100 = new Checkbox("100", cbgAccP, false);
    cbAll = new Checkbox("all", cbgAccP, false);
    p.add(cb30);
    p.add(cb50);
    p.add(cb100);
    p.add(cbAll);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 2;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("1) Find accumulation points"), c);

    c.gridx += 2;
    c.gridwidth = GridBagConstraints.REMAINDER;
    accPBtn = new Button("get accumulation points");
    accPBtn.setActionCommand("acc");
    add(accPBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    p = new Panel();
    taInequal = new TextArea(8, 33);
    taInequal.setEditable(false);
    taInequal.setBackground(Color.lightGray);
    p.add(taInequal);
    taAccP = new TextArea(8, 33);
    taAccP.setText("Accumulation points:");
    taAccP.setEditable(false);
    taAccP.setBackground(Color.lightGray);
    p.add(taAccP);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(10,0,0,0);
    add(new Label("2) Minima of sawtooth curves in [ p/b(1), p+1/b(1) [, sorted in increasing order"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 2;
    cbg = new CheckboxGroup();
    p = new Panel();
    p.add(new Label("scan"));
    pOne = new Checkbox("one p-value", cbg, true);
    p.add(pOne);
    pAll = new Checkbox("all p-values", cbg, false);
    p.add(pAll);
    add(p, c);

    c.gridx +=2;
    c.anchor = GridBagConstraints.EAST;
    trapdoorBtn = new Button("find trapdoor pair"); 
    trapdoorBtn.setActionCommand("trap");
    add(trapdoorBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taMinima = new TextArea(10, 70);
    taMinima.setBackground(Color.lightGray);
    taMinima.setEditable(false);
    add(taMinima, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(10,0,0,0);
    add(new Label("3) Find interval in [ v(i), v(i+1) [ satisfying superincreasing property and SUM(fi) < 1"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    p = new Panel();
    taFunction = new TextArea(10, 25);
    taFunction.setBackground(Color.lightGray);
    taFunction.setEditable(false);
    p.add(taFunction);
    taInterval = new TextArea(10, 40);
    taInterval.setBackground(Color.lightGray);
    taInterval.setEditable(false);
    p.add(taInterval);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    p = new Panel();
    p.add(new Label("final interval ] u1 , u2 [ = ]"));
    tfSolI1 = new TextField(16);
    tfSolI1.setBackground(Color.lightGray);
    tfSolI1.setEditable(false);
    p.add(tfSolI1);
    p.add(new Label(" , "));
    tfSolI2 = new TextField(16);
    tfSolI2.setBackground(Color.lightGray);
    tfSolI2.setEditable(false);
    p.add(tfSolI2);
    p.add(new Label("["));
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    p = new Panel();
    p.add(new Label(" = ]"));
    tfSolI3 = new TextField(16);
    tfSolI3.setBackground(Color.lightGray);
    tfSolI3.setEditable(false);
    p.add(tfSolI3);
    p.add(new Label(" , "));
    tfSolI4 = new TextField(16);
    tfSolI4.setBackground(Color.lightGray);
    tfSolI4.setEditable(false);
    p.add(tfSolI4);
    p.add(new Label("["));
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(10,0,0,0);
    c.anchor = GridBagConstraints.WEST;
    add(new Label("4) Any rational number U / M in ]u1 , u2[ is a trapdoor-pair"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,20);
    p = new Panel();
    p.add(new Label("U ="));
    tfU = new TextField(10);
    tfU.setBackground(Color.white);
    p.add(tfU);
    add(p, c);

    c.gridx++;
    p = new Panel();
    p.add(new Label("M ="));
    tfM = new TextField(10);
    tfM.setBackground(Color.white);
    p.add(tfM);
    add(p, c);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,0,0);
    p = new Panel();
    UMBtn = new Button("new U, M");
    UMBtn.setActionCommand("um");
    p.add(UMBtn);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("5) Get new private key A' by computing a'(i) = b(i) * U mod M"), c);    

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.EAST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridwidth = 2;
    lError = new Label("", Label.CENTER);
    lError.setForeground(Color.red);
    add(lError, c);
    c.gridx = 2;
    c.fill = GridBagConstraints.NONE;
    c.gridwidth = GridBagConstraints.REMAINDER;
    privKeyBtn = new Button("create private key");
    privKeyBtn.setActionCommand("private");
    add(privKeyBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.CENTER;
    add(new Label("original private key"));
    c.gridx++;
    add(new Label("derived private key"), c);
    c.gridx++;
    add(new Label("resulting public key"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.CENTER;
    taPrivKey = new TextArea(10, 18);
    taPrivKey.setBackground(Color.lightGray);
    taPrivKey.setEditable(false);
    add(taPrivKey, c);
    c.gridx++;
    taNewKey = new TextArea(10, 18);
    taNewKey.setBackground(Color.lightGray);
    taNewKey.setEditable(false);
    add(taNewKey, c);

    c.gridx++;
    taNewPub = new TextArea(10, 18);
    taNewPub.setBackground(Color.lightGray);
    taNewPub.setEditable(false);
    add(taNewPub, c);

    for (int i=visible; i<maxVisible; i++)
      tf[i].setBackground(Color.gray);

    keyBtn.addActionListener(this);
    accPBtn.addActionListener(this);
    trapdoorBtn.addActionListener(this);
    UMBtn.addActionListener(this);
    privKeyBtn.addActionListener(this);
    ch.addItemListener(this);

    /* create private and public key */
    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(minStart, maxStart));
    pubKey = privKey.getPubKey();
    taPrivKey.setText(privKey.toString());

    /* set textfields with values of knapsack elements */
    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(pubKey.getElement(i)));

    sh = new SH(pubKey);
    maxWidth = sh.getWidth();
    currWidth = maxWidth;
    tfWidth.setText(Integer.toString(maxWidth));
    tfDelta.setText(new Double(sh.getDelta(precision)).toString());
    taInequal.setText(sh.inequalToString());

  } /* end init() */


  public void run()
  {
    String out;
    int cnt = 0;

    try
    {
      while ( (out = sh.getNextMessage()) != null)
      {
        if (out.startsWith("StackOverflow"))
        {
          String tmp = new String(out);

          tmp = out.substring(out.lastIndexOf(" ") +1);
          try
          {
            maxWidth = (Integer.parseInt(tmp) -100) >> 1;
          }
          catch (NumberFormatException nfe)
          {taAccP.append("NumberFormatException: <" +tmp +">");}

          taAccP.append(out +"\nset new width = " +maxWidth);
          tfWidth.setText(Integer.toString(maxWidth));
          taAccP.append("\n\nPress stop-Button and try again\n");
          return;
        }
        else
        {
          if (cnt > 25000)
          {
            taAccP.setText("");
            cnt = 0;
          }

          taAccP.append(out);
          cnt += out.length();
        }

      }
    }
    catch (Exception e)
    {return;}
    catch (Error s)
    {return;}

    accPBtn.setActionCommand("acc");
    accPBtn.setLabel("get accumulation points");

    pThread = null;
    pList = sh.getPList();

    lock = false;

    if (pList == null)
    {
      taAccP.setText("Error occurred ...pList is null\n");
      return;
    }

    numP = pList.size();
    printpValues(pList);

    pIndex = 0;

    if (numP == 0)
      return;

    currP = nextP(pIndex);

    return;

  } /* end run */


  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();

    if (cmd.equals("key"))
    {
      if (lock)
        return;

      initFields("key");

      privKey = new MH(visible);
      privKey.getPrivKey(getStartVal());
      pubKey = privKey.getPubKey();
      taPrivKey.setText(privKey.toString());

      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(pubKey.getElement(i)));

      sh = new SH(pubKey);
      maxP = getMaxP();
      currWidth = getWidth();
      sh.setMaxP(maxP);
      sh.setWidth(currWidth);
      tfDelta.setText(new Double(sh.getDelta(precision)).toString());
      taInequal.setText(sh.inequalToString());

      return;
    }

    if (cmd.equals("acc"))
    {
      if (lock)
        return;

      Knapsack k = getKnapsack();

      if (k == null)
        return;

      lock = true;

      if (!k.equals(pubKey))
        taPrivKey.setText("");

      pubKey = k;
      sh = new SH(pubKey);

      initFields("acc");
      taAccP.setText("Trying to find accumulation points...\nPress stop-Button to abort\n");

      accPBtn.setLabel("stop");
      accPBtn.setActionCommand("stop");

      maxP = getMaxP();
      currWidth = getWidth();
      sh.setMaxP(maxP);
      sh.setWidth(currWidth);
      tfDelta.setText(new Double(sh.getDelta(precision)).toString());
      taInequal.setText(sh.inequalToString());

      if (pThread != null)
        pThread = null;

      pThread = new Thread(sh);
      pThread.start();

      if (printThread != null)
      { 
        printThread.stop();
        printThread = null;
      }

      printThread = new Thread(this);
      printThread.start();

      return;
    }

    if (cmd.equals("trap"))
    {
      if (lock)
        return;

      initFields("trap");

      if (pList == null)
      {
        taMinima.setText("first get accumulation points ...\n");
        return;
      }

      if (pIndex == numP)
      {
        taMinima.setText("no more accumulation points ...\n");
        return;
      }

      long step = pIndex+1;

      if (pAll.getState())
        step = numP;

      Rational left, right;

      while (pIndex < step)
      {
        taFunction.setText("");
        taInterval.setText("");
        taMinima.setText("");

        currP = nextP(pIndex);
        left = new Rational(currP, pubKey.getElement(0));
        right = new Rational(currP+1, pubKey.getElement(0));
        taMinima.setText("Minima in [ " +left.toString() +" , " +right.toString() +" [\n\n");

        sList = sh.getMinimaList(pIndex);

        if (sList == null)
          return;

        printvValues(sList);
        found = findInterval(u);

        if (found)
          break;

        pIndex++;
      }

      if (found)
      {
        getRational(u);
      }

      return;
    }

    if (cmd.equals("um"))
    {
      if (lock)
        return;

      initFields("um");

      if (!found)
        return;

      getRational(u);

      return;
    }

    if (cmd.equals("private"))
    {
      if (lock)
        return;

      initFields("private");

      if (!found)
        return;

      long tmpU, tmpM;

      try
      {
        tmpU = Long.parseLong(tfU.getText());
      }
      catch (NumberFormatException nfe)
      {
        lError.setText("U: " +tfU.getText() +" not a number");

        return;
      }

      try
      {
        tmpM = Long.parseLong(tfM.getText());
      }
      catch (NumberFormatException nfe)
      {
        lError.setText("M: " +tfM.getText() +" not a number");

        return;
      }

      Rational r = new Rational(tmpU, tmpM);
      r.cancel();

      if (!isValid(r, u))
      {
        lError.setText(r.toString() +" not in ] " +u[0].toString() +" , " +u[1].toString() +" [");

        return;
      }

      U = r.getN();
      M = r.getD();

      MH newKey = new MH(visible);
      newKey.setM(M);
      newKey.setW(Tools.multInvers(U, M));

      for (int i=0; i<visible; i++)
        newKey.setElement(i, Tools.mod(pubKey.getElement(i), U, M));

      if (!newKey.isSuperInc())
      {
        taNewKey.setText("Uuups: private key not superincreasing\n" +newKey.toString());
        
        return;
      }

      taNewKey.setText(newKey.toString());

      Knapsack newPubKey = newKey.getPubKey();
      taNewPub.setText(newPubKey.toString());

      return;
    }

    if (cmd.equals("stop"))
    {
      accPBtn.setLabel("get accumulation points");
      accPBtn.setActionCommand("acc");

      if (printThread != null)
        printThread.stop();

      printThread = null;

      if (pThread != null)
        pThread.stop();

      pThread = null;

      pList = sh.getPList();
      numP = pList.size();
      printpValues(pList);

      lock = false;
      pIndex = 0;

      if (numP == 0)
        return;

      currP = nextP(pIndex);

      return;
    }

    taAccP.setText("unknown command");
    return;

  } /* end actionPerfomed() */


  public void itemStateChanged(ItemEvent ie)
  {
    if (lock)
      return;

    Object obj = ie.getItem();

    initFields("all");

    int newVisible = Integer.parseInt(obj.toString());

    if (visible == newVisible)
      return;

    if (visible < newVisible)
      for (int i=visible; i<newVisible; i++)
        tf[i].setBackground(Color.lightGray);
    else
      for (int i=newVisible; i<visible; i++)
      {
        tf[i].setBackground(Color.gray);
        tf[i].setText("");
      }

    visible = newVisible;

    /* create new private key */
    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(minStart, maxStart));
    taPrivKey.setText(privKey.toString());

    /*create new public key */
    pubKey = privKey.getPubKey();

    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(pubKey.getElement(i)));

    sh = new SH(pubKey);

    tfDelta.setText(new Double(sh.getDelta(precision)).toString());
    taInequal.setText(sh.inequalToString());
    tfWidth.setText(Integer.toString(currWidth));

    return;

  } /* end itemStateChanged() */


  public Knapsack getKnapsack()
  {
    String[] s = new String[visible];
    Knapsack kn;

    for (int i=0; i<visible; i++)
      s[i] = tf[i].getText(); 

    try
    {
      kn = new Knapsack(s, "b", false);
    }
    catch (notAKnapsackException ke)
    {
      taAccP.setText(ke.getMessage());
      return (null);
    }

    return (kn);
  }


  /* get a rational number in ] r[0], r[1] [ */
  public void getRational(Rational[] r)
  {
    double diff = r[1].toDouble() - r[0].toDouble();
    double q = Tools.randomNumber(1, 99)/100.0;
    double value = r[0].toDouble() + q*diff;
    double eps = Math.min(Math.abs(r[0].toDouble() - value), Math.abs(r[1].toDouble() - value)); 
    eps /= 100.0;

    Rational res = Tools.getRational(value , eps);

    tfM.setText(Long.toString(res.getD()));
    tfU.setText(Long.toString(res.getN()));
    M = res.getD();
    U = res.getN();

    tfSolI1.setText(r[0].toString());
    tfSolI2.setText(r[1].toString());
    tfSolI3.setText(new Double(formatDouble(r[0].toDouble(), 0)).toString());
    tfSolI4.setText(new Double(formatDouble(r[1].toDouble(), 0)).toString());

    return;
  }


  /* true if r is in ] u[0], u[1] [ */
  public boolean isValid(Rational r, Rational[] u)
  {
    if (r.toDouble() <= u[0].toDouble())
      return (false);

    if (r.toDouble() >= u[1].toDouble())
      return (false);

    return (true);
  }


  public void printpValues(Vector vec)
  {
    if (vec == null)
      return;

    String out;
    int p, cnt = 0;

    taAccP.setText("Accumulation points:\n\n");

    if (vec == null)
    {
      taAccP.setText("Error occurred ...\n");
      return;
    }

    p = pList.size();

    if (p == 0)
    {
      taAccP.setText("no accumulation points ...\n");
      return;
    }

    for (int i=0; i<p; i++)
    {
      if (cnt > 25000)
      {
        taAccP.setText("");
        cnt = 0;
      }

      long[] l = (long[]) vec.elementAt(i);

      out = (i+1) +". p = " +l[0];
      out += " ( q = " +l[1] +" , r = " +l[2] +")\n"; 
      taAccP.append(out);
      cnt += out.length();
    }

    if (p == sh.getMaxP())
      taAccP.append("\n\nreached maximal number of accumulation points; maybe not all p-values found\n");

    return;
  }


  public void printvValues(Vector vec)
  {
    if (vec == null)
      return;

    int size = vec.size();
    int cnt = 0;

    String out;
    vNode v;
    Rational r;

    for (int i=0; i<size; i++)
    {
      if (cnt > 25000)
      {
        taMinima.setText("");
        cnt = 0;
      }

      out = "v(" +(i+1) +"): ";
      v = (vNode) vec.elementAt(i);

      r = v.getRational();
      out += r.toString() +"\t= " +r.toDouble();
      out += "\t( minimum of function " +(v.getIndex()+1) +") \n";

      taMinima.append(out);
      cnt += out.length();
    }

    taMinima.setCaretPosition(0);

    return;
  }


  /* check all intervals ] v(i), v(i+1) [ for an interval satisfying the superincreasing
     property and in which SUM(f(i)) < 1 */
  public boolean findInterval(Rational[] r)
  {
    String out;
    boolean found = false;
    int cnt = 0;

    for (int i=0; i<sList.size() -1; i++)
    {
      if (cnt > 25000)
      {
        taFunction.setText("");
        cnt = 0;
      }

      r = nextInterval(i);
      u = sh.getInterval(i);

      if (i==0)
      {
        taFunction.append("functions in ");
        out = "[ v(" +(i+1) +"), v(" +(i+2) +") [ :\n";
        taFunction.append(out);

        for (int j=0; j<pubKey.getDim(); j++)
          taFunction.append("    " +sh.getFunction(j) +"\n");

        cnt = taFunction.getText().length();
      }
      else
      {
        out = "\nNew function in [ v(" +(i+1) +"), v(" +(i+2) +") [ :\n";
        cnt += out.length();
        taFunction.append(out +"    " +sh.getChangedFunction() +"\n");
      }

      if (u == null)
      {
        taFunction.append("u is null\n");
        found = false;

        return (found);
      }

      out = "[ v(" +(i+1) +"), v(" +(i+2) +") [ :";

      if (!isValid(u))
      {
        out += "\tget interval ] " +u[0].toString() +" , " +u[1].toString(); 
        out += " [: lower bound >= upper bound  ==> INFEASIBLE\n";
      }
      else
      {
        out += "\tfinal interval ] " +u[0].toString() +" , " +u[1].toString() +" [\n";
        found = true;
      }

      taInterval.append(out);
      cnt += out.length();

      if (found)
      {
        out = "\nfunctions in [ v(" +(i+1) +"), v(" +(i+2) +") [ :\n";
        taInterval.append(out);

        for (int j=0; j<pubKey.getDim(); j++)
          taInterval.append("    " +sh.getFunction(j) +"\n");

        out = "\nconstraints in [ v(" +(i+1) +"), v(" +(i+2) +") [ :\n";
        taInterval.append(out);
        taInterval.append(sh.constraintsToString(r));

        break;
      }

    }

    if (!found)
      taInterval.append("\nNO INTERVAL FOUND\n");

    return(found);
  }


  /* get next v-interval */
  public Rational[] nextInterval(int vIndex)
  {
    if (vIndex >= sList.size()-1)
      return (null);

    Rational r[] = new Rational[2];

    vNode v = (vNode) sList.elementAt(vIndex);
    r[0] = v.getRational();

    v = (vNode) sList.elementAt(++vIndex);
    r[1] = v.getRational();

    return (r);    
  }


  /* left < right? */
  public boolean isValid(Rational[] r)
  {
    if (r == null)
      return (false);

    if (r[0].toDouble() >= r[1].toDouble())
      return (false);

    return (true);
  }


  public double formatDouble(double d, int prec)
  {
    if (prec <= 0)
      return (d);

    double l = Math.pow(10, prec);
    d = Math.round(d*l);
    d /= l;

    return (d);
  }


  public long nextP(int index)
  {
    if (pList == null)
      return (-1);

    if (index >= numP)
      return (-1);

    long[] p = (long[])pList.elementAt(index);

    return (p[0]);
  }


  public long getMaxP()
  {
    long p;

    if (cbAll.getState())
      p = pubKey.getElement(0);
    else
      p = Long.parseLong(cbgAccP.getSelectedCheckbox().getLabel());

    return p;
  }


  public int getWidth()
  {
    int w;
    try
    {
      w = Integer.parseInt(tfWidth.getText());
    }
    catch (NumberFormatException nfe)
    {
      w = maxWidth;
    }

    if (w <= 20)
      w = 20;

    if (w > maxWidth)
      w = maxWidth;

    tfWidth.setText(Integer.toString(w));

    return (w);
  }


  public long getStartVal()
  {
    long s;

    try
    {
      s = Long.parseLong(tf[0].getText());
    }
    catch (NumberFormatException nfe)
    {
      return (Tools.randomNumber(minStart, maxStart));
    }

    if ( (s < minStart) | (s > maxStart) )
      return (Tools.randomNumber(minStart, maxStart));
 
    return (s);
 }


  public void initFields(String src)
  {
    taNewPub.setText("");
    taNewKey.setText("");
    lError.setText("");

    if (src.equals("private"))
      return;

    tfU.setText("");
    tfM.setText("");

    if (src.equals("um"))
      return;

    tfSolI1.setText("");
    tfSolI2.setText("");
    tfSolI3.setText("");
    tfSolI4.setText("");
    taFunction.setText("");
    taInterval.setText("");
    taMinima.setText("");

    found = false;

    if (src.equals("trap"))
      return;

    taAccP.setText("Accumulation points:\n\n");

    sList = null;
    pList = null;
    pIndex = 0;
    found = false;

    return;
  } /* end initFields() */


  public void stop()
  {
    if (pThread != null)
    {
      pThread.stop();
      pThread = null;
    }

    if (printThread != null)
    {
      printThread.stop();
      printThread = null;
    }

    return;
  }


  public void destroy()
  {
    if (pThread != null)
    {
      pThread.stop();
      pThread = null;
    }

    if (printThread != null)
    {
      printThread.stop();
      printThread = null;
    }

    return;
  }

} /* end class */