public class lTable
{
  private long[][] table;
  private int rows;
  private int cols;
  private int dim;

  lTable(Knapsack kn)
  {
    dim = kn.getDim();
    rows = 0x01 << dim;
    cols = 2;

    table = new long[rows][cols];

    for (int i=0; i<rows; i++)
    {
      table[i][0] = kn.encrypt((long) i);
      table[i][1] = (long)i;
    }

    return;
  }

  public long getElement(int i, int j)
  {
    return (this.table[i][j]);
  }

  public void setElement(int i, int j, long l)
  {
    this.table[i][j] = l;

    return;
  }

  public long[] getRow(int i)
  {
    long[] tmp = new long[2];

    tmp[0] = this.getElement(i, 0);
    tmp[1] = this.getElement(i, 1);

    return (tmp);
  }

  public String rowToBinaryString(int i)
  {
    if ( (i < 0) | (i >= (0x01 << dim)) )
      return (null);

    String res = Long.toString(this.table[i][0]);
    res += "\t";
    res += Tools.fillString(Long.toBinaryString(this.table[i][1]), dim);
    res += "\n";

    return (res);
  }

  public void setRow(int i, long l1, long l2)
  {
    this.table[i][0] = l1;
    this.table[i][1] = l2;

    return;
  }

  public int getCols()
  {
    return (this.cols);
  }

  public int getRows()
  {
    return (this.rows);
  }

  public void sort()
  {
    this.quicksort(0, this.rows -1);

    return;
  }

  /* sort this table by first component */
  private void quicksort(int left, int right)
  {
    if (left < right)
    {

      int i = left;
      int j = right;

      long pivot = this.table[(int)(left + right)/2][0];

      do
      {
        while (this.table[i][0] < pivot)
          i++;

        while (pivot < this.table[j][0])
          j--;

        if (i <= j)
        {
          long[] tmp = this.table[i];
          this.table[i] = this.table[j];
          this.table[j] = tmp;

          i++;
          j--;
        }

      }
      while (i < j);

      this.quicksort(left, j);
      this.quicksort(i, right);
    }

    return;
  } /* end quicksort() */

  /* search for l in table; returns the index of the row containing l else -1 */
  public int search(long l)
  {
    int res = binarySearch(0, this.rows - 1, l);

    return (res);
  }

  /* search using binary algorithm */
  private int binarySearch(int left, int right, long l)
  {
    if (left > right)
      return (-1);

    int res = -1;
    int index = left + ((right - left) >> 1);

    if (this.table[index][0] == l)
      return (index);

    if (this.table[index][0] > l)
      res = binarySearch(left, index-1, l);
    else
      res = binarySearch(index+1, right, l);

    return (res);
  }

} /* end class lTable */