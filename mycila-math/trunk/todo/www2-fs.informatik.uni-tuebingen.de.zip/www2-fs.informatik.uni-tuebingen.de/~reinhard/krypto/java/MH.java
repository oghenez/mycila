public class MH extends Knapsack
{
  private long M;	/* modulus */
  private long W;	/* weight */
  private long U;	/* U*W = 1 (mod M) */

  public MH(int n)
  {
    super(n);
  }

  /* n is dimension, m the start value for the superincreasing sequence */
  public MH(int n, long m)
  {
    super(n);
    this.getPrivKey(m);

    return;
  }

  public MH(String[] s, String[] mw, String name) throws notAKnapsackException
  {
    super(s, name, true);

    String err;

    try
    {
      M = Long.parseLong(mw[0]);
    }
    catch (NumberFormatException nfe)
    {
      err = "M: <" +mw[0] +"> not a number\n";
      throw new notAKeyException(err);
    }

    try
    {
      W = Long.parseLong(mw[1]);
    }
    catch (NumberFormatException nfe)
    {
      err = "W: <" +mw[1] +"> not a number\n";
      throw new notAKeyException(err);
    }

    if (M <= this.getSum())
    {
      err = "M <= SUM a(i) = " +Long.toString(this.getSum());
      throw new notAKeyException(err);
    }

    if (M >= (MAXSTART << dim))
    {
      err = "M: choose a number <= " +Long.toString((MAXSTART << dim) -1);
      throw new notAKeyException(err);
    }

    if (W < 1)
    {
      err = "W: choose a number >= 1";
      throw new notAKeyException(err);
    }

    if (W >= M)
    {
      err = "W: choose a number < M = " +Long.toString(M);
      throw new notAKeyException(err);
    }

    long d = Tools.binaryGcd(W, M);
    if (d != 1)
    {
      err = "gcd(W, M) = " +Long.toString(d) +": choose another value for W\n";
      throw new notAKeyException(err);
    }

    U = Tools.multInvers(W, M);

    return;
  }


  public long getM()
  {
    return (this.M);
  }

  public long getW()
  {
    return (this.W);
  }

  public long getU()
  {
    return (this.U);
  }

  public void setM()
  {
    /* t is the bitlength of last element in superincreasing sequence */
    long t = (long) Tools.log2((double) this.set[this.dim -1]);
    t++;

    t = 0x01L << t;

    /* choose M to be a 2^t bit number with M > SUM(Ai) */
    this.M = Tools.randomNumber(Math.max(this.getSum() +1, t), (t << 1) -1);

    return;
  }

  public void setW()
  {
    if (this.M == 0)
      this.setM();

    long w = Tools.randomNumber(2, this.M -2);
    long d = Tools.binaryGcd(w, this.M);

    while (d != 1)
    {
      w /= d;
      d = Tools.binaryGcd(w, this.M);
    }

    this.W = w / Tools.binaryGcd(w, this.M);
    this.U = Tools.multInvers(this.W, this.M);

    return;
  }

  public void setM(long m)
  {
    this.M = m;
    return;
  }

  public void setW(long w)
  {
    this.W = w;
    this.U = Tools.multInvers(this.W, this.M);

    return;
  }

  public void getPrivKey(long startVal)
  {
    this.getSuperInc(startVal);
    this.setM();
    this.setW();

    return;
  }

  public Knapsack getPubKey()
  {
    Knapsack kn = new Knapsack(this.dim);

    for (int i=0; i<dim; i++)
      kn.setElement(i, Tools.mod(this.W, this.set[i], this.M) );

    return (kn);
  }

  public long decrypt(long chiffre)
  {
    long msg = 0x0;
    long s = 0x01L;
    int i = this.dim;

    /* compute c = c*U mod M */
    chiffre = Tools.mod(chiffre, this.U, this.M);

    for (--i; i>=0; i--)
    {
      if (this.set[i] <= chiffre)
      {
        msg = msg | s;
        chiffre -= this.set[i];
      }

      s = s << 1;
    }

    return (msg);
  } /* end decrypt */

  public String toString()
  {
    String res = super.toString();
    res = res.replace('b', 'a');

    res += "\nM:\t" +this.M +"\n";
    res += "W:\t" +this.W +"\n";
    res += "U:\t" +this.U +"\n";

    return (res);
  } /* end toString() */

} /* end class MH */