import java.awt.*;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class SuperIncApplet extends Applet implements ActionListener, ItemListener
{
  final int maxVisible = 21;
  final int minVisible = 4;
  final long startVal = 16;
  final String name = "a";

  int visible = maxVisible >> 1;
  long sum = 0;

  Button solveBtn, newBtn;
  Choice ch;
  TextField[] tf;
  TextField tfSum, tfSol;
  TextArea taOutput;

  Knapsack knapsack;

  public void init()
  {
    Color[] color = {Color.cyan, Color.green, Color.magenta, Color.orange, Color.pink, Color.yellow};

    int col = ((int)Tools.randomNumber(1, (long)3*color.length))%color.length;
    setBackground(color[col]);

    this.showStatus("It's coming home ...");

    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();

    Panel p;
    String str;

    int gridy = 0;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    add(new Label("Solving superincreasing knapsacks"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;

    p = new Panel();
    p.add(new Label("choose number elements in knapsack A"));

    ch = new Choice();

    for (int i=minVisible; i<=maxVisible; i++)
      ch.add(Integer.toString(i));

    if (visible < minVisible)
      visible = minVisible;

    if (visible > maxVisible)
      visible = maxVisible;

    ch.select(Integer.toString(visible));
    p.add(ch);

    add(p, c);

    p = new Panel();
    gridy = c.gridy;

    c = new GridBagConstraints();    
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;

    tf = new TextField[maxVisible];

    for (int i=0; i<maxVisible; i++)
    {
      c.insets = new Insets(0,0,0,20);

      p = new Panel();

      str = "a(";
      str += Integer.toString(i+1);
      str += ")";

      tf[i] = new TextField(10);
      tf[i].setBackground(Color.white);

      p.add(new Label(str));
      p.add(tf[i]);

      if ( (i%3 == 2) )
        c.insets = new Insets(0,0,0,0);

      if (i%3 == 0)
      {
        c.gridy++;
        c.gridx=0;
      }

      add(p, c);
      c.gridx++;
    }

    gridy = c.gridy;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(10,0,0,20);
    p = new Panel();
    p.add(new Label("choose s"));

    tfSum = new TextField(10);
    tfSum.setBackground(Color.white);
    p.add(tfSum);
    add(p, c);

    c.gridx++;
    newBtn = new Button("new knapsack");
    newBtn.setActionCommand("new");
    add(newBtn, c);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(10,0,0,0);
    solveBtn = new Button("solve (A, s)");
    solveBtn.setActionCommand("solve");
    add(solveBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.CENTER;
    c.gridwidth = GridBagConstraints.REMAINDER;
    add(new Label("solving (A, s)"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taOutput = new TextArea("", 10, 70);
    taOutput.setBackground(Color.lightGray);
    taOutput.setEditable(false);
    add(taOutput, c);

    for (int i=visible; i<maxVisible; i++)
    {
      tf[i].setBackground(Color.gray);
      tf[i].setEditable(false);
    }

    solveBtn.addActionListener(this);
    newBtn.addActionListener(this);
    ch.addItemListener(this);

    /* create new knapsack */
    knapsack = new Knapsack(visible);
    knapsack.getSuperInc(Tools.randomNumber(startVal, startVal<<1));

    /* set textfields with values of knapsack elements */
    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(knapsack.getElement(i)));

    /* get a random sum being solvable */
    sum = Tools.randomNumber(1, (1 << knapsack.getDim() ) - 1);
    sum = knapsack.encrypt(sum);

    tfSum.setText(Long.toString(sum));

  } /* end init() */


  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();

    if (cmd.equals("solve"))
    {
      clearFields();

      Knapsack tmpKn;
      long s;

      if ((tmpKn = getKnapsack(visible)) == null)
        return;

      knapsack = tmpKn;

      if ( (s = getSum()) == -1)
        return;

      sum = s;

      solveSuperInc(sum, knapsack);

      return;
    }

    if (cmd.equals("new"))
    {
      clearFields();

      long first = getStartValue(knapsack.getMaxStart());

      if (first == -1)
        return;

      knapsack.getSuperInc(first);

      for (int i=0; i<visible; i++)
       tf[i].setText(Long.toString(knapsack.getElement(i)));

      sum = Tools.randomNumber(1, (1 << knapsack.getDim() ) - 1);
      sum = knapsack.encrypt(sum);

      tfSum.setText(Long.toString(sum));
      return;
    }

    taOutput.setText("unknown command");

    return;

  } /* end actionPerfomed() */


  public void itemStateChanged(ItemEvent ie)
  {
    Object obj = ie.getItem();

    int newVisible = Integer.parseInt(obj.toString());

    clearFields();

    /* restore old values */
    if (visible == newVisible)
    {
      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(knapsack.getElement(i)));

      tfSum.setText(Long.toString(sum));

      return;
    }

    if (visible < newVisible)
    {
      for (int i=visible; i<newVisible; i++)
      {
        tf[i].setBackground(Color.white);
        tf[i].setEditable(true);
      }
    }
    else
    {
      for (int i=newVisible; i<visible; i++)
      {
        tf[i].setText("");
        tf[i].setBackground(Color.gray);
        tf[i].setEditable(false);
      }
    }

    visible = newVisible;

    /* create new knapsack */
    knapsack = new Knapsack(visible);
    knapsack.getSuperInc(Tools.randomNumber(startVal, startVal<<1));


    for (int i=0; i<knapsack.getDim(); i++)
      tf[i].setText(Long.toString(knapsack.getElement(i)));

    sum = Tools.randomNumber(1, (1 << knapsack.getDim() ) - 1);
    sum = knapsack.encrypt(sum);

    tfSum.setText(Long.toString(sum));

    return;

  } /* end itemStateChanged() */


  private long getStartValue(long max)
  {
    long f;

    try
    {
      f = Long.parseLong(tf[0].getText());
    }
    catch (NumberFormatException nfe)
    {
      taOutput.setText("a(1): <" +tf[0].getText() +"> not a number\n");
      return (-1);
    }

    if (f <= 0)
    {
      taOutput.setText("a(1) <= 0: only positive starting values allowed\n");
      return (-1);
    }

    if (f > max)
    {
      taOutput.setText("a(1): choose a number <= " +Long.toString(max) +"\n");
      return (-1);
    }

    return (f);
  }


  public Knapsack getKnapsack(int visible)
  {
    String[] s = new String[visible];
    Knapsack k;

    for (int i=0; i<visible; i++)
      s[i] = tf[i].getText();

    try
    {
      k = new Knapsack(s, name, true);
    }
    catch (notAKnapsackException ke)
    {
      taOutput.setText(ke.getMessage());
      return (null);
    }

    /* input is ok */
    return (k);

  } /* end getKnapsack() */


  public long getSum()
  {
    String err;
    long s;

    try
    {
      s = Long.parseLong(tfSum.getText());
    }
    catch (NumberFormatException nfe)
    {
      err = "s: <" +tfSum.getText();
      err += "> not a number";
      taOutput.setText(err);

      return (-1);
    }

    if (s < 0)
    {
      err = "s: no negative values";
      taOutput.setText(err);

      return (-1);
    }

    return (s);

  } /* end getSum() */


  void solveSuperInc(long sum, Knapsack k)
  {
    int i = k.getDim();

    byte b;
    long msg = 0x0;
    long s = 0x01L;
    long save = sum;

    String out;

    for (--i; i>=0; i--)
    {
      b=0;

      if (sum >= k.getElement(i))
      {
        msg |= s;
        b = 1;
      }

      out = "s = " +sum;
      out += (b != 0) ? " >= " : " < ";
      out += k.getElement(i);
      out += " = a(" +(i+1) +")\t ==> x(" +(i+1) +") = ";
      out += b +" , s = " +sum +" - ";
      out += (b != 0) ? k.getElement(i) : 0;

      sum -= (long)b*k.getElement(i);

      out += " = " +sum +"\n";
      taOutput.append(out);

      s = s << 1;
    }

    if (sum != 0)
    {
      out = "\ns != 0 ==> no solution for (A, " +save +")";
      taOutput.append(out);
    }
    else
    {
      out = "\nSolution for (A, " +save +") = ";
      out += Tools.fillString(Long.toBinaryString(msg), k.getDim());
      taOutput.append(out);
    }

    return;
  } /* end solveSuperInc() */


  public void clearFields()
  {
    taOutput.setText("");

    return;
  } /* end clearFields() */

} /* end class */