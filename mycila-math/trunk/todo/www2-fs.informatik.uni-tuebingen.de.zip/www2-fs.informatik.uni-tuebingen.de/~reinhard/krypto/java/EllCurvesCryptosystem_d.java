// OK

package kryptoScript;

//
// java/EllipticCurves_d.java // 
// Copyright (c) 2002 Silke Thomas
//
// last change: 24.3.2002
// last change: 11.12.2007 KR
//

// uses "mod" (multiply a and b modulo c) from Helpers.class

import java.awt.*;
import java.applet.*;
import java.lang.*;
import java.awt.event.*;
import java.util.*;

public class EllCurvesCryptosystem_d extends Applet
implements ActionListener{
	
	long a, b, secExp, test, x, y, z, p, k;
	KeyField aField, bField, secField, pField, xField, yField,
		ix1Field, ix2Field, kField,
		y11Field, y12Field, y21Field, y22Field;
	TextField betaField, alphaTestField;
	TextArea pabTestArea, pointArea, resPointArea,
		addPointArea, multPointArea,
		encryptArea, decryptArea;
	Label nLabel, lLabel, encLabel, anzLabel, eLabel;
	Button pabTestButton, lsgButton,
		pointButton, alphaTestButton, multButton,
		encryptButton, decryptButton;
	Panel panel = new Panel();
	boolean longToBitDone = true, pabTestDone = false,
		pTestDone = false, alphaTestDone = false,
		betaTestDone = false, encryptDone = false;
	String newline = System.getProperty("line.separator");
	EllPoint alpha, beta, plain, y1, y2, xp;
	Vector points, alphaMultVector, betaMultVector, y1MultVector;
	
	
// layout   
	public void init() {
		setLayout(new GridBagLayout()); GridBagConstraints c, grid;

	    
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 0;
		c.gridwidth = 2; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST; 
		Panel p0 = new Panel();
		p0.add(new Label("W\u00e4hle p:"));
		p0.add(pField = new KeyField("11", 4));
		add(p0, c);

		c = new GridBagConstraints();
		c.gridx = 2; c.gridy = 0;
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p2 = new Panel();
		p2.add(new Label(",  A:"));
		p2.add(aField = new KeyField("1", 4));
		add(p2, c);

		c = new GridBagConstraints();
		c.gridx = 3; c.gridy = 0;
		c.gridwidth = 6; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p3 = new Panel();
		p3.add(new Label("und  B:"));
		p3.add(bField = new KeyField("6", 4));
		p3.add(new Label(" wie oben."));
		add(p3, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 1;
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p4 = new Panel();
		p4.add(pabTestButton = new Button("Test"));
		add(p4, c);

		c = new GridBagConstraints();
		c.gridx = 1; c.gridy = 1;
		c.gridwidth = 9; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p5 = new Panel();
		p5.add(pabTestArea = new TextArea("",2, 55));
		pabTestArea.setEditable(false);
		add(p5, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 2;
		c.gridwidth = 3; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p9 = new Panel();
		p9.add(new Label("Berechnung der Punkte von E:"));
		add(p9, c);

		c = new GridBagConstraints();
		c.gridx = 3; c.gridy = 2;
		c.gridwidth = 7; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p10 = new Panel();
		p10.add(pointButton = new Button("Punktberechnung"));
		add(p10, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 3;
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p11 = new Panel();
		p11.add(resPointArea = new TextArea("",6,80));
		resPointArea.setEditable(false);
		add(p11, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 4;
		c.gridwidth = 2; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p13 = new Panel();
		p13.add(new Label("W\u00e4hle x:"));
		p13.add(xField = new KeyField("2", 4));
		add(p13, c);

		c = new GridBagConstraints();
		c.gridx = 2; c.gridy = 4;
		c.gridwidth = 8; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p14 = new Panel();
		p14.add(new Label("und  y:"));
		p14.add(yField = new KeyField("7", 4));
		p14.add(new Label(" so, dass alpha = (x, y) aus E ist"));
		add(p14, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 5;
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p15 = new Panel();
		p15.add(alphaTestButton = new Button("Test von alpha"));
		add(p15, c);

		c = new GridBagConstraints();
		c.gridx = 1; c.gridy = 5;
		c.gridwidth = 9; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p16 = new Panel();
		p16.add(alphaTestField = new TextField("",55));
		alphaTestField.setEditable(false);
		add(p16, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 6;
		c.gridwidth = 4; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel q15 = new Panel();
		q15.add(new Label("W\u00e4hle Bobs geheimen Exponenten a:"));
		q15.add(secField = new KeyField("7", 2));
		q15.add(eLabel = new Label(" < #E."));
		add(q15, c);
      
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 10;
		c.gridwidth = 3; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p17 = new Panel();
		p17.add(multButton = new Button("Berechnung von beta"));
		add(p17, c);

		c = new GridBagConstraints();
		c.gridx = 3; c.gridy = 10;
		c.gridwidth = 7; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p18 = new Panel();
		p18.add(betaField = new TextField("",40));
		betaField.setEditable(false);
		add(p18, c);


		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 11; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p20 = new Panel();
		p20.add(new Label("W\u00e4hle k "));
		p20.add(kField = new KeyField("3",4));
		p20.add(anzLabel = new Label(", so dass 0 < k < #E"));
		add(p20, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 12; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p19 = new Panel();
		p19.add(new Label("W\u00e4hle den Klartext x = ("));
		p19.add(ix1Field = new KeyField("10",2));
		p19.add(new Label(", "));
		p19.add(ix2Field = new KeyField("9",2));
		p19.add(new Label("), so dass x aus E ist."));
		p19.add(encryptButton = new Button("verschl\u00fcsseln"));
		add(p19, c);


		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 13; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p21 = new Panel();
		p21.add(encryptArea = new TextArea("",6,80));
		encryptArea.setEditable(false);
		add(p21, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 14; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p22 = new Panel();
		p22.add(new Label("W\u00e4hle den Klartext y = ( ("));
		p22.add(y11Field = new KeyField("8",2));
		p22.add(new Label(", "));
		p22.add(y12Field = new KeyField("3",2));
		p22.add(new Label(") , ("));
		p22.add(y21Field = new KeyField("10",2));
		p22.add(new Label(", "));
		p22.add(y22Field = new KeyField("2",2));
		p22.add(new Label(")), so dass x aus E ist."));
		add(p22, c);


		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 15; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p222 = new Panel();
		p222.add(decryptButton = new Button("entschl\u00fcsseln"));
		add(p222, c);

		

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 16; 
		c.gridwidth = 10; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p23 = new Panel();
		p23.add(decryptArea = new TextArea("",6,80));
		decryptArea.setEditable(false);
		add(p23, c);
// register listeners
		pField.addActionListener(this);
		aField.addActionListener(this);
		bField.addActionListener(this);
		secField.addActionListener(this);
		xField.addActionListener(this);
		yField.addActionListener(this);
		pabTestButton.addActionListener(this);
		alphaTestButton.addActionListener(this);
		alphaTestField.addActionListener(this);
		pointButton.addActionListener(this);
		multButton.addActionListener(this);
		encryptButton.addActionListener(this);
		decryptButton.addActionListener(this);
	}

// listen, dispatch
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		String command = e.getActionCommand();

		if (command.equals("Test")) {
			getp();
		}
		if ((command.equals("Punktberechnung")) &&
		    (pabTestDone)) {
			computePoints();
			showPoints();
		}   
		if ((command.equals("Test von alpha")) &&
		    (pabTestDone)) {
			getalpha();
		}
		if ((command.equals("Berechnung von beta")) &&
		    (pabTestDone) && (alphaTestDone)) {
			computeBeta();
		}
		if ((command.equals("verschl\u00fcsseln")) &&
		    (pabTestDone) && (alphaTestDone) && (betaTestDone)) {
			encrypt();
		}
		if ((command.equals("entschl\u00fcsseln")) &&
		    (pabTestDone) && (alphaTestDone) &&
		    (betaTestDone) && (encryptDone)) {
			decrypt();
		}
	}
   
   
// greatest common divisor
	public long Gcd(long left, long right) {
		if (!( left > right)) {return -1;}
      
		long q = (int)Math.floor((double)(left/right)); //trunc?
		long rest = left - q * right;
		while (rest != 0) {
			left = right;
			right = rest;
			q = (int)Math.floor((double)(left/right)); //trunc?
			rest = left - q * right;
		}
		return right;
	}

// prime number test
	public boolean isPrime(long num) {
		boolean prime = true;
		if ((num < 2) | ((num % 2 ==0) && (num != 2))) { return false; }
		long root = (int)Math.sqrt((double)num);
		long i = 3;
		while (i <= root && prime) {
			if (num % i == 0) {
				prime = false;
			}
			i += 2;
		}
		return prime;
	}
   
// computes  b^(-1) (mod n)
	public long extEuclid(long b, long n) {
		if (b == 0) { return -1; }
		if ((b == -1) | (n == -1)) { return -1; }

		long n0 = n;
		long b0 = b;
		long t0 = 0;
		long t = 1;
		long q = (int)Math.floor((double)(n0/b0)); // trunc?
		long r = n0 - q * b0;
		while (r > 0) {
			long temp = t0 - q * t;
			if (temp >= 0) temp = temp % n;
			if (temp < 0) temp = n - ((-temp) % n);
			t0 = t;
			t = temp;
			n0 = b0;
			b0 = r;
			q = (long)Math.floor((double)(n0/b0));
			r = n0 - q * b0;
		}
		if (b0 != 1) {
			return -1;
		}
		else {
			return t;
		}
	}
	
// gets and tests p
	public void getp() {
		p = pField.getLongKey();
		if (! isPrime(p)) {
			pabTestArea.setText(p + " ist nicht prim.\n");
		} else {
			pabTestArea.setText("OK, " + p + " ist prim.\n");
			pTestDone = true;
			getAB();
		}
	}
	
// gets and tests A and B
	public void getAB() {
		a = aField.getLongKey();
		b = bField.getLongKey();
		test = ((4 * a * a * a) + (27 * b * b)) % p ; 
		
		if (test == 0) {
			pabTestArea.append("(4 * A^3 + 27 * B^2) ist ein Vielfaches von " + p);
		} else {
			pabTestArea.append("OK, (4 * A^3 + 27 * B^2) ist kein Vielfaches von " + p + ".");
			pabTestDone = pTestDone;
		}
	}

// computes the points on the elliptic curve E
	public void computePoints() {
		points = new Vector();
		for (int i = 0; i < p; i++) {
			long z = ((long) Math.pow(i, 3) + (a * i) + b) % p;
			long eulerTest = ((long) Math.pow(z, ((p - 1)/ 2)))
				% p;
			if ((eulerTest == 1)||(z == 0)){
				for (int j = 0; j < p; j++) {
					long quad = (j * j) % p;
					if (quad == z) {
						EllPoint ePoint =
							new EllPoint();
						ePoint.setCar(i);
						ePoint.setCdr(j);
						points.addElement(ePoint);
					}
				}
			}
		}
	}

// display the points
	public void showPoints() {
		for (int k = 0; k < points.size(); k++) {
			if ((k % 3) == 0) resPointArea.append("\n");
			resPointArea.append("P" + k);
			if (k < 10) resPointArea.append("  ");
			resPointArea.append(" = " + points.elementAt(k));
			resPointArea.append("\t\t");
		}
	}

// addition of two points of the elliptic curve
	public EllPoint addPoints(EllPoint p1, EllPoint p2) {
		long x1 = p1.getCar();
		long y1 = p1.getCdr();
		long x2 = p2.getCar();
		long y2 = p2.getCdr();
		long zaehler, tmp, nenner, lambda, x3, y3;
		EllPoint resPoint = new EllPoint();
		
		if ((x1 == 666) && (y1 == 666)) {
			return p2;
		} else if ((x2 == 666) && (y2 == 666)) {
			return p1;
		} else if ((x1 == x2) && (y1 == p-y2)) {
			x3 = 666;
			y3 = 666;
		} else if ((x1 == x2) && (y1 == y2)) {
			zaehler = ((3 * x1 * x1) + a) % p;
			tmp = (2 * y1) % p;
			nenner = extEuclid(tmp, p);
			lambda = (zaehler * nenner) % p;
			x3 = (lambda * lambda - x1 - x2) % p;
 			if (x3 < 0) x3 += p;
			y3 = (lambda * (x1 - x3) - y1) % p;
 			if (y3 < 0) y3 += p;
		} else {
			zaehler = (y2 - y1) % p;
			if (zaehler < 0) zaehler += p;
			tmp = (x2 - x1) % p;
			if (tmp < 0) tmp += p;
			nenner = extEuclid(tmp, p);
			lambda = (zaehler * nenner) % p;
			x3 = (lambda * lambda - x1 - x2) % p;
 			if (x3 < 0) x3 += p;
			y3 = (lambda * (x1 - x3) - y1) % p;
 			if (y3 < 0) y3 += p;
		}
		resPoint.setCar(x3);
		resPoint.setCdr(y3);
		return resPoint;
	}

//gets and tests alpha	
	public void getalpha() {
		alpha = new EllPoint();
		alpha.setCar(xField.getLongKey());
		alpha.setCdr(yField.getLongKey());

		EllPoint toTest = new EllPoint();
		
		for (int i = 0; i < points.size(); i++) {
			toTest = (EllPoint) points.elementAt(i);
			if (toTest.equals(alpha)) {
				alphaTestField.setText("OK, alpha ist aus E");
				alphaMultVector = new Vector();
				alphaMultVector =
					makeMultVector(alpha, points.size());
				alphaTestDone = true;
				return;
			}
		}
		alphaTestField.setText("alpha ist nicht aus E");
	}


// computes the multiples of the point ep on the elliptic curve E
	public Vector makeMultVector(EllPoint ep, int howOften) {
		EllPoint nep = ep;
		Vector testVector = new Vector();

		for (int k = 0; k < howOften; k++) {
			testVector.addElement(nep);
			nep = addPoints(nep, ep);
		}
		return testVector;
	}

// computes beta
 	public void computeBeta() {
		secExp = secField.getLongKey();
		
		beta = new EllPoint();
		beta = (EllPoint) alphaMultVector.elementAt((int) secExp - 1);
		
		betaField.setText("beta = " + secExp + " * " + alpha + " = " +
				  alphaMultVector.elementAt((int) secExp - 1));

		betaMultVector = makeMultVector(beta, points.size());
		betaTestDone = true;
 	}

// encryption of x = (x1, x2)	
	public void encrypt() {
		plain = new EllPoint();
		plain.setCar(ix1Field.getLongKey());
		plain.setCdr(ix2Field.getLongKey());

		y1 = new EllPoint();
		y2 = new EllPoint();
		EllPoint tmp = new EllPoint();
		
		k = kField.getLongKey();
		
		encryptArea.setText("e(x, k) = (y_1, y_2)  \t mit " +
				    "\t y_1 = k * alpha \t und " +
				    "\t y_2 = x + k * beta \n");
 		encryptArea.append("\t\t\t" + "        = " + k +
				   " * " + alpha);
 		encryptArea.append("\t\t" + "        = " + plain +
				   " + " + k + " * " + beta + "\n");

 		y1 = (EllPoint) alphaMultVector.elementAt((int) k - 1);
 		encryptArea.append("\t\t\t" + "        = " + y1);
		
		tmp = (EllPoint) betaMultVector.elementAt((int) k - 1);
 		encryptArea.append("\t\t" + "        = " + plain +
				   " + " + tmp + "\n");
		
 		y2 = addPoints(plain, tmp);
 		encryptArea.append("\t\t\t\t\t\t" + "        = " + y2 +
 				   " \n\n");
 		encryptArea.append("Also ist  e( " + plain + " ,  " + k +
 				   " ) = ( " + y1 + " ,  " + y2 + " ).");
 		encryptDone = true;
	}

// decryption	
	public void decrypt() {
		y1 = new EllPoint();
		y2 = new EllPoint();
		xp = new EllPoint();
		EllPoint tmp = new EllPoint();
		EllPoint tmpNeg = new EllPoint();

		y1.setCar(y11Field.getLongKey());
		y1.setCdr(y12Field.getLongKey());
		y2.setCar(y21Field.getLongKey());
		y2.setCdr(y22Field.getLongKey());

		y1MultVector = makeMultVector(y1, points.size());		
		decryptArea.setText("x = d(y1, y2) = y2 - a * y1 \t mit \t" +
				    "y1 = " + y1 + "\t und \t y2 = " + y2 +
				    ",\n\n");
		decryptArea.append("also x = " + y2 + " - " + secExp +
				   " * " + y1 + "\n" );

		tmp = (EllPoint) y1MultVector.elementAt((int) secExp - 1);
		decryptArea.append("        = " + y2 + " - " + tmp + "\n" );

		tmpNeg.setCar(tmp.getCar());
		tmpNeg.setCdr(- tmp.getCdr());

		decryptArea.append("        = " + y2 + " + " + tmpNeg + "\n" );

		xp = addPoints(y2, tmpNeg);
		decryptArea.append("        = " + xp + "\n" );
	}
}
