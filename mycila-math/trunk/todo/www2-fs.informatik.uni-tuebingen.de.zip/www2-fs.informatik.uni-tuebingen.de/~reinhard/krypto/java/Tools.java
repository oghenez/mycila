public class Tools
{
  /* returns d=gcd(x, y) using binary gcd algorithm */
  public static long binaryGcd(long x, long y)
  {
    long g = 1;
    long t;

    x = Math.abs(x);
    y = Math.abs(y);

    if (x == 0)
      return (y);

    if (y == 0)
      return (x);

    if (x < y)
    {
      long tmp = x;
      x = y;
      y = tmp;
    }

    while ( ((x & 0x01) == 0x0 ) && ((y & 0x01) == 0x0) )
    {
      x = x >> 1;
      y = y >> 1;
      g = g << 1;
    }

    while (x != 0)
    {
      while ( (x & 0x01) == 0x0) 
       x = x >> 1;

      while ( (y & 0x01) == 0x0)
        y = y >> 1;

      t = (x - y)/2;
      t = Math.abs(t);      

      if ( x >= y)
        x = t;
      else
        y = t;
    }

    return (g*y);
  }

   /* returns integers a, b, v with a*x + b*y = v */
   /* v=gcd(x, y), x > 0, y > 0 */
  public static long[] binaryExtendedGcd(long x, long y)
  {
    long g = 1, A = 1, B = 0, C = 0, D = 1;
    long u, v;
    long [] res = new long[3];

    if ( (x <= 0) || (y <= 0) )
      return (null);

    while ( ((x & 0x01) == 0x0) && ((y & 0x01) == 0x0))
    {
      x = x >> 1;
      y = y >> 1;
      g = g << 1;
    }

    u = x;
    v = y;
 
    while (u != 0)
    {
      while ( (u & 0x01) == 0)
      {
        u = u >> 1;

        if ( ((A & 0x01) == 0) && ((B & 0x01) == 0) )
        {
          A = A >> 1;
          B = B >> 1;
        }
        else
        {
          A = (A + y) >> 1;
          B = (B - x) >> 1;
        }
      }

      while ( (v & 0x01) == 0)
      {
        v = v >> 1;

        if ( ((C & 0x01) == 0) && ((D & 0x01) == 0) )
        {
          C = C >> 1;
          D = D >> 1;
        }
        else
        {
          C = (C + y) >> 1;
          D = (D - x) >> 1;
        }
      }

      if (u >= v)
      {
        u -= v;
        A -= C;
        B -= D;
      }
      else
      {
        v -= u;
        C -= A;
        D -= B;
      }
    }

    res[0] = C;		// res[0] == a
    res[1] = D;		// res[1] == b
    res[2] = g*v;	// res[2] == v

    return res;
  }

  /* returns the inverse of a (mod n): a*x = 1 (mod n) */
  public static long multInvers(long a, long n)
  {
    if (n <= 0)
      return (-1L);

    while (a <= 0)
      a+=n;

    long[] res = binaryExtendedGcd(n, a);

    if (res == null)
      return (-1);

    if (res[2] != 1)	// gcd(a, n) != 1
      return (-1);

    while (res[1] < 0)
      res[1] += n;

    return res[1];
  }

  /* returns a random number in [0, n] */
  public static long randomNumber(long n)
  {
    if (n < 0)
      return (-1);

    double tmp = Math.random();
    tmp *= (double)n;

    return (Math.round(tmp));
  }

  /* returns a random number in [m, n], m <= n */
  public static long randomNumber(long m, long n)
  {
    long res;

    if (n < m)
      return (-1);

    res = randomNumber(n-m);

    return (res+m);
  }

  /* returns log2(a) */
  public static double log2(double a)
  {
    if (a <= (double)0)
      return ((double)-1);

    return (Math.log(a) / Math.log(2));
  } /* end log2() */

  /* returns a*b mod n */
  public static long mod(long a, long b, long n)
  {
    long res = a;
    long s = 0x01L;

    long len;

    if (n<0)
      return (-1L);

    if (n==0)
      return (0);

    while (a<0)
      a+=n;

    while (b<0)
      b+=n;

    if ( (a==0) || (b==0) )
      return (0);

    len = (long) log2(b);
    len++;

    for (long i=len-2; i>=0; i--)
    {
      res = res << 1;

      if ( ((s << i) & b) != 0)
        res +=a;

      res %= n;
    }

    res %= n;

    if (res < 0)
      res += n;

    return (res);
  } /* end mod() */

  /* approximates a given double-value by a rational number r with |u-r| < eps */
  public static Rational getRational(double u, double eps)
  {
    return (contFrac(u, eps));
  } /* end getRational() */

  /* returns a rational number r with | r - val | < eps */
  private static Rational contFrac(double val, double eps)
  {
    long[] b = new long[3];
    long[] c = new long[3];
    long a;

    double x = Math.abs(val);

    if (x == 0)
      return (new Rational(0));

    a = (long) Math.floor(x);
    x -= a;

    b[0] = a;
    c[0] = 1;

    if (x == 0)
      return (new Rational(b[0], c[0]));

    a = (long) Math.floor(1/x);
    b[1] = b[0]*a +1;
    c[1] = a;
    
    b[2] = b[1];
    c[2] = c[1];

    while ( Math.abs(b[2]/(double)c[2] - val) >= eps  )
    {
      x = 1/x - a;

      if (x == 0)
        break;

      a = (long) Math.floor(1/x);

      b[2] = a*b[1] + b[0];
      c[2] = a*c[1] + c[0];
      b[0] = b[1];
      b[1] = b[2];
      c[0] = c[1];
      c[1] = c[2];

    }

    return (new Rational(b[2], c[2]));
  } /* end contFrac() */

  /* returns the String str = 0...0|s, with dim - |s| zero's */
  public static String fillString (String s, int dim)
  {
    int n = dim - s.length();	/* how many leading 0's should be added */
    String str = new String();

    for (int i=0; i<n; i++)
      str = str.concat("0");

    str = str.concat(s);

    return (str);
  } /* end fillString() */

} /* end class */
