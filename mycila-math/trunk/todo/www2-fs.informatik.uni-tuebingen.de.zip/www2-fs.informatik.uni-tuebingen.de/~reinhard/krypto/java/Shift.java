package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/Shift.java (Shift Cipher)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// shift (caesar) cipher: only shifts characters and numbers

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Shift extends Applet implements ActionListener {
   KeyField plainField, keyField, cipherField;
   Button ButtonEncrypt;
   
   //Layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("plaintext")+" m:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0; c.gridwidth = 2;
      add(plainField = new KeyField("HAL", 30), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy =1; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("key")+" s:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 1;
      add(keyField = new KeyField("1", 2), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 1; c.anchor = GridBagConstraints.EAST;
      add(ButtonEncrypt = new Button(getParameter("encrypt")), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("ciphertext") + " e(m) ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 2; c.gridwidth = 2;
      add(cipherField = new KeyField(30), c);
      cipherField.setEditable(false); // choose true to ease scrolling
    
      // register listeners
      plainField.addActionListener(this);
      keyField.addActionListener(this);
      ButtonEncrypt.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      shiftNow();
   }
   
   //shift algorithm
   public void shiftNow() {
      int shift = keyField.getKey();
      if (shift == -1) {
	 cipherField.setText("");
	 return;
      }
      char plainchar, cipherchar;
      String plaintext, ciphertext = "";
      
      for (int i=0; i < plainField.getText().length(); i++) {
	 plainchar = (plainField.getText().charAt(i));             
	 cipherchar = Helpers.shiftSingle(plainchar, shift);
	 ciphertext += String.valueOf(cipherchar);
	 
	 cipherField.setText(String.valueOf(ciphertext));
      }
   }
}
