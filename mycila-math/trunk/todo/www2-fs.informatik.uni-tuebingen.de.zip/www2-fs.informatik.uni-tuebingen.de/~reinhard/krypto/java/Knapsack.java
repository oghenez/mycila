public class Knapsack
{
  protected int dim;	/* number elements in Knapsack */
  protected long[] set;	/* Knapsack set */
  protected String name; /* name of elements */

  protected long MAXSTART; /* max start value if superincreasing */
  private long MAXSIZE; /* max size for elements in knapsack */

  /* empty knapsack of dimension n */
  public Knapsack(int n)
  {
    this.dim = n;
    this.set = new long[n];
    this.name = "b";

    for (int i=0; i<this.dim; i++)
      this.set[i] = 0;

    /* superincreasing: max start value for a[1] is a (54 - dim) bit number
     so that a[dim] is at most a 52 bit number */
    MAXSTART = (1L << (53 - dim)) -1;

    /* general knapsack: SUM(ai) is maximal a 60 bit number */
    int t = (int) Tools.log2(this.dim);
    t++;
    MAXSIZE = (1L << (60 - t)) -1;

    return;
  }

  /* new knapsack of dimension n with values in [1, max] */
  public Knapsack(int n, long max)
  {
    this(n);
    this.createSet(max);

    return;
  }

  public Knapsack(String[] s, String n, boolean b) throws notAKnapsackException
  {
    this(s.length);
    name = n;

    for (int i=0; i<dim; i++)
    {
      try
      {
        set[i] = Long.parseLong(s[i]);
      }
      catch (NumberFormatException nfe)
      {
        String err = name +"(" +Integer.toString(i+1);
        err += "): <" +s[i] +"> not a number\n";
        throw new notAKnapsackException(err);
      }
    }

    if (b)
      testSuperKnapsack();
    else
      testGeneralKnapsack();

    return;
  }

  private void testGeneralKnapsack() throws notAKnapsackException
  {
    String err;

    long max = MAXSIZE;

    for (int i=0; i<dim; i++)
    {
      if (set[i] <= 0)
      {
        err = name +"(" +(i+1) +"): only positive values\n";
        throw new notAKnapsackException(err);
      }
      if (set[i] > max)
      {
        err = name +"(" +(i+1) +"): choose a number <= ";
        err += Long.toString(max) +"\n";
        throw new notAKnapsackException(err);
      }

      for (int j=0; j<i; j++)
        if (set[j] == set[i])
        {
          err = name +"(" +Integer.toString(j+1) +") == ";
          err += name +"(" +Integer.toString(i+1) +")\n";
          throw new notAKnapsackException(err);
        }

    }

    return;
  }

  protected void testSuperKnapsack() throws notAKnapsackException
  {
    String err;

    long sum = set[0];
    long max = MAXSTART;

    if (sum <= 0)
    {
      err = name +"(1) <= 0: only positive starting values allowed\n";
      throw new notAKnapsackException(err);
    }

    if (set[0] > max)
    {
      err = name +"(1): choose a number <= " +max +"\n";
      throw new notAKnapsackException(err);
    }

    for (int i=1; i<dim; i++)
    {
      max = max << 1;

      if (set[i] <= sum)
      {
        err = "Knapsack not superincreasing: a(" +Long.toString(i+1);
        err += ") <= " +sum;
        throw new notAKnapsackException(err);
      }

      if (set[i] > max)
      {
        err = name +"(" +Long.toString(i+1);
        err += "): choose a number <= " +max;
        throw new notAKnapsackException(err);
      }

      sum += set[i];
    }

    return;
  }

  public void setName(String s)
  {
    this.name = s;

    return;
  }

  public long getMaxStart()
  {
    return (this.MAXSTART);
  }

  public long getMaxSize()
  {
    return (this.MAXSIZE);
  }

  public int getDim()
  {
    return (this.dim);
  }

  public long getElement(int i)
  {
    return (this.set[i]);
  }

  public void setElement(int i, long m)
  {
    this.set[i] = m;
  }

  /* get sum of all elements of this knapsack */
  public long getSum()
  {
    long sum = 0;

    for (int i=0; i<this.dim; i++)
      sum += this.set[i];

    return (sum);
  }

  /* get the density (= dimension/(log2 (max a(i))) ) of this knapsack */
  public double getDensity(int precision)
  {
    long max = this.getMaxElem();
    double dense = (double)this.dim/(Math.log(max)/Math.log(2));
    double prec = Math.pow((double)10, (double)precision);
    long tmp = Math.round(dense*prec);

    dense = tmp/prec;

    return (dense);
  }

  /* creates a random knapsack set */
  public void createSet(long max)
  {
    int i, j;
    long next;

    for(i=0; i<this.dim; i++)
    {
      next = Tools.randomNumber(1, max);

      for (j=0; j<i; j++)
      {
        if (next == this.set[j])
        {
          next = Tools.randomNumber(1, max);
          j=-1;
        }
      }

      this.set[i] = next;
    }

    return;
  }

  /* is this knapsack a superincreasing one? */
  public boolean isSuperInc()
  {
    if (this.dim == 0)
      return (true);

    long sum = this.set[0];

    for (int i=1; i<this.dim; i++)
    {
      if (sum >= this.set[i])
        return (false);

      sum += this.set[i];
    }

    return (true);
  }

  public void getSuperInc(long start)
  {
    if (start <= 0)
      return;

    /* t is the bitlength of start */
    long t = (long) Tools.log2((double) start);
    t++;
    t = 0x01L << t;

    this.set[0] = start;
    long sum = this.getElement(0);

    /* choose set[i] to be a (t+i)-bit number so that set[i] > sum */
    for (int i=1; i<this.dim; i++)
    {
      this.set[i] = Tools.randomNumber(Math.max(sum+1, t), (t << 1) -1);
      sum += this.getElement(i);

      t = t << 1;
    }

    return;
  } /* end getSuperInc() */

  /* chiffre = p(i)*this.set[i] */
  public long encrypt(long plain)
  {
    long chiffre = 0L;
    int i = this.dim;

    for (--i; i>=0; i--)
    {
      if ((plain & 0x01) != 0)
        chiffre += this.set[i];

      plain = plain >> 1;
    }

    return (chiffre);
  } /* end encrypt() */

  public String toString()
  {
    String out = new String();

    for (int i=0; i<this.dim; i++)
      out += name +"(" +(i+1) +"):\t" +this.set[i] +"\n";

    return (out);
  }

  private long getMaxElem()
  {
    int index = 0;

    for (int i=1; i<this.dim; i++)
      if (this.set[i] > set[index])
        index = i;

    return (this.set[index]);
  }

  public boolean equals(Knapsack k)
  {
    if (k == null)
      return (false);

    if (dim != k.dim)
      return (false);

    for (int i=0; i<dim; i++)
      if (set[i] != k.set[i])
        return (false);

    return (true);
  }
} /* end class Knapsack */
