package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/haeusser/krypto/
// Vigenere.java (Vigenere Cipher)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// vigenere cipher only shifts characters and numbers
// key must be a word

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Vigenere extends Applet implements ActionListener {
   TextField plainfield, keyfield, cipherfield;
   Button buttonEncrypt;
   
   public void init() {
      setLayout(new GridBagLayout());
      GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("plaintext")+" m:"), c);
      
      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0; c.anchor = GridBagConstraints.EAST;
      c.gridwidth = 2;
      add(plainfield = new TextField("Vigenere", 30), c);
      plainfield.setEditable(true);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("key")+" s:"), c);
      
      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(keyfield = new TextField("dabei", 12), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 1; c.anchor = GridBagConstraints.EAST;
      add(buttonEncrypt = new Button(getParameter("encrypt")), c);
    
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.EAST;
      add(new Label(getParameter("ciphertext") + " e(m) ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(cipherfield = new TextField(30), c);
      cipherfield.setEditable(false); // choose true to ease scrolling


   // register listeners
   plainfield.addActionListener(this);
   buttonEncrypt.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      encrypt();
   }
   
   public void encrypt() {
      int keyPos=0;
      String ciphertext = "";
      char plainchr, cipherchr;
      
      String key = keyfield.getText();
      if (key.equals("")) {key="a";} // in case key is empty
      String plaintext = plainfield.getText();
      
      for (int t=0; t < plaintext.length(); t++) {
	 int shift = Helpers.chrIndex((char)key.charAt(keyPos)) + 1;
	 plainchr = plaintext.charAt(t);
	 cipherchr = Helpers.shiftSingle(plainchr,shift); // a = 1 (!= 0)
	 ciphertext += cipherchr;
	 keyPos = ++keyPos % key.length(); // next char in the key
      }
      cipherfield.setText(ciphertext);
   }
}


