package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/haeusser/krypto/
// java/Substitution.java (Substitution Cipher)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// subst cipher only shifts characters and numbers

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Substitution extends Applet implements ActionListener {
   int cipherint, plainint, shift, keyPos;
   TextField cipherField, plainField, abcField, keyField;
   Button encryptButton;
   
   // Layout
   public void init() {
      setLayout(new GridBagLayout());
      GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("plaintext")+" m:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0; c.gridwidth = 3;
      add(plainField = new TextField("SUBSTITUTION", 32),c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("ciphertext") + " e(m) ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 1; c.gridwidth = 3;
      add(cipherField = new TextField(32), c); 
      cipherField.setEditable(false); // choose true to ease scrolling

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2;
      c.gridwidth = 4; c.anchor = GridBagConstraints.WEST;
      add(encryptButton = new Button(getParameter("encrypt")), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 3; c.gridwidth = 2;
      c.anchor = GridBagConstraints.EAST;
      add(abcField = new TextField("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), c);
      abcField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 4;
      add(new Label(getParameter("subst")+":"), c);
      
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 4; c.gridwidth = 2;
      c.anchor = GridBagConstraints.EAST;
      add(keyField = new TextField("DLRYVOHEZXWPTBGFJQNMUSKACI"), c);
      keyField.setEditable(true);
      
     
      //register listeners
      plainField.addActionListener(this);
      keyField.addActionListener(this);
      encryptButton.addActionListener(this);
}

   // checks if every character occurs exactly once in s
   public boolean isValidKey(String s) {
      if (s.length() != 26) return false;
      for (int t=0; t<26; t++) {
	 if (s.indexOf(numToChar(t)) == -1) return false;
      }
      return true;
   }

   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      substitute();
   }
   
   
   // substitute algorithm
   public void substitute() {
      String plaintext = plainField.getText(), ciphertext = "",
	 key = (keyField.getText().toUpperCase().trim());
      char plainchr=0, cipherchr=0;
      if (!isValidKey(key)) {
	 ciphertext = getParameter("invalidKey");
      }
      else {
	 for (int t=0; t < plaintext.length(); t++) {
	    plainchr = plaintext.charAt(t);
	    if (Character.isLetter(plainchr))
	       cipherchr = key.charAt(chrIndex(plainchr));
	    else cipherchr = plainchr;
	    
	    ciphertext += cipherchr;
	 }
      }
      cipherField.setText(ciphertext);
   }


   // 0..25 -> A..Z
   char numToChar(int i) {
      if ((i < 0) && (i > 25)) i=0;
      return (char) (i + 'A') ;
   }

   // a,A -> 0, ..., z,Z -> 25, rest -> 0
   public static int chrIndex(char c) {
      int numA = (int)'A';
      int numa = (int)'a';
      if (Character.isUpperCase(c)) {
	 return (c - numA);
      }
      if (Character.isLowerCase(c)) {
	 return (c - numa);
      }
      else return 0;
   }
}
