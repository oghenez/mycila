public class Rational
{
  private long n; /* numerator */
  private long d; /* denominator */

  Rational (long n, long d)
  {
    this.n = n;
    this.d = d;

    this.norm();
  }

  Rational (long n)
  {
    this.n = n;
    this.d = 1;
  }

  Rational (Rational r)
  {
    this.n = r.n;
    this.d = r.d;

    this.norm();
  }

  public double toDouble()
  {
    return (this.n / (double) this.d);
  }

  public void min(Rational r)
  {
    if (r.toDouble() >= this.toDouble())
      return;

    this.n = r.n;
    this.d = r.d;

    return;
  }

  public void max(Rational r)
  {
    if (this.toDouble() >= r.toDouble())
      return;

    this.n = r.n;
    this.d = r.d;

    return;
  }

  public long getN()
  {
    return (this.n);
  }

  public long getD()
  {
    return (this.d);
  }

  public void setN(long n)
  {
    this.n = n;
  }

  public void setD(long d)
  {
    this.d = d;
  }

  private void norm()
  {
    if (this.d < 0)
    {
      this.n = -this.n;
      this.d = -this.d;
    }

    return;
  }

  public void cancel()
  {
    long d = Tools.binaryGcd(this.n, this.d);

    this.n /= d;
    this.d /= d;

    return;
  }

  public String toString()
  {
    this.norm();
      
    return new String(this.n +"/" +this.d);
  }

} /* end class */