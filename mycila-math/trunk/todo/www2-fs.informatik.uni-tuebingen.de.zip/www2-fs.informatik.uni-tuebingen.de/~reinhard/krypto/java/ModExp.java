package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/ModExp.java (Modulares Potenzieren)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ModExp extends Applet implements ActionListener {
   long x,b,n;
   KeyField xField, bField, nField;
   TextField binField;
   TextArea comp;
   Button startButton;
   String newline = System.getProperty("line.separator");

   // layout
   public void init() {
      setLayout(new GridBagLayout());
      GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label("x:"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0;
      add(xField = new KeyField("9726",8), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label("b "+getParameter("decimal")+":"), c);

      c = new GridBagConstraints();
      c.gridx = 3; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(bField = new KeyField("3533",8), c);

      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 0;
      add(new Label("n:"), c);

      c = new GridBagConstraints();
      c.gridx = 5; c.gridy = 0;
      add(nField = new KeyField("11413",8), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.gridwidth = 2;
      c.anchor = GridBagConstraints.CENTER;
      add(startButton = new Button(getParameter("start")), c);
      
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(new Label("b "+getParameter("binary")+" ="), c);

      c = new GridBagConstraints();
      c.gridx = 3; c.gridy = 1; c.gridwidth = 3;
      c.anchor = GridBagConstraints.WEST;
      add(binField = new TextField("",24), c);
      binField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.gridwidth = 6;
      c.anchor = GridBagConstraints.WEST;
      add(comp = new TextArea("",25,51), c); 
      
      // register listeners
      xField.addActionListener(this);
      bField.addActionListener(this);
      nField.addActionListener(this);
      startButton.addActionListener(this);
}

   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      modexp();
   }

   // modexp algorithm
   public void modexp() {
      	 x = xField.getLongKey();
	 b = bField.getLongKey();
	 n = nField.getLongKey();
	 int pos, first = 2;
	 
	 String bin = Long.toBinaryString(b);
	 binField.setText(bin);

	 comp.setText(" (i) b"+newline+newline);
	 long z = 1;
	 for (int i = 0; i < bin.length(); i++) { // internal string index
	    char bi = bin.charAt(i);
	    pos = bin.length() -i -1; // index as to algorithm
	    if (pos < 10) { comp.append(" "); };
	    comp.append("(" + (pos) + ") " + bi);

	    // square
	    comp.append(" z = "+ z +" ** 2");
	    if (first > 0) { first--; comp.append(" mod "+ n); }
	    z = Helpers.mod(z,z,n);
	    comp.append(" = " + z + newline);

	    // maybe multiply
	    if (bi == '1') {
	       comp.append("       z = "+ z +" * "+ x);
	       z = Helpers.mod(z,x,n);
	       if (first > 0) { first = 0; comp.append(" mod "+ n); }
	       comp.append(" = "+ z + newline);
	    }
	 }
   }
}

