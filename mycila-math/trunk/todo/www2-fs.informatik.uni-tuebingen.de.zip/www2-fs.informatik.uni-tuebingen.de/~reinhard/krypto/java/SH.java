import java.util.*;
import java.lang.*;
import lp.*;

public class SH implements constant, Runnable
{
  private long[] t;
  private long[] b;
  private Vector pList; /* to hold the accumulation points */
  private Vector sList; /* sorted minima in increasing order */

  private double delta; /* used for finding accumulation points */
  private int dim;

  private long maxP; /* maximal number of accumulation points to be found */
  private int lastIndexOfFunction; /* last function being updated */
  private long currP;
  private long numP;
  private int width = 3000;
  private int recDepth = (width << 1);

  private String message;
  private boolean READ = true;


  SH(Knapsack k)
  {
    dim = k.getDim();

    b = new long[dim];

    for (int i=0; i<dim; i++)
      b[i] = k.getElement(i);

    delta = Math.sqrt(b[0]/2.0);
    maxP = 50;
    numP = 0;

    return;
  }


  public synchronized void putNextMessage()
  {
    READ = false;
    notify();

    while (READ == false)
    {
      try
      {
        wait();
      }
      catch (InterruptedException ie)
      {
        System.err.println(ie);
      }
    }

    return;
  }


  public synchronized String getNextMessage()
  {
    while (READ)
    {
      try
      {
        wait();
      }
      catch (InterruptedException ie)
      {
        System.err.println(ie);
      }
    }

    String tmp;

    if (message != null)
      tmp = new String(message);
    else
      tmp = null;
 
    READ = true;
    notify();

    return (tmp);

  } 

  public void run()
  {
    try
    {
      getAccPoints();
    }
    catch (InterruptedException e)
    {
      System.out.println("Ausnahme bei getAccPoints():\n<" +e +">\n");
    }
    catch (StackOverflowError s)
    {
      int d = Integer.parseInt(s.getMessage());

      message = "StackOverflow at depth " +d;

      putNextMessage();
      message = null;
      putNextMessage();
    }
    catch (Error e)
    {}
    catch (Exception e)
    {}

    return;
  }


  public double getDelta(int prec)
  {
    double f = Math.pow((double) 10, (double) prec);
    long l = Math.round(f*this.delta);

    return (l/f);
  }


  public void setMaxP(long p)
  {
    this.maxP = p;

    return;
  }


  public long getMaxP()
  {
    return (this.maxP);
  }


  public int getWidth()
  {
    return (width);
  }

  public void setWidth(int w)
  {
    if (w <= 0)
      return;

    width = w;
    recDepth = w << 1;

    return;
  }

  public Vector getPList()
  {
    return (this.pList);
  }


  /* get values p, q, r such that |b[0]*q -b[1]*p| < delta and |b[0]*r - b[2]*p < delta */
  private synchronized void getAccPoints() throws InterruptedException
  {
    solve lpSolve = new solve();
    this.pList = new Vector();
    numP = 0;
    message = "";

    final int VAR = 3;

    long p = this.b[0];

    long[] pqr = new long[VAR];
    double[] x = new double[VAR+1];
    double rhs;

    long lower = 1; /* lower and upper bounds */
    long upper = b[0]-1;

    /* split a big problem to smaller ones */
    long iter = (p - 1) / width;

    if (this.b[0] == 1)
    {
      message = null;
      putNextMessage();

      return;
    }

    /* first parameter: number of constraints, second parameter: number of variables */
    lprec lpIn = new lprec(2*(VAR-1), VAR);

    /* function to minimize: x[1]  */
    x[1] = 1;
    x[2] = 0;
    x[3] = 0;
    lpSolve.set_obj_fn(lpIn, x);
    lpSolve.set_minim(lpIn);

    /* add constraints */
    /* x[1]*b[1] - x[2]*b[0] <= delta */
    x[1] = b[1];
    x[2] = -p;
    x[3] = 0;
    rhs = this.delta;
    lpSolve.add_constraint(lpIn, x, LE, rhs);

    /* x[1]*b[1] - x[2]*b[0] >= -delta */
    x[1] = b[1];
    x[2] = -p;
    x[3] = 0;
    rhs = -this.delta;
    lpSolve.add_constraint(lpIn, x, GE, rhs);

    /* x[1]*b[2] - x[3]*b[0] <= delta */
    x[1] = b[2];
    x[2] = 0;
    x[3] = -p;
    rhs = this.delta;
    lpSolve.add_constraint(lpIn, x, LE, rhs);

    /* x[1]*b[2] - x[3]*b[0] >= -delta */
    x[1] = b[2];
    x[2] = 0;
    x[3] = -p;
    rhs = -this.delta;
    lpSolve.add_constraint(lpIn, x, GE, rhs);

    /* all variables must be integers */
    lpSolve.set_int(lpIn, 1, TRUE);
    lpSolve.set_int(lpIn, 2, TRUE);
    lpSolve.set_int(lpIn, 3, TRUE);

    /* set bounds for 1st variable */
    lpSolve.set_lowbo(lpIn, 1, 1);

    /* set upper bound for variables */
    lpSolve.set_upbo(lpIn, 1, upper);

    /* set bounds for 2nd variable */
    if (b[1] == 1)
    {
      lpSolve.set_lowbo(lpIn, 2, 0);
      lpSolve.set_upbo(lpIn, 2, 0);
    }
    else
    {
      lpSolve.set_lowbo(lpIn, 2, 1);
      lpSolve.set_upbo(lpIn, 2, b[1]-1);
    }

    /* set bounds for 3rd variable */
    if (b[2] == 1)
    {
      lpSolve.set_lowbo(lpIn, 3, 0);
      lpSolve.set_upbo(lpIn, 3, 0);
    }
    else
    {
      lpSolve.set_lowbo(lpIn, 3, 1);
      lpSolve.set_upbo(lpIn, 3, b[2]-1);
    }

    lpSolve.setDepth(recDepth);

    for (int j=0; j<iter; j++)
    {
      upper = (j+1)*width;
      lower = (j*width) +1;

      if ( (j%10) == 0)
      {
        long up = Math.min(lower -1 + 10*width, b[0] -1);
        message = "searching p in [" +lower +", " +up +"]\n";
        putNextMessage();
      }

      lpSolve.set_upbo(lpIn, 1, upper);
      lpSolve.set_lowbo(lpIn, 1, lower);

      while (numP < this.maxP)
      {
        int result = lpSolve.solve(lpIn);

        if (result == constant.OPTIMAL)
        {
          for (int i=1; i<=VAR; i++)
            pqr[i-1] = Math.round(lpIn.getBestSolution(lpIn.getRows() + i));

          this.append(pqr);
          message = createMessage(pqr);
          putNextMessage();

          if (pqr[0] == upper) /* don't increase lower bound because then lower bound > upper bound */
            break;

          lower = pqr[0] +1;
          lpSolve.set_lowbo(lpIn, 1, lower);
        }
        else
          break;

      } /* end while */

      if (numP >= this.maxP)
        break;

    } /* end for */

    /* last interval to scan */
    upper = this.b[0] -1;
    lower = Math.min((iter*width) +1, upper);

    lpSolve.set_upbo(lpIn, 1, upper);
    lpSolve.set_lowbo(lpIn, 1, lower);

    while (numP < this.maxP)
    {
      int result = lpSolve.solve(lpIn);

      if (result == constant.OPTIMAL)
      {
        /* if pqr[i] is 'near' but not an integer */
        for (int i=1; i<=VAR; i++)
          pqr[i-1] = Math.round(lpIn.getBestSolution(lpIn.getRows() + i)); 

        this.append(pqr);
        message = createMessage(pqr);
        putNextMessage();

        /* don't increase lowerbound because then lowerbound > upperbound */
        if (pqr[0] == upper)
          break;

        lower = pqr[0] +1;
        lpSolve.set_lowbo(lpIn, 1, lower);
      }
      else
        break;

    } /* end while */

    message = null;
    putNextMessage();

    return;

  } /* end getAccPoints() */


  private void append(long[] pqr)
  {
    long[] p = new long[pqr.length];

    for (int i=0; i<p.length; i++)
      p[i] = pqr[i];

    this.pList.addElement((Object) p);
    numP++;

    return;
  }


  private String createMessage(long[] pqr)
  {
    String s = "\t" +Long.toString(numP) +". " +Long.toString(pqr[0]);
    s += " (" +Long.toString(pqr[1]) +" , " +Long.toString(pqr[2]) +")\n";

    return (s);
  }


  /* get the number of minima of all functions in ] 0 , p(pIndex)/b0 [ */
  public void get_tValues(int pIndex)
  {
    if ( (pIndex >= numP) | (pIndex < 0) )
      return;

    this.t = new long[this.dim];
    this.currP = ((long[]) this.pList.elementAt(pIndex))[0];

    long last;
    double tmp;

    for (int i=0; i<dim; i++)
    {
      tmp = this.b[i]*this.currP;
      tmp /= (double) this.b[0];

      /* 'last'/bi is the last minimum of fi in ]0, currP/b0[ */
      last = (long)Math.floor(tmp);

      if ( (tmp - (double) last) == 0)
        last--;

      this.t[i] = last;
    }

    return;
  } /* end get_tValues() */


  /* vector[i] contains all minima of function i in [p(index)/b0, p(index+1)/b0[ */
  private Vector[] getList(int pIndex)
  {
    if ( (pIndex >= numP) | (pIndex < 0) )
      return (null);

    this.get_tValues(pIndex);

    Vector[] vList = new Vector[dim];
    this.currP = ((long[]) this.pList.elementAt(pIndex))[0];

    long first, last;
    double tmp;

    for (int i=0; i<dim; i++)
    {
      /* get first minimum of function f_i in [ p/b0, (p+1)/b0 [ */
      first = this.t[i]+1;

      /* get last minimum of function f_i in [p/b0, (p+1)/b0 [ */
      tmp = (this.currP+1)*this.b[i] / (double) this.b[0];
      last = (long)Math.floor(tmp);

      /* if last minimum of f_i equals (p+1)st accumulation point of f1*/
      if ( (tmp - (double) last) == 0)
        last--;

      vList[i] = new Vector();

      /* vec[i] contains all mimima of function i in [ p/b[0], (p+1)/b[0] [ */
      for (long j=first; j<=last; j++)
        vList[i].addElement((Object)new Rational(j, this.b[i]));

    }

    return (vList);    
  } /* end getList() */


  /* sorted list of minima of all functions in [ p(index)/b0, p(index+1)/b0 [ */
  public Vector getMinimaList(int pIndex)
  {
    if ( (pIndex >=numP ) | (pIndex < 0) )
      return(null);

    Vector[] vList = this.getList(pIndex);

    if (vList == null)
      return (null);

    vNode v;
    this.sList = new Vector();

    int total = 0;
    int i, j, k;
    int minIndex = 0;

    Rational r, min = new Rational(1);

    for (i=0; i<dim; i++)
      total += vList[i].size();

    for (i=0; i<total; i++)
    {
      for (j=0; j<dim; j++)
      {
        if (vList[j].size() == 0)
          continue;

        min = (Rational) vList[j].elementAt(0);
        minIndex = j;

        break;
      }

      for (k = j+1; k<dim; k++)
      {
        if (vList[k].size() == 0)
          continue;

        r = (Rational) vList[k].elementAt(0);
        
        if ( r.toDouble() < min.toDouble() )
        {
          min = r;
          minIndex = k;
        }
      }

      min = (Rational) vList[minIndex].elementAt(0);
      v = new vNode(minIndex, min);
      this.sList.addElement((Object)v);

      vList[minIndex].removeElementAt(0);
    }

    /* last minimum is (currP+1) / b[0] */
    v = new vNode(0, new Rational(this.currP+1, b[0]));
    this.sList.addElement((Object) v);

    return (this.sList);
  } /* end getVList() */


  /* check if there is a valid interval in which SUM(fi) < 1 and fi is superincreasing */
  public Rational[] getInterval(int vIndex)
  {
    long bSum, tSum;
    Rational u;
    Rational r[] = nextInterval(vIndex);

    if (r == null)
      return (null);

    bSum = this.b[0];
    tSum = this.t[0];

    /* check whether or not the functions form a superincreasing sequence */
    /* fi(u) = b[i]*u - t[i] with t[i] the number of minima of fi in ] 0, left [ */
    for (int i=1; i<this.dim; i++)
    {
      if (b[i] == bSum)
        return (null);

      u = new Rational(this.t[i] - tSum, this.b[i] - bSum);

      if ( (this.b[i] - bSum) > 0)
        r[0].max(u);
      else
        r[1].min(u);

      if (!isValidInterval(r))
        return (r);

      bSum += this.b[i];
      tSum += this.t[i];
    }

    /* check if SUM(f(i)) < 1 */
    if (bSum == 0)
      return (null);

    u = new Rational(tSum +1, bSum);

    if (bSum > 0)
      r[1].min(u);
    else
      r[0].max(u);

    return (r);

  } /* end getInterval() */


  private boolean isValidInterval(Rational[] r)
  {
    if (r == null)
      return (false);    

    if ( r[0].toDouble() >= r[1].toDouble() )
      return (false);

    return (true);
  }


  /* next v-interval to check */
  private Rational[] nextInterval(int vIndex)
  {
    if (sList == null)
      return (null);

    if (vIndex >= sList.size() -1)
      return (null);

    Rational[] r = new Rational[2];

    vNode v = (vNode) this.sList.elementAt(vIndex);
    r[0] = new Rational(v.getRational());

    /* increase t-value for function, which has a minimum at r[0] */
    this.t[v.getIndex()]++;
    lastIndexOfFunction = v.getIndex();

    v = (vNode) this.sList.elementAt(++vIndex);
    r[1] = new Rational(v.getRational());

    return (r);
  }

  /* function in current v-interval */
  public String getFunction(int fIndex)
  {
    if (fIndex >= dim)
      return (null);

    String out = "f" +Integer.toString(fIndex+1) +"(u) = ";
    out += this.b[fIndex] +"*u - " +this.t[fIndex];

    return (out);
  }

  /* constraints in current v-interval */
  public String constraintsToString(Rational[] u)
  {
    String out = new String();

    long bSum = b[0];
    long tSum = t[0];

    Rational left = new Rational(u[0]);
    Rational right = new Rational(u[1]);
    Rational r;

    out = "SUPERINCREASING:\n";
    /* superincreasing properties */
    for (int i=1; i<dim; i++)
    {
      out += "f" +(i+1) +" > SUM(fj), j = 1 ... " +i +":\n\t";
      out += b[i] +"*u -" +t[i] +" > " +bSum +"*u ";
      if (tSum >= 0)
        out += "-";

      out += tSum;
      out += " ==> ";

      if ((b[i] - bSum) > 0)
      {
        out += "u > ";
        r = new Rational(t[i]-tSum, b[i]-bSum);
        out += r.toString();
        left.max(r);
      }
      else
      {
        out += "u < ";
        r = new Rational(t[i] - tSum, b[i] - bSum);
        out += r.toString();
        right.min(r);
      }

      out += "\n\t==> new interval ] " +left.toString() +" , " +right.toString() +" [\n";
      bSum += b[i];
      tSum += t[i];
    }

    out += "\nSUM(fi) < 1:\n";
    out += bSum +"*u -" +tSum +" < 1 ==> u < ";
    r = new Rational(1 + tSum, bSum);
    out += r.toString();
    right.min(r);
    out += "\n\t==> final interval ] " +left.toString() +" , " +right.toString() +" [\n";  

    return (out);
  } /* end constraintsToString() */


  /* only one function has been changed in current v-interval */
  public String getChangedFunction()
  {
    String out = "f" +Integer.toString(lastIndexOfFunction+1) +"(u) = ";
    out += this.b[lastIndexOfFunction] +"*u - " +this.t[lastIndexOfFunction];

    return (out);
  }

  public String inequalToString()
  {
    String out = "Inequalities to be solved:\n";
    out += "\n| " +this.b[1] +"*p - " +this.b[0] +"*q | < " +getDelta(6);
    out += "\n| " +this.b[2] +"*p - " +this.b[0] +"*r | < " +getDelta(6);
    out += "\n\t1 <= p < " +this.b[0];
    out += "\n\t1 <= q < " +this.b[1];
    out += "\n\t1 <= r < " +this.b[2];

    return (out);
  } /* end inequalToString() */

} /* end class SH */
