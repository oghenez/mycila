public class Lattice
{
  private myVector[] lattice; /* the lattice */
  private int row; /* number rows of the lattice */
  private int col; /* number columns of the lattice */

  static final int RUNALL = 0;

  /* new lattice with r rows and c columns */
  public Lattice (int r, int c)
  {
    lattice = new myVector[r];

    for (int i=0; i<r; i++)
      lattice[i] = new myVector(c);

    row = r;
    col = c;

    return;
  }

  /* create a lattice for a given knapsack */
  public Lattice(Knapsack k, long s)
  {
    this(k.getDim() + 1, k.getDim() + 1);

    int i=0, j=0;

    double d = Math.sqrt(k.getDim());
    d = Math.ceil(0.5*d);

    for (i=0; i<k.getDim(); i++)
    {
      for (j=0; j<k.getDim(); j++)
      {
        if (i==j)
          this.setElement(i, j, 1);
        else
          this.setElement(i, j, 0);
      }

      this.setElement(i, j, d*k.getElement(i));
    }

    for (j=0; j<k.getDim(); j++)
      this.setElement(i, j, (double)1/2);

    this.setElement(i, j, d*s);

    return;
  }

  public Lattice(Lattice lat)
  {
    this(lat.getRows(), lat.getCols());

    for (int i=0; i<this.row; i++)
      this.setRow(i, lat.lattice[i]);

    return;
  }

  private void setRow(int r, myVector m)
  {
    for (int i=0; i<m.getDim(); i++)
      lattice[r].setElement(i, m.getElement(i));

    return;
  }

  public myVector getRow(int r)
  {
    myVector myVec = new myVector(lattice[r]);

    return (myVec);
  }

  public void setElement(int r, int c, double d)
  {
    lattice[r].setElement(c, d);

    return;
  }

  public double getElement(int r, int c)
  {
    return (lattice[r].getElement(c));
  }

  public int getCols()
  {
    return (this.col);
  }

  public int getRows()
  {
    return (this.row);
  }

  public String toString(String name)
  {
    String res = "";

    for (int i=0; i<row; i++)
    {
      res += name +"(" +Integer.toString(i+1) +"):\t";

      for (int j=0; j<col; j++)
        res += this.lattice[i].getElement(j) +"\t";

      res += "\n";
    }

    return (res);
  }

  /* reduce this lattice */
  public void reduce(int step)
  {
    if (step < 0)
      return;

    if (step == RUNALL)
      L3Reduce(this.getRows() -1);
    else
      step = Math.min(step, this.getRows() -1);

    L3Reduce(step);

    return;
  }

  private void L3Reduce(int step)
  {
    int len = this.getRows();
    int n = len - 1;
    int k;

    myVector[] b_s = new myVector[this.getRows()];

    double[] B = new double[len];
    double[][] mue = new double[len][len];

    /* 1. */
    b_s[0] = new myVector(this.lattice[0]);
    B[0] = b_s[0].innerProd(b_s[0]);

    /* 2. */
    for (int i=1; i<=n; i++)
    {
      /* 2.1 */
      b_s[i] = new myVector(this.lattice[i]);

      /* 2.2 */
      for (int j=0; j<i; j++)
      {
        mue[i][j] = (this.lattice[i]).innerProd(b_s[j]);
        mue[i][j] /= B[j];

        b_s[i] = b_s[i].sub( b_s[j].scalarMult(mue[i][j]) );
      }

      /* 2.3 */
      B[i] = b_s[i].innerProd(b_s[i]);
    }

    /* 3. */
    k = 1;

    /* 4.  */
    do
    {
      red(k, k-1, mue);

      /* 5. */
      if (B[k] < (0.75 - (mue[k][k-1]*mue[k][k-1])) * B[k-1] )
      {
        /* 5.1 */
        double mu = mue[k][k-1];
        double tmpB = B[k] + mu*mu*B[k-1];

        mue[k][k-1] = mu*B[k-1];
        mue[k][k-1] /= tmpB;

        B[k] = B[k-1]*B[k];
        B[k] /= tmpB;

        B[k-1] = tmpB;

        /* 5.2 */
        myVector tmp_vec = this.lattice[k];
        this.lattice[k] = this.lattice[k-1];
        this.lattice[k-1] = tmp_vec;

        /* 5.3 */
        if (k > 1)
        {
          for (int j=0; j<k-1; j++)
          {
            double tmp_d = mue[k][j];
            mue[k][j] = mue[k-1][j];
            mue[k-1][j] = tmp_d;
          }
        }

        /* 5.4 */
        for (int i=k+1; i<=n; i++)
        {
          double t = mue[i][k];
          mue[i][k] = mue[i][k-1] - (mu*t);
          mue[i][k-1] = t + mue[k][k-1]*mue[i][k];
        }

        /* 5.5 */
        k = Math.max(1, k-1);

        /* 5.6 */
        continue;

      } /* end if */
      else
      {
        for (int i=k-2; i>=0; i--)
          red(k, i, mue);

        k++;
      } /* end else */
    }
    while (k <= step);

    return ;
  }


  private void red(int k, int l, double[][] mue)
  {
    double r;

    if ( !(Math.abs(mue[k][l]) > 0.5) )
      return;

    r = Math.floor(0.5 + mue[k][l]);
    this.lattice[k] = (this.lattice[k]).sub((this.lattice[l]).scalarMult(r));

    for (int j=0; j<=l-1; j++)
      mue[k][j] = mue[k][j] - mue[l][j]*r;

    mue[k][l] = mue[k][l] - r;

    return;
  }

} /* end class Lattice */