package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/ExtEuclid.java (RSA)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

import java.awt.*;
import java.applet.*;
import java.lang.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExtEuclid extends Applet implements ActionListener {
   KeyField bField, nField;
   TextArea steps;
   Button ButtonStart;
   
   // layout
   public void init() {
      setLayout(new GridBagLayout());
      GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(new Label("b ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0;
      add(bField = new KeyField("28", 5), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0;
      add(new Label("n ="), c);

      c = new GridBagConstraints();
      c.gridx = 3; c.gridy = 0;
      add(nField = new KeyField("75", 5), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.gridwidth = 4;
      add(ButtonStart = new Button(getParameter("start")), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(steps = new TextArea(18,28), c);
      steps.setEditable(false);

      // register listeners
      bField.addActionListener(this);
      nField.addActionListener(this);
      ButtonStart.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      exteuclid();
   }

   public void exteuclid() {
      int b = bField.getKey();
      int n = nField.getKey();
      if (b == 0) {
	 steps.setText(getParameter("bnot0"));
	 return;
      }
      if ((b == -1) | (n == -1)) { return; }

      int b0 = b;
      int n0 = n;
      int t = 1;
      int q = (int)Math.floor((double)(n0/b0)); // trunc?
      int r = n0 - q * b0;
      steps.setText(" (6) "+ n +" = "+ q +" * "+ b0 +" + "+ r +"\n"); // output
      int t0 = 0;
      while (r > 0) {   // should step 12 be output?
	 int temp = t0 - q * t;
	 if (temp >= 0) temp = temp % n;
	 if (temp < 0) temp = n - ((-temp) % n);
	 t0 = t;
	 t = temp;
	 steps.append("(12) "+ t +" * "+ b +" mod "+ n +" = "+ r +"\n"); // output
	 n0 = b0;
	 b0 = r;
	 q = (int)Math.floor((double)(n0/b0));
	 r = n0 - q * b0;
	 steps.append("(16) "+ n0 +" = "+ q +" * "+ b0 +" + "+ r +"\n"); // output
      }
      if (b0 != 1) {
	 steps.append("\n" + getParameter("noInverse"));
      }
      else {
	 steps.append("\n=> " + getParameter("result") + ": " + t);
      }
   }
} 


