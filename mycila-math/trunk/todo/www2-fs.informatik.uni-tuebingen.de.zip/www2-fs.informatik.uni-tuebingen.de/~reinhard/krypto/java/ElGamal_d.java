// OK

package kryptoScript;

//
// java/ElGamal_d.java
// 
// Copyright (c) 2002 Silke Thomas
//
// last change: 24.3.2002
//

// uses "mod" (multiply a and b modulo c) from Helpers.class

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.lang.*;

public class ElGamal_d extends Applet
implements ActionListener{
	
	long p, n, alpha, a, beta, k, plain, y1, y2, gcd, yps1, yps2, res;
	KeyField pField, alphaField, aField, kField,
		plainField, yps1Field, yps2Field;
	TextField nField, test1Field, test2Field;
	TextArea betaArea, nArea, encryptArea, decryptArea;
	Label nLabel, p1Label, p2Label, lLabel;
	Button test1Button, test2Button, computeButton,
		encryptButton, decryptButton;
	Panel panel = new Panel();
	boolean longToBitDone = true, test1Done = false, test2Done = false,
		encryptDone = false;
	String newline = System.getProperty("line.separator");
  
// layout   
	public void init() {
		setLayout(new GridBagLayout()); GridBagConstraints c, grid;

	    
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 0;
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST; 
		Panel p0 = new Panel();
		p0.add(new Label("W\u00e4hle p:"));
		p0.add(pField = new KeyField("2579", 7));
		p0.add(new Label("mit (p - 1) / 2 ebenfalls prim."));
		p0.add(test1Button = new Button("Test von p"));
		p0.add(test1Field = new TextField("",18));
		test1Field.setEditable(false);
		add(p0, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 1; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p2 = new Panel();
		p2.add(new Label("N = Bitl\u00e4nge(p) = "));
		p2.add(nArea = new TextArea("",3,30));
		nArea.setEditable(false); 
		add(p2, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 2; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p3 = new Panel();
		p3.add(new Label("W\u00e4hle alpha:"));
		p3.add(alphaField = new KeyField("2", 5));
		p3.add(p1Label = new Label(" < p    "));
		p3.add(new Label("und  a:"));
		p3.add(aField = new KeyField("765", 5));
		p3.add(p2Label = new Label(" < p    "));
		add(p3, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 3; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p5 = new Panel();
		p5.add(new Label("Berechnung von beta :"));
		p5.add(computeButton = new Button("Start"));
		add(p5, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 4; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p6 = new Panel();
		p6.add(betaArea = new TextArea("",4,30));
		betaArea.setEditable(false);
		add(p6, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 5; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST; 
		Panel p7 = new Panel();
		p7.add(new Label("W\u00e4hle k:"));
		p7.add(kField = new KeyField("853", 5));
		p7.add(new Label("mit ggT( (p - 1) , k ) = 1"));
		p7.add(test2Button = new Button("Test von k"));
		p7.add(test2Field = new TextField("",31));
		test1Field.setEditable(false);
		add(p7, c);

		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 6; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p9 = new Panel();
		p9.add(new Label("Klartext:"));
		p9.add(plainField = new KeyField("1299",5));
		p9.add(encryptButton = new Button("verschl\u00fcsseln"));
		add(p9, c);
      
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 7; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p10 = new Panel();
		p10.add(encryptArea = new TextArea("",5,82));
		encryptArea.setEditable(false);
		add(p10, c);
      
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 8; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p11 = new Panel();
		p11.add(new Label("Chiffretext:    ("));
		p11.add(yps1Field = new KeyField("435",4));
		p11.add(new Label(", "));
		p11.add(yps2Field = new KeyField("2396",4));
		p11.add(new Label(") "));
		p11.add(decryptButton = new Button("entschl\u00fcsseln"));
		add(p11, c);
 
		c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 9; 
		c.gridwidth = 1; c.gridheight = 1;
		c.anchor = GridBagConstraints.WEST;
		Panel p12 = new Panel();
		p12.add(decryptArea = new TextArea("",5,82));
		decryptArea.setEditable(false);
		add(p12, c);

      
// register listeners
		pField.addActionListener(this);
		alphaField.addActionListener(this);
		aField.addActionListener(this);
		plainField.addActionListener(this);
		yps1Field.addActionListener(this);
		yps2Field.addActionListener(this);
		test1Button.addActionListener(this);
		test2Button.addActionListener(this);
		computeButton.addActionListener(this);
		encryptButton.addActionListener(this);
		decryptButton.addActionListener(this);
	}
      
// listen, dispatch
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		String command = e.getActionCommand();

		if (command.equals("Test von p")) {
			getp();
			if (test1Done) {
				computeN();
			}
		}
		if (command.equals("Test von k")) {
			getk();
		}
		if (command.equals("Start")) {
			computeBeta();

		}
		if ((command.startsWith("verschl"))
		    && (test1Done) && (test2Done)) {
			encrypt();
		}   
		if ((command.startsWith("entschl")) && encryptDone) {
			decrypt();
		}
	}
   
   
// greatest common divisor
	public long Gcd(long left, long right) {
		if (!( left > right)) {return -1;}
      
		long q = (int)Math.floor((double)(left/right)); //trunc?
		long rest = left - q * right;
		while (rest != 0) {
			left = right;
			right = rest;
			q = (int)Math.floor((double)(left/right)); //trunc?
			rest = left - q * right;
		}
		return right;
	}

// prime number test
	public boolean isPrime(long num) {
		boolean prime = true;
		if ((num < 2) | ((num % 2 ==0) && (num != 2))) { return false; }
		long root = (int)Math.sqrt((double)num);
		long i = 3;
		while (i <= root && prime) {
			if (num % i == 0) {
				prime = false;
			}
			i += 2;
		}
		return prime;
	}

// computes  b^(-1) (mod n)
	public long extEuclid(long b, long n) {
		if (b == 0) { return -1; }
		if ((b == -1) | (n == -1)) { return -1; }

		long n0 = n;
		long b0 = b;
		long t0 = 0;
		long t = 1;
		long q = (int)Math.floor((double)(n0/b0)); // trunc?
		long r = n0 - q * b0;
		while (r > 0) {
			long temp = t0 - q * t;
			if (temp >= 0) temp = temp % n;
			if (temp < 0) temp = n - ((-temp) % n);
			t0 = t;
			t = temp;
			n0 = b0;
			b0 = r;
			q = (long)Math.floor((double)(n0/b0));
			r = n0 - q * b0;
		}
		if (b0 != 1) {
			return -1;
		}
		else {
			return t;
		}
	}

// gets and tests p
	public void getp() {
		p = pField.getLongKey();
		if (! isPrime(p)) {
			test1Field.setText(p + " ist nicht prim.");
		} else if (! isPrime((p - 1)/2)) {
			test1Field.setText(((p - 1)/2) + " ist nicht prim.");
		} else {
			test1Field.setText("OK, " + (p - 1)/2 + " ist prim.");
			p1Label.setText(" < " + p);
			p2Label.setText(" < " + p);
			test1Done = true;
		}
	}

// gets and tests k	
	public void getk() {
		k = kField.getLongKey();
		gcd = Gcd((p - 1),k);
		
		if (gcd == -1) {
			test2Field.setText(k + " ist zu gro'�'.");
		} else if (gcd > 1) {
			test2Field.setText(k +
					   " ist nicht teilerfremd zu "
					   + (p -1) + ".");
		} else {
			test2Field.setText("OK, " + k + " ist zu " + (p - 1)
					   + " teilerfremd.");
			test2Done = true;
		}
	}

// computes the number of bits
	public void computeN() {
		String binp = Long.toBinaryString(p);
		nArea.setText("\n" + p + " = " + binp + "(bin)\n");
		nArea.append(" => N = " + binp.length());
	}

   
// computes beta
	public void computeBeta() {
		alpha = alphaField.getLongKey();
		a = aField.getLongKey();
		betaArea.setText("beta = alpha^a (mod p)\n");
		betaArea.append("     = " + alpha + "^"+ a +
				" (mod " + p + " )\n");
		beta = Helpers.modexp(alpha, a, p);
		betaArea.append("     = " +  beta + "\n");
	}

// encryption of x
	public void encrypt() {
		plain = plainField.getLongKey();
		if (plain == -1) { return; }
		encryptArea.setText("e(x, k) = (y1, y2)  \t mit " +
				    "\t y1 = alpha^k (mod p)\t und " +
				    "\t y2 = beta^k * x (mod p) \n");
		y1 = Helpers.modexp(alpha, k, p);
		encryptArea.append("\t\t\t" + "        = " + y1);
		if (y1 < 100) encryptArea.append("\t"); 
		encryptArea.append("\t\t\t" + "        = " + beta + "^" + k +
				   " * " + plain + " (mod p) \n");
		y2 = ((plain % p) * Helpers.modexp(beta, k, p)) % p;
		encryptArea.append("\t\t\t\t\t\t\t" + "        = " + y2 +
				   " \n\n");
		encryptArea.append("Also ist  e(" + plain + ", " + k +
				   ") = (" + y1 + ", " + y2 + ").");
		encryptDone = true;
	}
   
// decryption decryption of y = (y1, y2)
	public void decrypt() {
		yps1 = yps1Field.getLongKey();
		yps2 = yps2Field.getLongKey();
		long tmp = Helpers.modexp(yps1, a, p);
		res = ((yps2 % p) * extEuclid(tmp, p)) % p;

		decryptArea.setText("\nd(y1, y2) = y2 * (y1^a)^(-1) " +
				    "(mod p)\n\n");
		decryptArea.append("Also gilt:  d(" + yps1 + ", " + yps2
				   + ") = " + yps2 + " * (" + y1 + "^" + a +
				   ")^(-1) (mod p) ");
		decryptArea.append("= " + res);
	}   
}





