public class notAKnapsackException extends Exception
{
  public notAKnapsackException()
  {
    super();
  }

  public notAKnapsackException(String s)
  {
    super(s);
  }

}