package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/DesKey.java (Key for Des)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// computes the 16 DES keys from input key (hex or binary)
// all binary keys are regarded as strings of 0 and 1

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.lang.Integer.*;

public class DesKey extends Applet implements ActionListener {
   TextField keyhexfield, keybinfield, keyparityfield, keyPC1field, C0field, D0field;
   TextArea keysarea;
   Button startButton, nextButton;
   boolean readyForKeys = false;
   int keynum=0;
   String key, keyWithParity, keyPC1;
   String keys[] = {"","","","","","","","","","","","","","","","",""};
   String C[] = {"","","","","","","","","","","","","","","","",""};
   String D[] = {"","","","","","","","","","","","","","","","",""};
   // 17 elements each
   
   //Layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(new Label(getParameter("keyhex") + ":"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(keyhexfield = new TextField("1234567890FFF8", 14), c);

      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(startButton = new Button(getParameter("start")), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("keybin") + ":"), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(keybinfield = new TextField("", 56), c);
     
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      add(new Label(getParameter("parityKey") + " ="), c);
      
      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(keyparityfield = new TextField(64), c);
      keyparityfield.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      add(new Label("(PC-1)(K) ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(keyPC1field = new TextField(56), c);
      keyPC1field.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 4; c.anchor = GridBagConstraints.WEST;
      add(new Label("C[0] ="), c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 4; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(C0field = new TextField(28), c);
      C0field.setEditable(false);
      
      c = new GridBagConstraints();
      c.gridx = 3; c.gridy = 4; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(D0field = new TextField(28), c);
      D0field.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 5; c.gridy = 4; c.anchor = GridBagConstraints.WEST;
      add(new Label("= D[0]"), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 5;
      add(new Label(" "), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 6; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(nextButton = new Button(getParameter("next")), c);
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 7; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 6; c.fill = GridBagConstraints.HORIZONTAL;
      add(keysarea = new TextArea("", 3, 65, TextArea.SCROLLBARS_NONE), c);
      keysarea.setEditable(false);
    
      // register listeners
      keyhexfield.addActionListener(this);
      keybinfield.addActionListener(this);
      startButton.addActionListener(this);
      nextButton.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      Object source = e.getSource();
      if ((source == nextButton) && (readyForKeys)) { // display next key
	 printKey();
      }
      else if (source != nextButton) { // compute all keys first
	 key = getKey(source);
	 keyWithParity = addParity(key);
	 keyparityfield.setText(keyWithParity);
	 keyPC1 = PC1(keyWithParity);
	 keyPC1field.setText(keyPC1);
	 leftShifts(keyPC1);
	 readyForKeys = true;
	 keynum=0;
	 printKey();
      }
   }
   
   // extends all strings to desired length by inserting 0s
   public String fillup(String in, int length) {
      if (in.length() < length) {
	 String temp = "";
	 for (int i=0; i < length-in.length(); i++) {
	    temp += "0";
	 }
	 return temp+in;
      }
      else return in;
   }

   // parse input key, either hex or binary
   //  the keys are split only because their numeric value is too
   // big to handle easily
   public String getKey(Object source) {
      String binkey, leftbinkey, rightbinkey, hexkey, lefthexkey, righthexkey;
      int leftvalue=0, rightvalue=0;
      if ((source == keyhexfield) | (source == startButton)) {
	 hexkey = keyhexfield.getText();
	 boolean tooshort = false;

	 if (hexkey.length() < 14) {
	    hexkey = fillup(hexkey, 14);
	    tooshort = true;
	 }

	 lefthexkey = hexkey.substring(0,7);
	 righthexkey = hexkey.substring(7,14);
	 
	 try {
	    leftvalue = Integer.parseInt(lefthexkey, 16);
	    rightvalue = Integer.parseInt(righthexkey, 16);
	 }
	 catch (NumberFormatException ex) {
	    leftvalue = 0; rightvalue = 0;
	 }
	 
	 leftbinkey = Integer.toBinaryString(leftvalue);
	 rightbinkey = Integer.toBinaryString(rightvalue);
	 leftbinkey = fillup(leftbinkey, 28);
	 rightbinkey = fillup(rightbinkey, 28);
	 binkey = leftbinkey + rightbinkey;
	 keybinfield.setText(binkey);
	 if (tooshort) { keyhexfield.setText(hexkey); }
	 return binkey;
      }

      else {
	 binkey = keybinfield.getText();
	 int binkeylength = binkey.length();
	 boolean tooshort = false;
	 
	 if (binkeylength < 56) {
	 binkey = fillup(binkey, 56);
	 tooshort = true;
	 }
	 
	 leftbinkey = binkey.substring(0,28);
	 rightbinkey = binkey.substring(28,56);
	 
	 try {
	    leftvalue = Integer.parseInt(leftbinkey, 2);
	    rightvalue = Integer.parseInt(rightbinkey, 2);
	 }
	 catch (NumberFormatException ex) {
	    leftvalue = 0; rightvalue = 0;
	 }
	 
	 lefthexkey = Integer.toHexString(leftvalue);
	 righthexkey = Integer.toHexString(rightvalue);
	 lefthexkey = fillup(lefthexkey, 7);
	 righthexkey = fillup(righthexkey, 7);
	 hexkey = lefthexkey + righthexkey;
	 keyhexfield.setText(hexkey);
	 if (tooshort) { keybinfield.setText(binkey); }
	 return binkey;
      }
   }

   // is there no better way of inverting booleans?
   public boolean not(boolean in) {
      if (in) { return false; }
      else { return true; }
   }
   
   // add redundant parity bits to key
   public String addParity(String in) {
      String out="";
      for (int i=0; i < 8; i++) {
	 boolean even = true;
	 for (int t=0; t < 7; t++) {
	    int pos = t + i*7;
	    String single = in.substring(pos, pos + 1);
	    out += single;
	    if (single.equals("1")) { even = not(even); }
	 }
	 if (even) { out += "0"; }
	 else { out += "1"; };
      }
      return out;
   }
	    
   // first permutation
   public String PC1(String in) {
      String out="";
      int pc1[] = {57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};
      for (int i=0; i < 56; i++) {
         out += in.substring(pc1[i]-1, pc1[i]);
      }
      return out;
   }

   // second permutation
   public String PC2(String in) {
      String out="";
      int pc2[] = {14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32};
      for (int i=0; i < 48; i++) {
	 out += in.substring(pc2[i]-1, pc2[i]);
      }
      return out;
   }
   
   // left shift for C[] and D[]
   public String LS(int i, String in) {
      if ((i==1) || (i==2) || (i==9) || (i==16)) {
	 return in.substring(1,28) + in.substring(0,1);
      }
      else return in.substring(2,28) + in.substring(0,2);
   }

   public void leftShifts(String key) {
      C[0] = key.substring(0, 28);
      D[0] = key.substring(28,56);
      C0field.setText(C[0]);
      D0field.setText(D[0]);
      for (int i=1; i <= 16; i++) {
	 C[i] = LS(i,C[i-1]);
	 D[i] = LS(i,D[i-1]);
	 keys[i] = PC2(C[i] + D[i]);
      }
   }

   // print key #keynum
   public void printKey() {
      keynum++;
      if (keynum == 17) { keynum = 1; }
      keysarea.setText("C["+keynum+"] = "+C[keynum]+", ");
      keysarea.append("D["+keynum+"] = "+D[keynum]+"\n\n");
      keysarea.append(getParameter("keyNr")+ " " + keynum +" = "+ keys[keynum]);
   }
}
