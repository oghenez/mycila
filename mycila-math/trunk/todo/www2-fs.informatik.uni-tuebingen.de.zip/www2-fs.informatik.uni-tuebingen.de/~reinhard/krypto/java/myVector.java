public class myVector
{
  private int dim; /* dimension of the vector */
  private double[] set; /* the elements of the vector */

  public myVector (int d)
  {
    set = new double[d];
    dim = d;

    return;
  }

  public myVector(Knapsack kn)
  {
    dim = kn.getDim();
    set = new double[dim];

    for (int i=0; i<dim; i++)
      set[i] = (double)kn.getElement(i);

    return;
  }

  public myVector(myVector v)
  {
    dim = v.getDim();
    set = new double[dim];

    for (int i=0; i<dim; i++)
      set[i] = v.getElement(i);

    return;
  }

  public double getElement(int i)
  {
    return (this.set[i]);
  }

  public void setElement(int i, double d)
  {
    this.set[i] = d;

    return;
  }

  public int getDim()
  {
    return (this.dim);
  }

  public double getLength()
  {
    return (Math.sqrt(this.innerProd(this)));

  } /* end getLength() */

  public double innerProd(myVector v)
  {
    double res = 0;

    for (int i=0; i<this.dim; i++)
      res += (this.set[i] * v.set[i]);

    return (res);
  }

  /* returns this - v */
  public myVector sub(myVector v)
  {
    int dim = this.dim;

    myVector myVec = new myVector(dim);

    for (int i=0; i<dim; i++)
      myVec.setElement(i, this.getElement(i) - v.getElement(i));

    return (myVec);
  }

  /* returns this * d, d scalar */
  public myVector scalarMult(double d)
  {
    myVector myVec = new myVector(this.dim);

    for (int i=0; i<this.dim; i++)
      myVec.setElement(i, this.getElement(i)*d);

    return (myVec);
  }

  public myVector scalarMult(long l)
  {
    return this.scalarMult((double) l);
  }

  /* returns this + d, d scalar */
  public myVector scalarAdd(double d)
  {
    myVector myVec = new myVector(this.dim);

    for (int i=0; i<this.dim; i++)
      myVec.setElement(i, this.getElement(i)+d);

    return (myVec);
  }

  public myVector scalarAdd(long l)
  {
    return this.scalarAdd((double) l);
  }

  public myVector scalarAdd(int i)
  {
    return this.scalarAdd((double) i);
  }

  public String toString()
  {
    String res = new String();

    for (int i=0; i<this.getDim(); i++)
      res += this.getElement(i) +"\t";

    return (res);
  } /* end toString() */

} /* end class myVector */