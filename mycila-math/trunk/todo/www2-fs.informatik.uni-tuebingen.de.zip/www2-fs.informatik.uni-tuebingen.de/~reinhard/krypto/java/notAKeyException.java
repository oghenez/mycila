public class notAKeyException extends notAKnapsackException
{
  public notAKeyException()
  {
    super();
  }

  public notAKeyException(String s)
  {
    super(s);
  }

}