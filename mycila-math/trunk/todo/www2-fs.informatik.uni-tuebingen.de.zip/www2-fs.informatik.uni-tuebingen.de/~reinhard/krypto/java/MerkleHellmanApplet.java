import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class MerkleHellmanApplet extends Applet implements ActionListener, ItemListener, TextListener
{
  TextField[] tf;
  TextField tfM, tfW, tfU, tfPlain, tfbinP, tfChiffre, tfnewChiffre;
  TextArea taPrivKey, taPubKey, taEncrypt, taDecrypt;
  Choice ch;
  Label labelM, lPlain, labelC, lpubKey;
  Button keyBtn, newKeyBtn, encryptBtn, decryptBtn;

  MH privKey;
  Knapsack pubKey;

  boolean encryptOK = false, decryptOK = false;

  final int maxVisible = 21;
  final int minVisible = 4;
  final int startVal = 32;
  final String name = "a";

  int visible = maxVisible >> 1;
  String str;

  long plain, chiffre;

  public void init()
  {
    Color[] color = {Color.cyan, Color.green, Color.magenta, Color.pink, Color.yellow};

    int col = ((int)Tools.randomNumber(1, (long)3*color.length))%color.length;
    setBackground(color[col]);

    this.showStatus("Football forever !!!");

    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    Panel p;
    int gridy = 0;

    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    add(new Label("The Basic Merkle-Hellman Cryptosystem"), c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("1) Key Generation"), c);

    tf = new TextField[maxVisible];
    ch = new Choice();

    for (int i=minVisible; i<=maxVisible; i++)
      ch.add(Integer.toString(i));

    if (visible < minVisible)
      visible = minVisible;

    if (visible > maxVisible)
      visible = maxVisible;

    ch.select(Integer.toString(visible));

    p = new Panel();

    p.add(new Label("number elements in private key A"));
    p.add(ch);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    add(p, c);

    c.gridy++;
    c.gridwidth = 1;

    for (int i=0; i<maxVisible; i++)
    {
      c.insets = new Insets(0,0,0,20);
  
      p = new Panel();
      str = name +"(" +Integer.toString(i+1) +")";
      tf[i] = new TextField(10);
      tf[i].setBackground(Color.white);
      p.add(new Label(str));
      p.add(tf[i]);

      if (i%3 == 2)
        c.insets = new Insets(0,0,0,0);

      if (i%3 == 0)
      {
        c.gridy++;
        c.gridx=0;
      }

      add(p, c);
      c.gridx++;
    }

    gridy = c.gridy;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(10,0,0,20);
    p = new Panel();
    p.add(new Label("M ="));

    tfM = new TextField(10);
    tfM.setBackground(Color.white);
    p.add(tfM);
    add(p, c);

    c.gridwidth = GridBagConstraints.REMAINDER;
    c.gridx++;
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    labelM = new Label(getStringM(0), Label.LEFT);
    add(labelM, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,20);
    p = new Panel();
    p.add(new Label("W ="));
    tfW = new TextField(10);
    tfW.setBackground(Color.white);
    p.add(tfW);
    add(p, c);
    c.gridx++;
    c.insets = new Insets(0,0,0,0);
    c.anchor = GridBagConstraints.WEST;
    add(new Label("gcd(M, W) = 1 and 1 <= W < M"), c);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    newKeyBtn = new Button("new key");
    newKeyBtn.setActionCommand("new");
    add(newKeyBtn, c);

    c = new GridBagConstraints();
    c.anchor = GridBagConstraints.EAST;
    c.gridy = ++gridy;
    c.gridx = 0;
    c.insets = new Insets(0,0,0,20);
    p = new Panel();
    p.add(new Label("U ="));
    tfU = new TextField(10);
    tfU.setBackground(Color.lightGray);
    tfU.setEditable(false);
    p.add(tfU);
    add(p, c);

    c.gridx++;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("i.e. W*U = 1 mod M"), c);

    c.gridx++;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,0);
    keyBtn = new Button("create keys");
    keyBtn.setActionCommand("key");
    add(keyBtn, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    add (new Label("private key"), c);

    c.gridwidth = GridBagConstraints.REMAINDER;
    c.gridx++;
    c.anchor = GridBagConstraints.EAST;
    lpubKey = new Label(pubKeyString(visible));
    add(lpubKey, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    taPrivKey = new TextArea("", 8, 22);
    taPrivKey.setEditable(false);
    taPrivKey.setBackground(Color.lightGray);
    add(taPrivKey, c);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    taPubKey = new TextArea("", 8, 35);
    taPubKey.setBackground(Color.lightGray);
    taPubKey.setEditable(false);
    add(taPubKey, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(10,0,0,0);
    add(new Label("2) Encryption"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,20);
    p = new Panel();
    p.add(new Label("p ="));
    tfPlain = new TextField(8);
    tfPlain.setBackground(Color.white);
    p.add(tfPlain);
    add(p, c);

    c.gridx++;
    c.insets = new Insets(0,0,0,0);
    c.ipadx = 30;
    c.anchor = GridBagConstraints.WEST;
    lPlain = new Label(getStringP(visible), Label.LEFT);
    add(lPlain, c);

    c.ipadx = 0;
    c.gridx++;
    c.anchor = GridBagConstraints.EAST;
    encryptBtn = new Button("encrypt");
    add(encryptBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    p = new Panel();
    p.add(new Label("binary representation of p = ( p(1), p(2), ..., p(n) ):"));
    tfbinP = new TextField(25);
    tfbinP.setBackground(Color.lightGray);
    tfbinP.setEditable(false);
    p.add(tfbinP);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.ipadx = 10;
    labelC = new Label(getStringC(visible), Label.LEFT);
    add(labelC, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taEncrypt = new TextArea("", 8, 65);
    taEncrypt.setBackground(Color.lightGray);
    taEncrypt.setEditable(false);
    add(taEncrypt, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(10,0,0,0);
    add(new Label("3) Decryption"), c);

    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    decryptBtn = new Button("decrypt");
    add(decryptBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.SOUTHEAST;
    p = new Panel();
    p.add(new Label("to decrypt c ="));
    tfChiffre = new TextField("", 10);
    tfChiffre.setBackground(Color.lightGray);
    tfChiffre.setEditable(false);
    p.add(tfChiffre);
    p.add(new Label(", first compute c' = c*U mod M ="));
    tfnewChiffre = new TextField(10);
    tfnewChiffre.setBackground(Color.lightGray);
    tfnewChiffre.setEditable(false);
    p.add(tfnewChiffre);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    add(new Label("decryption: solve the easy knapsack problem ( A, c' )"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taDecrypt = new TextArea("", 8, 65);
    taDecrypt.setBackground(Color.lightGray);
    taDecrypt.setEditable(false);
    add(taDecrypt, c);

    for (int i=visible; i<maxVisible; i++)
    {
      tf[i].setBackground(Color.gray);
      tf[i].setEditable(false);
    }

    /* create new private key */
    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(startVal>>1, startVal));

    pubKey = privKey.getPubKey();

    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(privKey.getElement(i)));

    labelM.setText(getStringM(privKey.getSum()));

    tfM.setText(Long.toString(privKey.getM()));
    tfW.setText(Long.toString(privKey.getW()));
    tfU.setText(Long.toString(privKey.getU()));

    /* add the corresponding event listeners */
    keyBtn.addActionListener(this);
    newKeyBtn.addActionListener(this);
    encryptBtn.addActionListener(this);
    decryptBtn.addActionListener(this);

    ch.addItemListener(this);

    tfM.addTextListener(this);
    tfW.addTextListener(this);
    tfPlain.addTextListener(this);

    for (int i=0; i<maxVisible; i++)
      tf[i].addTextListener(this);

  } /* end init() */


  public void textValueChanged(TextEvent te)
  {
    /* if the plaintext has been changed, first encrypt new plaintext */
    if (te.getSource().equals(tfPlain))
    {
      decryptOK = false;
      clearFields(2);

      return;
    }

    /* either M, W or a(i) has been changed; so first create new private/public key */
    encryptOK = false;
    decryptOK = false;
    clearFields(1);

    return;

  } /* end textValueChanged() */


  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();
    String str;
    long res;

    if (cmd.equals("key"))
    {
      clearFields(1);

      MH tmpMH;

      /* is input valid ? */
      if ((tmpMH = getPrivKey(visible)) == null )
        return;
 
      /* get new private key */
      privKey = tmpMH;

      /* create the corresponding public key */
      pubKey = privKey.getPubKey();

      /* create a random plaintext */
      plain = Tools.randomNumber(1, (0x01 << visible) -1);

      labelM.setText(getStringM(privKey.getSum()));
      taPrivKey.setText(privKey.toString());
      taPubKey.setText(pubKey.toString());
      tfU.setText(Long.toString(privKey.getU()));
      tfPlain.setText(Long.toString(plain));

      encryptOK = true;

      return;
    }

    if (cmd.equals("new"))
    {
      long first;

      clearFields(1);

      if ((first = getStartValue(privKey.getMaxStart())) == -1)
        return;

      privKey.getPrivKey(first);

      for (int i=0; i<visible; i++)
       tf[i].setText(Long.toString(privKey.getElement(i)));

      tfM.setText(Long.toString(privKey.getM()));
      tfW.setText(Long.toString(privKey.getW()));
      tfU.setText(Long.toString(privKey.getU()));
      labelM.setText(getStringM(privKey.getSum()));

      return;
    }

    if (cmd.equals("encrypt"))
    {
      clearFields(2);

      /* encrypt only if M, W and the a(i)s have not been changed */
      if (!encryptOK)
      {
        taEncrypt.setText("first create private/public key: press key-Button");
        return;
      }

      long p;

      if ((p = getP(visible)) == -1)
        return;

      plain = p;

      tfbinP.setText(Tools.fillString(Long.toBinaryString(plain), visible));
      chiffre = encrypt(plain);
      taEncrypt.append("\nget chiffre = " +Long.toString(chiffre));
      tfChiffre.setText(Long.toString(chiffre));

      decryptOK = true;

      return;
    }

    if (cmd.equals("decrypt"))
    {
      /* decrypt only if M, W and the a(i)s have not been changed */
      if (!encryptOK)
      {
        taDecrypt.setText("first create private/public key: press key-Button");

        return;
      }

      /* decrypt only the correct plaintext p */
      if (!decryptOK)
      {
        taDecrypt.setText("first encrypt the plaintext: press encrypt-Button");

        return;
      }

      taDecrypt.setText("");
      res = decrypt(chiffre);

      return;
    }

    taPubKey.setText("unknown command");

    return;

  } /* end actionPerformed() */


  public void itemStateChanged(ItemEvent ie)
  {
    Object obj = ie.getItem();
    int newVisible = Integer.parseInt(obj.toString());

    /* restore old values */
    if (visible == newVisible)
    {
      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(privKey.getElement(i)));

      tfM.setText(Long.toString(privKey.getM()));
      tfW.setText(Long.toString(privKey.getW()));
      tfU.setText(Long.toString(privKey.getU()));

      return;
    }

    /* new dimension, so the keys are not valid anymore */
    encryptOK = false;
    decryptOK = false;

    clearFields(1);

    if (visible < newVisible)
    {
      for (int i=visible; i<newVisible; i++)
      {
        tf[i].setBackground(Color.white);
        tf[i].setEditable(true);
      }
    }

    else
    {
      for (int i=newVisible; i<visible; i++)
      {
        tf[i].setText("");
        tf[i].setBackground(Color.gray);
        tf[i].setEditable(false);
      }
    }

    visible = newVisible;

    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(startVal>>1, startVal));

    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(privKey.getElement(i)));

    tfM.setText(Long.toString(privKey.getM()));
    tfW.setText(Long.toString(privKey.getW()));
    tfU.setText(Long.toString(privKey.getU()));

    lpubKey.setText(pubKeyString(visible));
    labelC.setText(getStringC(visible));
    lPlain.setText(getStringP(visible));
    labelM.setText(getStringM(privKey.getSum()));

    return;
  } /* end itemStateChanged() */


  private long getStartValue(long max)
  {
    long f;

    try
    {
      f = Long.parseLong(tf[0].getText());
    }
    catch (NumberFormatException nfe)
    {
      taPubKey.setText(name +"(1): <" +tf[0].getText() +"> not a number");
      return (-1);
    }

    if (f <= 0)
    {
      taPubKey.setText(name +"(1) <= 0");
      return (-1);
    }

    if (f > max)
    {
      taPubKey.setText(name +"(1): choose a number <= " +Long.toString(max));
      return (-1);
    }

    return (f);
  } /* end getStartValue() */


  public MH getPrivKey(int visible)
  {
    String[] s = new String[visible];
    String[] mw = new String[2];
    MH mh;

    for (int i=0; i<visible; i++)
      s[i] = tf[i].getText();

    mw[0] = tfM.getText();
    mw[1] = tfW.getText();

    try
    {
      mh = new MH(s, mw, name);
    }
    catch (notAKnapsackException ke)
    {
      taPubKey.setText(ke.getMessage());
      return (null);
    }

    return (mh);

  } /* end getPrivKey() */


   /* check that the plaintext is in [0, 2^visible -1] */
  public long getP(int vis)
  {
    String err;
    long p;

    /* is p a number? */
    try
    {
      p = Long.parseLong(tfPlain.getText());
    }
    catch (NumberFormatException nfe)
    {
      err = "p: <" +tfPlain.getText();
      err += "> not a number";
      taEncrypt.setText(err);

      return (-1);
    }

    /* p >= 0? */ 
    if (p < 0 )
    {
      err = "p: no negative values";
      taEncrypt.setText(err);

      return (-1);
    }

    /* p < 2^(visible-1)? */
    if (p >= (0x01 << vis) )
    {
      err = "p: " +Long.toString(p) +" >= ";
      err += Long.toString(0x01 << visible);
      taEncrypt.setText(err);

      return (-1);
    }

    /* p is a valid number */
    return (p);

  } /* end getP() */


  public String getStringM(long sum)
  {
    String out = "> SUM (a(i)) = ";
    out += Long.toString(sum);

    return(out);
  } /* end getStringM() */


  public String getStringP(int visible)
  {
    String out = "0 <= p < ";
    out += Integer.toString(0x01 << visible);

    return (out);
  } /* end getStringP() */


  public String getStringC(int visible)
  {
    String out = "encryption: chiffretext c = SUM (b(i)*p(i)), 1 <= i <= ";
    out += Integer.toString(visible);

    return (out);
  } /* end getStringC() */


  public String pubKeyString(int visible)
  {
    String out = "public key B: b(i) = a(i)*W mod M, 1 <= i <= ";
    out += Integer.toString(visible);

    return (out);
  } /* end pubKeyString() */


  public void clearFields(int src)
  {
    tfbinP.setText("");
    taEncrypt.setText("");
    tfChiffre.setText("");
    tfnewChiffre.setText("");
    taDecrypt.setText("");

    if (src == 2)
      return;

    tfPlain.setText("");
    taPrivKey.setText("");
    taPubKey.setText("");

    return;
  }


  /* encrypt plaintext with pubKey */ 
  public long encrypt(long plain)
  {
    long chiffre = 0, save = 0;
    int n = pubKey.getDim() -1;
    long s = 0x01L << n;

    String output;
    byte b;

    taEncrypt.setText("Chiffre = 0 ...\n\n");

    for (int i=0; i<pubKey.getDim(); i++)
    {
      output = "";
      b = 0;

      if ((plain & s) != 0)
        b = 1;

      output = "p(" +(i+1) +") = " +b;
      output += "\t==> chiffre = " +b +" * " +pubKey.getElement(i);
      output += " + " +chiffre +" = ";

      if (b != 0)
        chiffre += pubKey.getElement(i);

      output += +chiffre +"\n";
      taEncrypt.append(output);

      s = s >> 1;
    }

    return (chiffre);
  } /* end encrypt() */


  /* decrypt with privKey */
  public long decrypt(long chiffre)
  {
    long msg = 0x0;
    long s = 0x01;

    int i = privKey.getDim();
    byte b = 0;

    String out;

    /* factor out the multiplier W */
    chiffre = Tools.mod(chiffre, privKey.getU(), privKey.getM());

    tfnewChiffre.setText(Long.toString(chiffre));

    for (--i; i>=0; i--)
    {
      out = "";
      b = 0;

      if (privKey.getElement(i) <= chiffre)
      {
        msg = msg | s;
        b = 1;
      }

      out = "c' = " +chiffre;
      out += (b != 0) ? " >= " : " < ";
      out += privKey.getElement(i) +" = a(" +(i+1) +")";
      out += "\t==> p(" +(i+1) +") = ";
      out += b +" , c' = " +chiffre + " - ";
      out += (b != 0) ? privKey.getElement(i) : 0;
      out += " = ";

      chiffre = chiffre - ((long)b*privKey.getElement(i));
      out += chiffre +"\n";

      taDecrypt.append(out);

      s = s << 1;
    }

    if (chiffre != 0)
      taDecrypt.append("no solution");
    else
    {
      out = "\nMessage is " +Tools.fillString(Long.toBinaryString(msg), visible);
      out += " = " +msg;
      taDecrypt.append(out);
    }

    return (msg);
  } /* end decrypt() */

} /* end class */