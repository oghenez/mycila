package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/TestPrime.java
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.math.*;

public class TestPrime extends Applet implements ActionListener, AdjustmentListener {
   KeyField numberField;
   TextField millerField, eratField, builtinField, sliderField, eratcalc;
   TextArea millercalc;
   Button millerButton, eratButton, builtinButton;
   Scrollbar slider;
   String prime, composite;
   int certainty;
   
   // layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;
      
      prime = getParameter("prime"); composite = getParameter("composite");

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(new Label(getParameter("number") + ":"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0; c.anchor = GridBagConstraints.EAST;
      add(numberField = new KeyField("20011",15), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1;
      add(new Label(""), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(millerButton = new Button("Miller-Rabin"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 2; c.anchor = GridBagConstraints.EAST;
      add(millerField = new TextField(15), c);
      millerField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 3;
      add(millercalc = new TextArea(4,39), c);
      millercalc.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 4;
      add(new Label(""), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 5; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(builtinButton = new Button("isProbablePrime(2)"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 5; c.anchor = GridBagConstraints.EAST;
      add(builtinField = new TextField(15), c);
      builtinField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 6; c.anchor = GridBagConstraints.WEST;
      add(slider = new Scrollbar(Scrollbar.HORIZONTAL, 2, 1, 0, 21));
      add(slider, c);

      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 6; c.anchor = GridBagConstraints.EAST;
      c.gridwidth = 2;
      add(sliderField = new TextField("Prob.: 1-1/2**2 = 0.75", 27), c);
      sliderField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 7;
      add(new Label(""), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 8; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(eratButton = new Button(getParameter("erat")), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 8; c.anchor = GridBagConstraints.EAST;
      add(eratField = new TextField(15), c);
      eratField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 9; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 3;
      add(eratcalc = new TextField(40), c);
      eratcalc.setEditable(false);

      // register listeners
      millerButton.addActionListener(this);
      eratButton.addActionListener(this);
      builtinButton.addActionListener(this);
      numberField.addActionListener(this);
      slider.addAdjustmentListener(this);
   }


   // listens to slider
   public void adjustmentValueChanged(AdjustmentEvent e) {
      certainty = e.getValue();
      builtinButton.setLabel("isProbablePrime("+ certainty +")");
      double probability = 1 - Math.pow(.5, certainty);
      // assemble output string:
      String temp = "Prob.: 1-1/2**"+ certainty +" = "+ probability +"                    ";
      sliderField.setText(temp.substring(0,27)); // output chopped string
   }


   // listen to buttons, dispatch
   public void actionPerformed(ActionEvent e) {
      long num = numberField.getLongKey();
      Object source = e.getSource();

      if (num > 1) {
	 if (source == millerButton) {
	    miller(num);
	 }
	 if (source == eratButton) {
	    erat(num);
	 }   
	 if (source == builtinButton) {
	    builtin(num);
	 }
	 if (source == numberField) {
	    miller(num);
	    erat(num);
	    builtin(num);
	 }
      }
      else {
	 millerField.setText("");
	 millercalc.setText(getParameter("invalid"));
	 eratField.setText(""); eratcalc.setText("");
	 builtinField.setText("");
      }
   }


   // Miller-Rabin Algorithm for n
   public void miller(long n) {
      int l=0;
      long m, x, x0, n1=n-1;

   miller: {
	 
	 // (1)
	 long ntemp = n1, temp=1;
	 while (ntemp % 2 == 0) { ntemp /= 2; l++; temp *= 2; }
	 m = n1 / temp;
	 millercalc.setText(" (1) "+ n1 +" = 2 ** "+ l +" * "+ m +"\n");
	 
	 // (2)
	 x = (int)(java.lang.Math.random() * n); // n-1 ?
	 millercalc.append(" (2) "+getParameter("random")+" x: "+ x +"\n");
	 
	 // (3)
	 x0 = Helpers.modexp(x,m,n);
	 millercalc.append(" (3) x0 = "+ x +" ** "+ m +" mod "+ n +" = "+ x0 +"\n");
	 
	 // (4) - (6)
	 if ((x0 == 1) | (x0 == n1)) {
	    millercalc.append(" (5) "+prime);
	    millerField.setText(prime);
	    break miller;
	 }
	 
	 // (7)
	 long xneu, xalt = x0;
	 for (int i=0; i <= l-1; i++) {
	    
	    // (8)
	    xneu = Helpers.modexp(xalt, 2, n);
	    
	    // (9) - (10)
	    if (xneu == n1) {
	       millercalc.append("(10) "+prime);
	       millerField.setText(prime);
	       break miller;
	    }
	
	    // (11) - (13)
	    else if (xneu == 1) {
	       millercalc.append("(12) "+composite);
	       millerField.setText(composite);
	       break miller;
	    }
	    xalt = xneu;
	 }
	 millercalc.append("(16) "+composite);
	 millerField.setText(composite);
      }
   }

   // sieve of Eratosthenes
   public void erat(long num) {
      String out = (num +" =");
      boolean isPrime = true, notfirst = false;
      long temp = num;
      
      while (temp % 2 == 0) {
	 temp /= 2;
	 if (notfirst) { out += " *"; }
	 else { notfirst = true; }
	 out += " 2";
	 isPrime = false;
      }
      
      int check = 3;
      while (check <= (num / 2)) {
	 while (temp % check == 0) {
	    temp /= check;
	    if (notfirst) { out += " *"; }
	    else { notfirst = true; }
	    out += (" "+ check);
	    isPrime = false;
	 }
	 check +=2;
      }
      
      
      if (isPrime) { eratField.setText(prime); out += (" "+prime); }
      else { eratField.setText(composite); }

      eratcalc.setText(out);
   }    
   
   
   // java-builtin isProbablePrime method
   public void builtin(long num) {
      Long temp = new Long(num);
      BigInteger b = new BigInteger(temp.toString());
      if (b.isProbablePrime(certainty)) { builtinField.setText(prime); }
      else { builtinField.setText(composite); }
   }
   
}

/*
  // sieve of Eratosthenes without factorization
  public void erat(int num) {
  boolean isPrime = true;
  if (num % 2 == 0 && num != 2) { isPrime = false; }
  int root = (int)Math.sqrt((double)num);
  int i = 3;
  while (i <= root && isPrime) {
  if (num % i == 0) {
  isPrime = false;
  }
  i += 2;
  }
  if (isPrime) { eratField.setText(prime); }
  else { eratField.setText(composite); }
  }
  
*/
