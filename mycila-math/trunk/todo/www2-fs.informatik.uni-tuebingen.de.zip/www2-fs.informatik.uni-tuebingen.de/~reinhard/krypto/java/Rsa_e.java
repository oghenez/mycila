package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/Rsa_e.java (RSA)
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// uses "mod" (multiply a and b modulo c) from Helpers.class

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Rsa_e extends Applet implements ActionListener {
   static final int maxInt = java.lang.Integer.MAX_VALUE; // for scroll hack
   long g,gcd,a,x,z,p,q,b,n,phi,plain;
   KeyField pField, qField, bField, plainField;
   TextField nField, phiField, testField, cipherField;
   TextArea aArea, encryptArea, decryptArea;
   Label nLabel;
   Button doneButton, testButton, encryptButton, decryptButton;
   boolean multiplyDone = false, testDone = false, encryptDone = false;
   String newline = System.getProperty("line.separator");
  
   // layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST; 
      Panel p = new Panel();
      p.add(new Label("Choose p:"));
      p.add(pField = new KeyField("101", 7));
      p.add(new Label("and q:"));
      p.add(qField = new KeyField("113", 7));
      //      p.add(new Label("."));
      add(p, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.WEST;
      Panel p1 = new Panel();
      p1.add(doneButton = new Button("Done"));
      p1.add(new Label("  n = pq ="));
      p1.add(nField = new TextField("", 16)); nField.setEditable(false);
      add(p1, c);
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      Panel p2 = new Panel();
      p2.add(new Label("phi(n) ="));
      p2.add(phiField = new TextField("(p-1)  *  (q-1) =", 27));
      phiField.setEditable(false);
      add(p2, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      Panel p3 = new Panel();
      p3.add(new Label("Choose b:"));
      p3.add(bField = new KeyField("3533", 8));
      p3.add(nLabel = new Label("< phi(n)"));
      add(p3, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 4; c.anchor = GridBagConstraints.WEST;
      Panel p4 = new Panel();
      p4.add(testButton = new Button("Test"));
      p4.add(testField = new TextField("",31)); testField.setEditable(false);
      add(p4, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 5; c.anchor = GridBagConstraints.WEST;
      Panel p5 = new Panel();
      p5.add(new Label("Calculation of a :"));
      add(p5, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 6; c.anchor = GridBagConstraints.WEST;
      Panel p6 = new Panel();
      p6.add(aArea = new TextArea("",5,40));
      aArea.setEditable(false);
      add(p6, c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 7; c.anchor = GridBagConstraints.WEST;
      Panel p7 = new Panel();
      p7.add(new Label("Plaintext:"));
      p7.add(plainField = new KeyField("9726",12));
      p7.add(encryptButton = new Button("encrypt"));
      add(p7, c);
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 8; c.anchor = GridBagConstraints.WEST;
      Panel p8 = new Panel();
      p8.add(encryptArea = new TextArea("",5,40));
      encryptArea.setEditable(false);
      add(p8, c);
      
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 9; c.anchor = GridBagConstraints.WEST;
      Panel p9 = new Panel();
      p9.add(new Label("Ciphertext:"));
      p9.add(cipherField = new TextField("",12));
      cipherField.setEditable(false);
      p9.add(decryptButton = new Button("decrypt"));
      add(p9, c);
 
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 10; c.anchor = GridBagConstraints.WEST;
      Panel p10 = new Panel();
      p10.add(decryptArea = new TextArea("",5,40));
      decryptArea.setEditable(false);
      add(p10, c);
      
      // register listeners
      pField.addActionListener(this);
      qField.addActionListener(this);
      doneButton.addActionListener(this);
      bField.addActionListener(this);
      testButton.addActionListener(this);
      plainField.addActionListener(this);
      encryptButton.addActionListener(this);
      decryptButton.addActionListener(this);
      }
      
      
      // listen, dispatch
      public void actionPerformed(ActionEvent e) {
	 Object source = e.getSource();
	 String command = e.getActionCommand();

	 if ((command.equals("Done")) | (source == pField) | (source == qField)) {	
	    multiply();
	 }
	 if (((command.equals("Test")) | (source == bField)) && multiplyDone) {
	    getb();
	    if (testDone) { computea(); }
	 }
	 if (((command.startsWith("encr")) | (source == plainField)) && (testDone)) {
	    encrypt();
	 }   
	 if ((command.startsWith("decr")) && encryptDone) {
	    decrypt();
      }
   }
   
   
   // greatest common divisor
   public long Gcd(long left, long right) {
      if (!( left > right)) {return -1;}
      
      long q = (int)Math.floor((double)(left/right)); //trunc?
      long rest = left - q * right;
      while (rest != 0) {
	 left = right;
	 right = rest;
	 q = (int)Math.floor((double)(left/right)); //trunc?
	 rest = left - q * right;
      }
	 return right;
   }

   public boolean isPrime(long num) {
      boolean prime = true;
      if ((num < 2) | ((num % 2 ==0) && (num != 2))) { return false; }
      long root = (int)Math.sqrt((double)num);
      long i = 3;
      while (i <= root && prime) {
	 if (num % i == 0) {
	    prime = false;
	 }
	 i += 2;
      }
      return prime;
   }
   

   // step 1: n and phi
   public void multiply() {
      p = pField.getLongKey(); q = qField.getLongKey();
      if (! isPrime(p)) {
	 nField.setText("p not prime");
      } else if (! isPrime(q)) {
	 nField.setText("q not prime");
      } else {
	 n = p*q;
	 nField.setText(String.valueOf(n));
	 phi = (p-1)*(q-1);
	 phiField.setText((p-1) +" * "+ (q-1) +" = "+ String.valueOf(phi));
	 nLabel.setText("< "+ phi);
	 multiplyDone = true;
      }
   }
   
   // step 2: get b
   public void getb() {
      b = bField.getLongKey();
      gcd = Gcd(phi,b);
      if (gcd == -1) {
	 testField.setText("too large!");
      }
      else if (gcd > 1) {
	 while ((Gcd(phi,b) > 1) & (b < phi)) { b++; }
	 testField.setText("gcd = "+String.valueOf(gcd)+", proposal: "+ b);
      }
      else {
	 testField.setText("OK, gcd = 1");
	 testDone = true;
      }
   }
   
   // step 2.5: compute a
   public void computea() {
      long n0=phi, b0=b, t=1, q=(long)Math.floor((double)(n0/b0));
      long r = n0 - q * b0;
      aArea.setText(phi +" = "+ q +" * "+ b0 +" + "+ r +"\n");
      long t0=0;
      while (r > 0) {
	 long temp = t0 - q * t;
	 if (temp >= 0) temp = temp % phi;
	 if (temp < 0) temp = phi - ((-temp) % phi);
	 t0 = t;
	 t = temp;
	 aArea.append(t +" * "+ b +" mod "+ phi +" = "+ r +"\n");
	 n0 = b0;
	 b0 = r;
	 q = (long)Math.floor((double)(n0/b0));
	 r = n0 - q * b0;
	 aArea.append(n0 +" = "+ q +" * "+ b0 +" + "+ r +"\n");
      }
      aArea.append("\n=> a = "+ t);
      a = t;
      aArea.setCaretPosition(maxInt); //hack to scroll to bottom
   }
      
   // step 3: encrypt
   public void encrypt() {
      plain = plainField.getLongKey();
      if (plain == -1) { return; }
      encryptArea.setText(plain +" ** "+ b +" mod "+ n +" =" +newline);
      String bin = Long.toBinaryString(b);
      encryptArea.append(plain +" ** "+ bin +"(bin) mod "+ n +" =>" + newline);
      z = 1;
      for (int i = 0; i < bin.length(); i++) {
	 char bi = bin.charAt(i);
	 encryptArea.append(bi +"| ");
	 if (bi == '1') {
	    encryptArea.append(z +" ** 2 * "+ plain);
	    z = Helpers.mod(z,z,n);
	    z = Helpers.mod(z,plain,n);
	 }
	 else {
	    encryptArea.append(z +" ** 2");
	    z = Helpers.mod(z,z,n);
	 }
	 encryptArea.append(" = "+ z +newline);
      }
      encryptArea.setCaretPosition(maxInt); //hack to scroll to bottom
      cipherField.setText(Long.toString(z));
      encryptDone = true;
   }
   
   // step 4: decrypt
   public void decrypt() {
      decryptArea.setText(z +" ** "+ a +" mod "+ n +" ="+ newline);
      String bina = Long.toBinaryString(a);
      decryptArea.append(z +" ** "+ bina +"(bin) mod "+ n +" =>"+ newline);
      
      x = z;
      long z = 1;
      for (int i = 0; i < bina.length(); i++) {
	 char bi = bina.charAt(i);
	 decryptArea.append(bi +"| ");
	 if (bi == '1') {
	    decryptArea.append(z + " ** 2 * " + x);
	    z = Helpers.mod(z,z,n);
	    z = Helpers.mod(z,x,n);
	 }
	 else {
	    decryptArea.append(z + " ** 2");
	    z = Helpers.mod(z,z,n);
	 }
	 decryptArea.append(" = " + z + newline);
      }
      decryptArea.setCaretPosition(maxInt); //hack to scroll to bottom
   }   
   
}





