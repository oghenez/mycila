public class vNode
{
  private int index; /* index of function */
  private Rational r; /* value of the minimum */

  public vNode (int i, Rational r)
  {
    index = i; 
    this.r = r;
  }

  public int getIndex()
  {
    return(this.index);
  }

  public Rational getRational()
  {
    return (this.r);
  }

} /* end class vNode */

