package kryptoScript;

//
// http://www-fs.informatik.uni-tuebingen.de/~reinhard/krypto/
// java/Miller.java
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 29.10.2003 by Klaus Reinhardt
//

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.math.*;

public class Miller extends Applet implements ActionListener {
   KeyField numberField;
   TextField millerField;
   TextArea millercalc;
   Button millerButton;
   String prime, composite;
   int certainty;
   
   // layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;
      
      prime = getParameter("prime"); composite = getParameter("composite");

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(new Label(getParameter("number") + ":"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 0; c.anchor = GridBagConstraints.EAST;
      add(numberField = new KeyField("25057",15), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1;
      add(new Label(""), c);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 2;
      add(millerButton = new Button("Miller"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 2; c.anchor = GridBagConstraints.EAST;
      add(millerField = new TextField(15), c);
      millerField.setEditable(false);

      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 3;
      add(millercalc = new TextArea(30,70), c);
      millercalc.setEditable(false);

      // register listeners
      millerButton.addActionListener(this);
      numberField.addActionListener(this);
   }



   // listen to buttons, dispatch
   public void actionPerformed(ActionEvent e) {
      long num = numberField.getLongKey();
      Object source = e.getSource();

      if (num > 1) {
	 if (source == millerButton) {
	    miller(num);
	 }
	 if (source == numberField) {
	    miller(num);
	 }
      }
      else {
	 millerField.setText("");
	 millercalc.setText(getParameter("invalid"));
      }
   }


   // Miller Algorithm for n
   public void miller(long n) {
      int l=0;
      long m, x, x0, n1=n-1;

   miller: {
	 
	 long ntemp = n1, temp=1;
	 while (ntemp % 2 == 0) { ntemp /= 2; l++; temp *= 2; }
	 m = n1 / temp;
	 millercalc.setText(n1 +" = 2 ^ "+ l +" * "+ m +"\n\n");
	 
	 for (x = 2; (x<29 && x<n1); x++){ // Das wurde stark vereinfacht
	     x0 = Helpers.modexp(x,m,n);
	     millercalc.append(x + " ^ "+ m +" mod "+ n +" = "+ x0);
	     long xneu = x0, xalt = x0;
	     for (int i=0; i <= l-1; i++) {
		 xneu = Helpers.modexp(xalt, 2, n);
		 millercalc.append(", "+xneu);
		 if (xneu == 1 & xalt != n1 & xalt != 1) {
		     millercalc.append(" "+composite);
		     millerField.setText(composite);
		     break miller;
		 }
		 xalt = xneu;
	     }
	     if (xneu != 1) {
		 millercalc.append("\n "+composite);
		 millerField.setText(composite);
		 break miller;
	     }
	     millercalc.append("\n");
	 }
	 millercalc.append(" "+prime);
	 millerField.setText(prime);
      }
   }
}
