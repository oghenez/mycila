package kryptoScript;

//
// http://www-ti.informatik.uni-tuebingen.de/~haeusser/krypto/
// java/Age_e.java
// 
// Copyright (c) 1999 Matthias Haeusser
//
// last change: 14.11.1999
//

// find older person without revealing actual age
// uses "modexp" (modular exponentiation) from Helpers.class

import java.awt.*;
import java.applet.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.*;

public class Age_e extends Applet implements ActionListener {
   KeyField bField, nField, aField, iField, jField;
   TextField m1, m3, a1, a3, a4, a6, b1, b2, b3, b4;
   TextArea a2, a5, m2;
   Button newAgeButton, goButton, setAgeButton;
   Label aAge, bAge;
   int i=24, j=27; // ages of Alice and Bob
   int a=31183,b=4567,n=78703; // RSA parameters
   int step; // progress
   int p; // large prime Alice chooses
   long x; // randomly chosen by Bob
   long k; // computed by Bob
   long y[] = new long[31];
   long z[] = new long[31];
   long f[] = new long[31];
   String a5Row1;
   boolean BobIsOlder;
   
   //Layout   
   public void init() {
      setLayout(new GridBagLayout()); GridBagConstraints c;

      // left (Bob's) Block
      Panel P = new Panel();
      P.setLayout(new GridBagLayout());
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.CENTER;
      P.add(new Label("             Bob            "), c);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.CENTER;
      P.add(bAge = new Label("j = 27 years old"), c);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2;
      P.add(new Label(" "), c);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(b1 = new TextField("(1)"), c);
      b1.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 4; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(b2 = new TextField("(2)"), c);
      b2.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 5; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(b3 = new TextField("(3)"), c);
      b3.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 10; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(b4 = new TextField("(8)"), c);
      b4.setEditable(false);


      // separator
      c = new GridBagConstraints();
      c.gridx = 1; c.gridy = 0;
      P.add(new Label(" "), c);


      // middle Block
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 1; c.anchor = GridBagConstraints.CENTER;
      P.add(newAgeButton = new Button("shuffle ages"), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 2; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(new Label("                               "), c);

      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 3; c.anchor = GridBagConstraints.CENTER;
      c.gridheight = 2;
      c.fill = GridBagConstraints.BOTH;
      P.add(goButton = new Button("Start"), c);
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 5; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(m1 = new TextField("(3)", 32), c);
      m1.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 10; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(m2 = new TextArea("(7)", 1, 32, TextArea.SCROLLBARS_HORIZONTAL_ONLY), c);
      m2.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 2; c.gridy = 11; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(m3 = new TextField("(9)", 32), c);
      m3.setEditable(false);


      // separator
      c = new GridBagConstraints();
      c.gridx = 3; c.gridy = 0;
      P.add(new Label(" "), c);


      // right (Alice's) Block
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 0; c.anchor = GridBagConstraints.CENTER;
      P.add(new Label("               Alice                "), c);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 1; c.anchor = GridBagConstraints.CENTER;
      P.add(aAge = new Label("i = 24 years old"), c);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 5; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a1 = new TextField("(4)"), c);
      a1.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 6; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a2 = new TextArea("(4)", 1, 10, TextArea.SCROLLBARS_HORIZONTAL_ONLY), c);
      a2.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 7; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a3 = new TextField("(5)"), c);
      a3.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 8; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a4 = new TextField("(6)"), c);
      a4.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 9; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a5 = new TextArea("(6)\n(7)", 2, 10, TextArea.SCROLLBARS_HORIZONTAL_ONLY), c);
      a5.setEditable(false);
      c = new GridBagConstraints();
      c.gridx = 4; c.gridy = 10; c.anchor = GridBagConstraints.CENTER;
      c.fill = GridBagConstraints.HORIZONTAL;
      P.add(a6 = new TextField("(7)"), c);
      a6.setEditable(false);

      // add to overall GridBagLayout
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.WEST;
      add(P, c);

      // separator
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 1; c.gridwidth = 5;
      add(new Label(" "), c);


      // bottom Panel1: set RSA Parameters
      Panel bottomP1 = new Panel();
      bottomP1.add(new Label("RSA parameters:  b ="));
      bottomP1.add(bField = new KeyField("4567", 5));
      bottomP1.add(new Label("n ="));
      bottomP1.add(nField = new KeyField("78703", 7));
      bottomP1.add(new Label("a ="));
      bottomP1.add(aField = new KeyField("31183", 6));
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(bottomP1, c);

      // bottom Panel2: set Ages
      Panel bottomP2 = new Panel();
      bottomP2.add(setAgeButton = new Button("take ages:"));
      bottomP2.add(new Label("j ="));
      bottomP2.add(jField = new KeyField("27", 2));
      bottomP2.add(new Label("i ="));
      bottomP2.add(iField = new KeyField("24", 2));
      c = new GridBagConstraints();
      c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.WEST;
      c.gridwidth = 5;
      add(bottomP2, c);


      // register listeners
      newAgeButton.addActionListener(this);
      setAgeButton.addActionListener(this);
      iField.addActionListener(this);
      jField.addActionListener(this);
      goButton.addActionListener(this);
   }
   
   // listen, dispatch
   public void actionPerformed(ActionEvent e) {
      Object source = e.getSource();
      String command = e.getActionCommand();

      if ((command.startsWith("take age")) | (source == iField) | (source == jField)) {
	 setAge();
      }
      if (command.equals("shuffle ages")) {
	 newAge();
      }
      if (command.equals("Start")) {
	 b = bField.getKey(); n = nField.getKey(); a = aField.getKey();
	 if (!((b<1)|(n<1)|(a<1))) {
	    first();
	    goButton.setLabel("next");
	    step = 2;
	 }
      }
      if (command.equals("next")) {
	 switch (step) {
	 case 2: second(); break;
	 case 3: third(); break;
	 case 4: fourth(); break;
	 case 5: fifth(); break;
	 case 6: sixth(); break;
	 case 7: seventh(); break;
	 case 8: eigth(); break;
	 case 9: ninth(); break;
	 }
	 step++;
      }
      if (command.equals("Start Over")) {
	 clear();
	 newAge();
	 goButton.setLabel("Start");
      } 
   }

   // manually set ages
   public void setAge() {
      boolean wrong = false;
      try {
	 i = Integer.parseInt(iField.getText().trim());
	 j = Integer.parseInt(jField.getText().trim());
      } catch (NumberFormatException ex) { wrong = true; }
      if (wrong | i<20 | i>30 | j<20 | j>30 ) {
	 iField.setText("??");
	 jField.setText("??");
      } else {
      aAge.setText("i = "+ i +" years old");
      bAge.setText("j = "+ j +" years old");
      clear();
      }
   }

   public void newAge() {
      i = (int)(java.lang.Math.random() * 11) +20; // between 20
      j = (int)(java.lang.Math.random() * 11) +20; // and 30
      aAge.setText("i = "+ i +" years old");
      bAge.setText("j = "+ j +" years old");
      clear();
   }

   // reset components for new run
   public void clear() {
      b1.setText("(1)"); b2.setText("(2)"); b3.setText("(3)");
      b4.setText("(8)"); m1.setText("(3)"); m2.setText("(7)");
      m3.setText("(9)"); a1.setText("(4)"); a2.setText("(4)");
      a3.setText("(5)"); a4.setText("(6)"); a5.setText("(6)\n(7)");
      a6.setText("(7)");
      goButton.setLabel("Start");
   }

   public void first() {
      x = (long)(java.lang.Math.random() * 4096) + 4096;
      b1.setText("chooses x = "+ x);
   }

   public void second() {
      k = Helpers.modexp(x,b,n);
      b2.setText("k = encr("+ x +") = "+ k);
   }

   public void third() {
      b3.setText("sends to Alice k-j = "+ (k-j));
      m1.setText("--- " +(k-j) +" -->");
   }
      
   public void fourth() {
      a1.setText("y[u] = decr("+ (k-j) +"+u) (u=20..30)");
      String a2Text="y[u]= ";
      for (int u=20; u <= 30; u++) {
	 y[u] = Helpers.modexp(k-j+u,a,n);
	 if (y[u] == 0) { System.out.println("Zero! Start over!"); }
	 a2Text += (y[u]+" ");
      }
      a2.setText(a2Text);
   }

   public void fifth() {
      // find next prime
      p = (int)(java.lang.Math.random() * 2048) + 2048;
      BigInteger two = new BigInteger("2");
      if (p % 2 == 0) { p++; }
      Integer temp = new Integer(p);
      BigInteger bi = new BigInteger(temp.toString());
      while (! bi.isProbablePrime(7)) {
	 bi = bi.add(two);
      }
      p = bi.intValue();
      a3.setText("chooses p = "+ p);
   }

   public void sixth() {
      a4.setText("z[u] = y[u] mod "+ p +" (u=20..30)");
      a5Row1 = "z[u] =";
      for (int u=20; u <= 30; u++) {
	 z[u] = y[u] % p;
	 // test omitted
	 a5Row1 += (" "+ z[u]);
      }
      a5.setText(a5Row1 + "\n(7)");
   }
   
   public void seventh() {
      String a5Row2="f[u] =";
      for (int u=20; u <= 30; u++) {
	 f[u] = z[u];
	 if (u > i) { f[u]++; }
	 a5Row2 += (" "+ f[u]);
      }
      a5.setText(a5Row1+"\n"+a5Row2);
      a6.setText("sends to Bob f[u] (u=20..30) and p");
      m2.setText("<-- "+ a5Row2 +";p = "+ p);
   }
   
   public void eigth() {
      BobIsOlder = true;
      if (f[j] == x%p) { BobIsOlder = false; }
      String b4Text = ("f[j] = ");
      if (BobIsOlder) { b4Text += (f[j]+" != "); }
      b4Text += ((x%p) +" = x mod p");
      b4.setText(b4Text);
   }
   
   public void ninth() {
      if ( BobIsOlder ) {
	 m3.setText("Bob is older");
      }
      else {
	 m3.setText("Alice is older, or equally old");
      }
      goButton.setLabel("Start Over");
   }
}
