import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class MeetMiddleApplet extends Applet implements ActionListener, ItemListener,
TextListener
{
  final int maxVisible = 21;
  final int minVisible = 4;
  final long weight = 1000;
  final String name = "b";

  int visible = maxVisible >> 1;
  long sum, plain, currSize = weight*visible;

  Button tBtn, lBtn, newBtn;
  Choice ch;
  Label l1, l2;
  TextArea taUnsorted, taTable, taCheck;
  TextField[] tf;
  TextField tfSum, tfSize;

  Knapsack knapsack;
  lTable table;

  public void init()
  {
    Color[] color = {Color.cyan, Color.green, Color.magenta, Color.orange, Color.pink, Color.yellow};

    int col = ((int)Tools.randomNumber(1, (long)3*color.length))%color.length;
    setBackground(color[col]);

    this.showStatus("You'll never walk alone");

    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();

    Panel p;
    String str;

    int gridy = 0;

    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    add(new Label("Meet-in-the-Middle algorithm"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;

    p = new Panel();
    p.add(new Label("choose number elements in knapsack B"));

    ch = new Choice();

    for (int i=minVisible; i<=maxVisible; i++)
      ch.add(Integer.toString(i));

    if (visible < minVisible)
      visible = minVisible;

    if (visible > maxVisible)
      visible = maxVisible;

    ch.select(Integer.toString(visible));
    p.add(ch);

    add(p, c);

    p = new Panel();
    gridy = c.gridy;

    c = new GridBagConstraints();    
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;

    tf = new TextField[maxVisible];

    for (int i=0; i<maxVisible; i++)
    {
      c.insets = new Insets(0,0,0,20);

      p = new Panel();

      str = name +"(" +Integer.toString(i+1) +")";

      tf[i] = new TextField(10);
      tf[i].setBackground(Color.white);

      p.add(new Label(str));
      p.add(tf[i]);

      if (i%3 == 2)
        c.insets = new Insets(0,0,0,0);

      if (i%3 == 0)
      {
        c.gridy++;
        c.gridx=0;
      }

      add(p, c);
      c.gridx++;
    }

    gridy = c.gridy;

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 2;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(10,0,0,20);
    p = new Panel();
    p.add(new Label("Size of elements: 1 <= " +name +"(i) <="));
    tfSize = new TextField(10);
    tfSize.setBackground(Color.white);
    p.add(tfSize);
    add(p, c);

    c.gridx = 2;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(10,0,0,0);
    newBtn = new Button("new knapsack");
    newBtn.setActionCommand("new");
    add(newBtn,c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.WEST;
    c.gridwidth = 2;
    l1 = new Label(getLabel1(visible >> 1));
    add(l1, c);

    c.gridx = 2;
    c.anchor = GridBagConstraints.EAST;
    tBtn = new Button("construct T");
    tBtn.setActionCommand("construct");
    add(tBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    p = new Panel();
    taUnsorted = new TextArea("B1*X1\tX1 (unsorted)\n", 10, 30);
    taUnsorted.setBackground(Color.lightGray);
    taUnsorted.setEditable(false);
    p.add(taUnsorted);
    taTable = new TextArea("B1*X1\tX1 (sorted by B1*X1)\n", 10, 30);
    taTable.setBackground(Color.lightGray);
    taTable.setEditable(false);
    p.add(taTable);
    add(p, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 2;
    c.anchor = GridBagConstraints.WEST;
    c.insets = new Insets(10,0,0,0);
    l2 = new Label(getLabel2((visible>>1) +1, visible));
    add(l2, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.EAST;
    c.gridwidth = 2;
    c.insets = new Insets(0,0,0,20);
    p = new Panel();
    p.add(new Label("choose s"));
    tfSum = new TextField(10);
    tfSum.setBackground(Color.white);
    p.add(tfSum);
    add(p, c);

    c.gridx = 2;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,0);
    lBtn = new Button("compute L");
    lBtn.setActionCommand("compute");
    add(lBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taCheck = new TextArea("X2\tB2*X2\tL = s - B2*X2\n", 10, 60);
    taCheck.setBackground(Color.lightGray);
    taCheck.setEditable(false);
    add(taCheck, c);

    for (int i=visible; i<maxVisible; i++)
    {
      tf[i].setBackground(Color.gray);
      tf[i].setEditable(false);
    }

    for (int i=0; i<maxVisible; i++)
      tf[i].addTextListener(this);

    tfSum.addTextListener(this);

    tBtn.addActionListener(this);
    lBtn.addActionListener(this);
    newBtn.addActionListener(this);
    ch.addItemListener(this);

    /* create new knapsack with elements in [1, currSize] */
    knapsack = new Knapsack(visible);
    knapsack.createSet(currSize);

    /* set textfields with values of knapsack elements */
    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(knapsack.getElement(i)));

    tfSize.setText(Long.toString(currSize));

    /* create a random sum */
    plain = Tools.randomNumber(1, (0x01 << visible) -1);
    sum = knapsack.encrypt(plain);
    tfSum.setText(Long.toString(sum));

  } /* end init() */

  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();

    if (cmd.equals("new"))
    {
      table = null;
      clearAllFields();

      long size;

      if ( (size = getSize(knapsack.getMaxSize())) == -1)
        return;

      currSize = size;

      knapsack.createSet(currSize);

      /* set textfields with values of knapsack elements */
      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(knapsack.getElement(i)));

      /* create a random sum */
      plain = Tools.randomNumber(1, (0x01 << visible) -1);
      sum = knapsack.encrypt(plain);
      tfSum.setText(Long.toString(sum));
      
      return;
    }

    if (cmd.equals("construct"))
    {
      table = null;
      clearAllFields();

      tfSize.setText(Long.toString(currSize));

      Knapsack tmpKn;
      long s;

      if ((tmpKn = getKnapsack(visible)) == null)
        return;
      else
        knapsack = tmpKn;

      Knapsack k = new Knapsack(knapsack.getDim() >> 1);

      for (int i=0; i<k.getDim(); i++)
        k.setElement(i, knapsack.getElement(i));

      taUnsorted.setText("constructing table ...\n");
      table = new lTable(k);

      if (table == null)
        return;

      taUnsorted.setText("B1*X1\tX1 (unsorted)\n\n");

      for (int i=0; i<table.getRows(); i++)
        taUnsorted.append(table.rowToBinaryString(i));

      taUnsorted.setCaretPosition(0);
      taTable.setText("sorting table ...\n");
      table.sort();
      taTable.setText("B1*X1\tX1 (sorted by B1*X1)\n\n");

      for (int i=0; i<table.getRows(); i++)
        taTable.append(table.rowToBinaryString(i));

      taTable.setCaretPosition(0);

      return;
    }

    if (cmd.equals("compute"))
    {
      String res;
      long s;

      clearFields();
      taTable.setCaretPosition(0);
      tfSize.setText(Long.toString(currSize));

      if (table == null)
      {
        taTable.setText("");
        taUnsorted.setText("");
        taCheck.setText("first construct table T\n");

        return;
      }

      if ((s = getSum()) == -1)
        return;

      sum = s;
      res = searchS(table, knapsack, sum);

      if (res == null)
        taCheck.append("\nNo solution for (B, " +Long.toString(sum) +")");
      else
        taCheck.append("\nSolution for (B, " +Long.toString(sum) +") = X1||X2 = " +res);

      return;
    }

    taTable.setText("unknown command");

    return;

  } /* end actionPerfomed() */

  public void itemStateChanged(ItemEvent ie)
  {
    Object obj = ie.getItem();
    String str;
    Knapsack k;

    int newVisible = Integer.parseInt(obj.toString());

    /* restore values */
    if (visible == newVisible)
    {
      for (int i=0; i<knapsack.getDim(); i++)
        tf[i].setText(Long.toString(knapsack.getElement(i)));

      tfSum.setText(Long.toString(sum));

      return;
    }

    /* new dimension of knapsack */
    table = null;
    clearAllFields();

    if (visible < newVisible)
    {
      for (int i=visible; i<newVisible; i++)
      {
        tf[i].setBackground(Color.white);
        tf[i].setEditable(true);
      }
    }
    else
    {
      for (int i=newVisible; i<visible; i++)
      {
        tf[i].setText("");
        tf[i].setBackground(Color.gray);
        tf[i].setEditable(false);
      }
    }

    visible = newVisible;
    currSize = weight*visible;

    knapsack = new Knapsack(visible);
    knapsack.createSet(currSize);

    tfSize.setText(Long.toString(currSize));

    for (int i=0; i<knapsack.getDim(); i++)
      tf[i].setText(Long.toString(knapsack.getElement(i)));

    l1.setText(getLabel1(visible >> 1));
    l2.setText(getLabel2((visible>>1) +1, visible));

    plain = Tools.randomNumber(1, (0x01 << visible) -1);
    sum = knapsack.encrypt(plain);

    tfSum.setText(Long.toString(sum));

    return;
  } /* end itemStateChanged() */

  public void textValueChanged(TextEvent te)
  {
    taCheck.setText("X2\tB2*X2\tL = s - B2*X2\n");

    if (te.getSource().equals(tfSum)) /* only the sum was modified */
      return;

    /* some values of the knapsack have been changed */
    table = null;
    taTable.setText("B1*X1\tX1 (sorted by B1*X1)\n\n");
    taUnsorted.setText("B1*X1\tX1 (unsorted)\n\n");

    return;
  } /* end textValueChanged() */

  public Knapsack getKnapsack(int visible)
  {
    String[] s = new String[visible];
    Knapsack k;

    for (int i=0; i<visible; i++)
      s[i] = tf[i].getText();

    try
    {
      k = new Knapsack(s, name, false);
    }
    catch (notAKnapsackException ke)
    {
      taTable.setText(ke.getMessage());
      return (null);
    }

    return (k);
  } /* end getKnapsack() */

  public long getSum()
  {
    String err;
    long s;

    try
    {
      s = Long.parseLong(tfSum.getText());
    }
    catch (NumberFormatException nfe)
    {
      err = "s: <" +tfSum.getText();
      err += "> not a number\n";
      taCheck.setText(err);

      return (-1);
    }

    if (s < 0)
    {
      err = "s: no negative values\n";
      taCheck.setText(err);

      return (-1);
    }

    return (s);

  } /* end getSum() */

  public long getSize(long max)
  {
    long s;

    try
    {
      s = Long.parseLong(tfSize.getText());
    }
    catch (NumberFormatException nfe)
    {
      setError("size: <" +tfSize.getText() +"> not a number\n");
      return (-1);
    }

    if (s < visible)
    {
      setError("Maximal size should be at least as big as the dimension of knapsack B\n");
      return (-1);
    }

    if (s > max )
    {
      setError("size: choose a number <= " +max +"\n");
      return (-1);
    }

    return (s);
  } /* end getSize() */

  /* return solution vector as a string, if a solution exists; otherwise null */
  public String searchS(lTable lt, Knapsack kn, long s)
  {
    int match, cnt;
    int offset = kn.getDim() >> 1;
    int t = kn.getDim() - offset;
    long c;

    String out = new String();
    Knapsack k = new Knapsack(t);

    for (int i=0; i<t; i++)
      k.setElement(i, kn.getElement(i+offset));

    out = "X2\tB2*X2\tL = s - B2*X2\n\n";
    cnt = out.length();
    taCheck.setText(out);

    for (int i=0; i<(0x01 << k.getDim()); i++)
    {
      c = k.encrypt(i);

      out = Tools.fillString(Integer.toBinaryString(i), t);
      out += "\t" +Long.toString(c);
      out += "\t" +Long.toString(s-c);
      out += "\n";
      taCheck.append(out);

      cnt += out.length();

      if ( (s-c) < 0 )
        continue;

      match = lt.search(s-c);

      /* found  solution? */
      if (match >= 0)
      {
        /* select the matching row of taTable */
        String s1 = taTable.getText();
        String s2 = Long.toString(lt.getElement(match, 0)) +"\t";
        s2 += Tools.fillString(Long.toBinaryString(lt.getElement(match, 1)), offset);

        int start = s1.indexOf(s2);

        taTable.select(start, start + s2.length());

        String res = Tools.fillString(Long.toBinaryString(lt.getElement(match, 1)), offset);
        res += " " +Tools.fillString(Integer.toBinaryString(i), t);

        return (res);
      }
    }

    return (null);

  } /* end searchS() */

  public String getLabel1(int end)
  {
    String res = "1) Construct T = [ B1*X1,  X1 ] ; X1 = ( x(1), ...,x(";
    res += Integer.toString(end);
    res += ") ) ]";

    return (res);
  }

  public String getLabel2(int start, int end)
  {
    String res = "2) For all X2 = ( x(";
    res += Integer.toString(start);
    res += "), ..., x(";
    res += Integer.toString(end);
    res += ") ): L = s - B2*X2, search L in T";

    return (res);
  }

  public void setError(String err)
  {
    taCheck.setText("");
    taUnsorted.setText("");
    taTable.setText(err);

    return;
  } /* end setError() */

  public void clearFields()
  {
    taCheck.setText("X2\tB2*X2\tL = s - B2*X2\n");

    return;
  } /* end clearFields() */

  public void clearAllFields()
  {
    taTable.setText("B1*X1\tX1 (sorted by B1*X1)\n");
    taUnsorted.setText("B1*X1\tX1 (unsorted)\n");
    clearFields();

    return;
  } /* end clearAllFields() */

} /* end class */