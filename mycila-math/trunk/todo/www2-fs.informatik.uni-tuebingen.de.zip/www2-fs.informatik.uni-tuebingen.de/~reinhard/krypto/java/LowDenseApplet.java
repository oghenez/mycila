import java.awt.*;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class LowDenseApplet extends Applet implements ActionListener, ItemListener, TextListener
{
  final int maxVisible = 21;
  final int minVisible = 4;
  final int startVal = 16;
  final int precision = 4;
  final String name = "b";

  int visible = maxVisible >> 1;
  int cnt = 0;
  long plain, chiffre = 0;
  double d;

  boolean runToEnd = false;

  Button baseBtn, redBtn, solBtn, keyBtn;
  Label lParam, lErrorKnapsack, lErrorRed, lErrorC;
  Choice ch;
  TextField[] tf;
  TextField tfChiffre;
  TextArea taLattice, taRedLattice, taSol, taSol2;
  CheckboxGroup cbg;
  Checkbox runOnce, runAll;

  Vector list = null;

  Knapsack pubKey;
  MH privKey;
  Lattice lattice, redLattice=null;

  public void init()
  {
    Color[] color = {Color.cyan, Color.green, Color.magenta, Color.orange, Color.pink, Color.yellow};

    int col = ((int)Tools.randomNumber(1, (long)3*color.length))%color.length;
    setBackground(color[col]);

    GridBagLayout gridbag = new GridBagLayout();
    setLayout(gridbag);

    GridBagConstraints c = new GridBagConstraints();

    Panel p;
    String str;

    int gridy = 0;

    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    add(new Label("Solving knapsacks of low density"), c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;

    p = new Panel();
    p.add(new Label("choose number elements in public knapsack B"));

    ch = new Choice();

    for (int i=minVisible; i<=maxVisible; i++)
      ch.add(Integer.toString(i));

    if (visible < minVisible)
      visible = minVisible;

    if (visible > maxVisible)
      visible = maxVisible;

    ch.select(Integer.toString(visible));
    p.add(ch);
    add(p, c);

    gridy = c.gridy;

    c = new GridBagConstraints();    
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.EAST;

    tf = new TextField[maxVisible];

    for (int i=0; i<maxVisible; i++)
    {
      c.insets = new Insets(0,0,0,20);
      p = new Panel();

      str = name +"(" +Integer.toString(i+1) +")";

      tf[i] = new TextField(10);
      tf[i].setBackground(Color.white);

      p.add(new Label(str));
      p.add(tf[i]);

      if (i%3 == 2)
        c.insets = new Insets(0,0,0,0);

      if (i%3 == 0)
      {
        c.gridy++;
        c.gridx=0;
      }

      add(p, c);
      c.gridx++;
    }

    gridy = c.gridy;

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(10,0,0,20);
    p = new Panel();
    p.add(new Label("choose c"));
    tfChiffre = new TextField(10);
    tfChiffre.setBackground(Color.white);
    p.add(tfChiffre);
    add(p, c);

    c.gridx++;
    c.insets = new Insets(10,0,0,0);
    c.anchor = GridBagConstraints.CENTER;
    lParam = new Label(getParamString(visible, 0));
    add(lParam, c);

    c.gridx++;
    c.insets = new Insets(10,0,0,0);
    c.anchor = GridBagConstraints.EAST;
    keyBtn = new Button("new key");
    keyBtn.setActionCommand("key");
    add(keyBtn, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    c.anchor = GridBagConstraints.WEST;
    c.gridwidth = 1;
    add(new Label("1) Construct base"), c);
    c.gridx++;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.EAST;
    baseBtn = new Button("construct base");
    baseBtn.setActionCommand("construct");
    add(baseBtn, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.anchor = GridBagConstraints.CENTER;
    c.gridwidth = GridBagConstraints.REMAINDER;
    add(new Label("base represented as (n+1) x (n+1) matrix M"), c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    taLattice = new TextArea("", 10, 70);
    taLattice.setBackground(Color.lightGray);
    taLattice.setEditable(false);
    add(taLattice, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = 1;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("2) Reduce base"), c);

    c.gridx++;
    c.anchor = GridBagConstraints.CENTER;
    p = new Panel();
    cbg = new CheckboxGroup();
    runOnce = new Checkbox("run once", cbg, !runToEnd);
    p.add(runOnce);
    runAll = new Checkbox("run", cbg, runToEnd);
    p.add(runAll);
    add(p, c);

    c.gridx++;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,0);
    redBtn = new Button("reduce base");
    redBtn.setActionCommand("reduce");
    add(redBtn, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    add(new Label("reduced base represented as (n+1) x (n+1) matrix M' after applying the L3 algorithm"), c); 

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    taRedLattice = new TextArea("", 10, 70);
    taRedLattice.setBackground(Color.lightGray);
    taRedLattice.setEditable(false);
    add(taRedLattice, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridx = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("3) Matching vectors of reduced base"), c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.insets = new Insets(0,0,10,0);
    taSol = new TextArea("", 3, 70);
    taSol.setBackground(Color.lightGray);
    taSol.setEditable(false);
    add(taSol, c);

    c = new GridBagConstraints();
    c.gridy = ++gridy;
    c.gridwidth = 2;
    c.anchor = GridBagConstraints.WEST;
    add(new Label("4) Try to get a solution vector"), c);

    c.gridx = 2;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(0,0,0,0);
    solBtn = new Button("find solution");
    solBtn.setActionCommand("sum");
    add(solBtn, c);

    c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = ++gridy;
    c.gridwidth = GridBagConstraints.REMAINDER;
    taSol2 = new TextArea("", 8, 70);
    taSol2.setBackground(Color.lightGray);
    taSol2.setEditable(false);
    add(taSol2, c);

    for (int i=visible; i<maxVisible; i++)
    {
      tf[i].setEditable(false);
      tf[i].setBackground(Color.gray);
    }

    baseBtn.addActionListener(this);
    redBtn.addActionListener(this);
    solBtn.addActionListener(this);
    keyBtn.addActionListener(this);
    ch.addItemListener(this);

    for (int i=0; i<maxVisible; i++)
      tf[i].addTextListener(this);

    tfChiffre.addTextListener(this);

    /* create private key */
    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(startVal, startVal << 1));

    /* create public key */
    pubKey = privKey.getPubKey();

    /* set textfields with values of public key */
    for (int i=0; i<visible; i++)
      tf[i].setText(new Long(pubKey.getElement(i)).toString());

    /* create random plaintext and the corresponding cyphertext */
    plain = Tools.randomNumber(1, (1 << visible) -1 );
    chiffre = pubKey.encrypt(plain);

    tfChiffre.setText(Long.toString(chiffre));
    lParam.setText(getParamString(visible, pubKey.getDensity(precision)));

  } /* end init() */

  public void actionPerformed(ActionEvent e)
  {
    String cmd = e.getActionCommand();
    String outStr;

    if (cmd.equals("key"))
    {
      /* create private and public key */
      privKey = new MH(visible);
      privKey.getPrivKey(getStartVal());
      pubKey = privKey.getPubKey();

      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(pubKey.getElement(i)));

      /* create random plaintext and the corresponding cyphertext */
      plain = Tools.randomNumber(1, (1 << visible) -1 );
      chiffre = pubKey.encrypt(plain);

      tfChiffre.setText(Long.toString(chiffre));
      lParam.setText(getParamString(visible, pubKey.getDensity(precision)));

      cnt = 0;
      list = null;

      return;
    }

    if (cmd.equals("construct"))
    {
      clearFields(1);

      Knapsack k;
      long c;

      if ((k = getKnapsack(visible)) == null)
        return;

      pubKey = k;

      if ((c = getC()) == -1)
        return;

      chiffre = c;

      lattice = new Lattice(pubKey, chiffre);
      redLattice = null;

      taLattice.setText(lattice.toString("m"));

      d = pubKey.getDensity(precision);
      lParam.setText(getParamString(visible, d));

      cnt = 0;
      list = null;

      return;
    }

    if (cmd.equals("reduce"))
    {
      clearFields(2);

      if (lattice == null)
      {
        taRedLattice.setText("first create base");

        return;
      }

      runToEnd = runAll.getState();

      /* run reduction step by step */
      if (!runToEnd)
      {
        redLattice = new Lattice(lattice);
        redLattice.reduce(++cnt);
        taRedLattice.setText(redLattice.toString("m'"));

        if (cnt < (redLattice.getRows() -1))
          return;
      }

      /* run reduction till the end */
      else
      {
        redLattice = new Lattice(lattice);
        redLattice.reduce(Lattice.RUNALL);
        taRedLattice.setText(redLattice.toString("m'"));

        cnt = redLattice.getRows() -1;
      }

      list = checkReducedLattice(redLattice);

      if (!list.isEmpty())
      {
        int index;

        for (int i=0; i<list.size(); i++)
        {
          index = ((Integer)list.elementAt(i)).intValue();

          outStr = "m'(" +Integer.toString(index+1) +"):\t" +redLattice.getRow(index).toString();
          outStr += "\n";
          taSol.append(outStr);
        }
      }
      else
        taSol.setText("no suitable vector found\n");

      return;
    }

    if (cmd.equals("sum"))
    {
      clearFields(3);

      if ( lattice == null)
      {
        taSol2.setText("first create base");
        return;
      }

      if ( redLattice == null)
      {
        taSol2.setText("first reduce base");
        return;
      }

      if (list == null)
      {
        taSol2.setText("reduce base to the end");
        return;
      }

      if (list.size() == 0)
      {
        taSol2.setText("nothing to do");
        return;
      }

      findSolVec(redLattice, list);

      return;
    }
  } /* end actionPerfomed() */

  public void itemStateChanged(ItemEvent ie)
  {
    Object obj = ie.getItem();
    String str;

    cnt = 0;
    int newVisible = Integer.parseInt(obj.toString());

    /* restore old values */
    if (visible == newVisible)
    {
      for (int i=0; i<visible; i++)
        tf[i].setText(Long.toString(pubKey.getElement(i)));

      tfChiffre.setText(Long.toString(chiffre));

      return;
    }

    /* new dimension of public knapsack */
    lattice = null;
    redLattice = null;

    clearFields(1);

    if (visible < newVisible)
      for (int i=visible; i<newVisible; i++)
      {
        tf[i].setBackground(Color.white);
        tf[i].setEditable(true);
      }
    else
      for (int i=newVisible; i<visible; i++)
      {
        tf[i].setText("");
        tf[i].setBackground(Color.gray);
        tf[i].setEditable(false);
      }

    visible = newVisible;

    privKey = new MH(visible);
    privKey.getPrivKey(Tools.randomNumber(startVal, startVal << 1));

    pubKey = privKey.getPubKey();

    for (int i=0; i<visible; i++)
      tf[i].setText(Long.toString(pubKey.getElement(i)));

    plain = Tools.randomNumber(1, (0x01 << visible) - 1);
    chiffre = pubKey.encrypt(plain);

    tfChiffre.setText(Long.toString(chiffre));
    lParam.setText(getParamString(visible, pubKey.getDensity(precision)));

    return;
  } /* end itemStateChanged() */

  public void textValueChanged(TextEvent te)
  {
    /* some values have been changed so first create a new lattice */
    lattice = null;
    redLattice = null;
    list = null;
    cnt = 0;

    clearFields(1);

    return;
  }

  public String getParamString(int visible, double d)
  {
    String res = "n = " +Integer.toString(visible);
    res += ", t = " +Double.toString(Math.ceil(0.5*Math.sqrt((double)visible)));
    res += ", d = " +d;

    return (res);
  }

  public Knapsack getKnapsack(int visible)
  {
    String[] s = new String[visible];
    Knapsack k;

    for (int i=0; i<visible; i++)
      s[i] = tf[i].getText();

    try
    {
      k = new Knapsack(s, name, false);
    }  
    catch (notAKnapsackException ke)
    {
      taLattice.setText(ke.getMessage());
      return (null);
    }

    return (k);

  } /* end getKnapsack() */


  public long getC()
  {
    long c = 0;

    try
    {
      c = Long.parseLong(tfChiffre.getText());
    }
    catch (NumberFormatException nfe)
    {
      taLattice.setText("c: <" +tfChiffre.getText() +"> not a number");

      return (-1);
    }

    if (c < 0)
    {
      taLattice.setText("c: no negative values");

      return (-1);
    }

    return (c);
  } /* end getC() */


  /* Is there a row with zero as last component and the others are in {0.5, -0.5} ? */
  private Vector checkReducedLattice(Lattice lat)
  {
    int row = lat.getRows();
    int cnt;

    Vector vec = new Vector();
    myVector myVecTmp;

    for (int i=0; i<row; i++)
    {
      cnt = 0;
      myVecTmp = lat.getRow(i);

      if (myVecTmp.getElement(myVecTmp.getDim()-1) != 0) /* last component != 0 ? */
        continue;

      for (int j=0; j<myVecTmp.getDim()-1; j++)
      {
        if (Math.abs(myVecTmp.getElement(j)) != 0.5)
          break;

        cnt++;
      }

      if (cnt == myVecTmp.getDim()-1) /* match */
        vec.addElement(new Integer(i));
    }

    return (vec);
  } /* end checkReducedLattice() */

  /* for all possible solution vectors Y compute SUM ( y(i) * b(i) ) */
  public void findSolVec(Lattice lat, Vector vec)
  {
    myVector myVecTmp = null;
    String outStr;

    long sum;
    int index;

    for (int i=0; i<vec.size(); i++)
    {
      sum = 0;
      index = ((Integer)vec.elementAt(i)).intValue();

      myVecTmp = lat.getRow(index);

      outStr = "X = 0.5 + m'(" +(index+1) +") = (";

      for (int j=0; j<myVecTmp.getDim() -1; j++)
        outStr += Integer.toString( (int)(myVecTmp.getElement(j) +0.5) ) +" ";

      outStr += ")\ncomputing s = SUM (x(i)*b(i)) = ";

      for (int j=0; j<myVecTmp.getDim() -1; j++)
      {
        if (myVecTmp.getElement(j) == 0.5)
        {
          sum += pubKey.getElement(j);
          outStr += pubKey.getElement(j) +" + ";
        }
      }

      outStr = outStr.substring(0, outStr.length() -2);
      outStr += " = ";

      outStr += Long.toString(sum);
      taSol2.append(outStr);

      outStr = "";

      if (sum == chiffre)
      {
        long msg = 0L;

        outStr = " = c\n\nFOUND SOLUTION:\nplainbits are (p(1) p(2) ... p(";
        outStr += (myVecTmp.getDim()-1) +")) = ( ";

        for (int j=0; j<myVecTmp.getDim() -1; j++)
        {
          msg = msg << 1;
          msg += (long)(myVecTmp.getElement(j) +0.5);
          outStr += Integer.toString( (int) (myVecTmp.getElement(j) +0.5)) +" ";
        }

        outStr += ")\nand the message is " +Long.toString(msg) +"\n";
        taSol2.append(outStr);

        return;
      }
      else
      {
        outStr = " != c = " +Long.toString(chiffre) +"\n\n";
        taSol2.append(outStr);
      }

      sum = 0;

      outStr = "X = 0.5 - m'(" +(index+1) +") = (";

      for (int j=0; j<myVecTmp.getDim() -1; j++)
        outStr += Integer.toString( (int)(0.5 - myVecTmp.getElement(j)) ) +" ";

      outStr += ")\ncomputing s = SUM (x(i)*b(i)) = ";

      for (int j=0; j<myVecTmp.getDim() -1; j++)
      {
        if (myVecTmp.getElement(j) == -0.5)
        {
          sum += pubKey.getElement(j);
          outStr += pubKey.getElement(j) +" + ";
        }
      }

      outStr = outStr.substring(0, outStr.length() -2);
      outStr += " = ";

      outStr += Long.toString(sum);
      taSol2.append(outStr);

      if (sum == chiffre)
      {
        long msg = 0L;

        outStr = " = c\n\nFOUND SOLUTION:\nplainbits are (p(1) p(2) ... p(";
        outStr += (myVecTmp.getDim()-1) +")) = (";

        for (int j=0; j<myVecTmp.getDim() -1; j++)
        {
          msg = msg << 1;
          msg += (long)(0.5 - myVecTmp.getElement(j));
          outStr += Integer.toString( (int) (0.5 - myVecTmp.getElement(j))) +" ";
        }

        outStr += ")\nand the message is " +Long.toString(msg) +"\n";
        taSol2.append(outStr);

        return;
      }

      else
      {
        outStr = " != c = " +Long.toString(chiffre) +"\n\n";
        taSol2.append(outStr);
      }

    } /* end for */

    return;

  } /* end findSolVec() */


  public long getStartVal()
  {
    long s;

    try
    {
      s = Long.parseLong(tf[0].getText());
    }
    catch (NumberFormatException nfe)
    {
      return (Tools.randomNumber(startVal, startVal << 1));
    }

    if ( (s < 1) | (s > 1023) )
      return (Tools.randomNumber(startVal, startVal << 1));
 
    return (s);
 }


  public void clearFields(int which)
  {
    taSol2.setText("");

    if (which == 3)
      return;

    taRedLattice.setText("");

    taSol.setText("");

    if (which == 2)
      return;

    taLattice.setText("");

    return;
  } /* end clearFields() */

} /* end class LowDenseApplet */