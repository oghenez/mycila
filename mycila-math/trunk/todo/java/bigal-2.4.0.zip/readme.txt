Description
-----------

BigAl 2.4.0 (June 23, 2007)
is free software written entirely in Java for calculating
really big numbers.

BigAl 2.4.0 has been released under the terms of the GNU GPLv2
or later.

Copyright (c) Dipl.-Inf. (FH) Johann N. Loefflmann
mailto: jonelo@jonelo.de



FAQs
----

Q: What is required to run BigAl ?

A: BigAl is written entirely in Java, therefore it runs on each
   computer with a Java Runtime Environment (JRE) installed.
   At least the JRE 1.4.2 is required, however the JRE 5 or JRE 6
   is recommended.



Q: Where can I download a JRE ?

A: For a list of available JREs for your operating system go to
   http://www.jonelo.de/java/faq/index.html#download

   Windows- and Linux-user can download the latest JRE from
   http://www.java.com
   or
   http://java.sun.com/javase

   BigAl also runs on FOSS JVMs
   http://openjdk.java.net/ (OpenJDK)
   http://gcc.gnu.org/java/ (GCC with GCJ)
   http://www.kaffe.org/ (Kaffe)



Q: Do I need to install BigAl ?

A: No, an installation is not required. You can use BigAl also
   without an installation. All you need is a JRE
   and the file called bigal.jar. 
   
   However, if you would like to use BigAl on your operating
   system with a little more comfort, it is recommended to add
   the program to the program path of your operating system. 



Q: Can I use Bigal as a portable application on an USB Stick ?

A: Yes, all you need is a JRE (installed on the host or on the
   USB stick) and the file called bigal.jar



Q: How can I install BigAl on my computer ?

A: Simply add the program to the program path of your operating
   system. Usually, the environment variable called PATH can be used.
   
   For Windows, a small installer called setup.exe is attached
   which can do the installation for you.
   
   For a manual installation use the attached batch file called
   bigal.bat (Windows) or use the attached script file called
   bigal (Linux/Unix). In those files you find further instructions
   for a manual installation.



Q: How do I start BigAl ?

A: Open a Terminal (in the Windows-World it is known as "Command Prompt").
   There are many ways to start BigAl.

   If you have added BigAl to your program path you can start BigAl
   independent of your current working directory just by typing

        bigal

   If you haven't installed BigAl, you can start BigAl by typing

        java -jar bigal.jar

   or

        java -classpath bigal.jar BigAl

   or

        java BigAl

        The environment variable called CLASSPATH must point
        to bigal.jar in this case.

   or

        ./bigal.jar
  
        Linux/Unix only. The file bigal.jar must have both execute
        permissions (chmod 755 bigal.jar) and your Linux- respectively
        Unix-Derivate must support the execution of .jar files
        (e. g. Solaris 10+).


   On a FOSS JVMs start BigAl by typing

        java -jar bigal.jar

   respectively

         gij -jar bigal.jar

   respectively
   
         kaffe -jar bigal.jar

   Here are a few examples to see BigAl in action

         bigal 1 + 2
         bigal 2 pow 1000
         bigal 1 divide 12345
  
   More examples can be found in the EXAMPLES section.

         bigal help



Updates
-------
Keep updated by sending an email to
  announce-subscribe@bigal.dev.java.net 

Get the latest BigAl version from
  http://www.jonelo.de/java/bigal/index.html


Files
-----
bigal             A script to launch BigAl on Unix/Linux
bigal-src.zip     The sources of BigAl
bigal.bat         A batch to launch BigAl on Windows
bigal.jar         The BigAl application
history.txt       A program history
license.txt       The license file (GPL)
liesmich.txt      A german readme
readme.txt        An english readme (this file)
setup.exe         A tiny installer to install BigAl on Windows
