import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Label;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventObject;
import pv.awt.PVEdit;
import pv.awt.PVNumeric;
import pv.awt.PVSpin;
import pv.awt.PVSpinPlus;

public class LCMPanel extends Panel
  implements ActionListener
{
  LCM Parent;
  PVSpin NSpin;
  PVNumeric NEdit;
  Button Compute;

  public LCMPanel(LCM paramLCM)
  {
    this.Parent = paramLCM;
    try
    {
      setBackground(new Color(Integer.parseInt(this.Parent.getParameter("BCOLOR"), 16)));
      setForeground(new Color(Integer.parseInt(this.Parent.getParameter("FCOLOR"), 16)));
    }
    catch (Exception localException1)
    {
      setBackground(Color.lightGray);
      setForeground(Color.black);
    }
    int i = 4;
    try
    {
      i = Integer.parseInt(this.Parent.getParameter("N"));
    }
    catch (Exception localException2)
    {
    }
    setLayout(new FlowLayout(2));
    add(this.Compute = new Button("Compute"));
    this.Compute.addActionListener(this);
    add(new Label(" "));
    this.NSpin = new PVSpinPlus(9);
    this.NEdit = new PVNumeric();
    Font localFont = new Font("Serif", 0, 17);
    add(localLabel = new Label("# of numbers"));
    localLabel.setFont(localFont);
    add(this.NSpin);
    this.NSpin.setStyle(9);
    this.NSpin.setButtonWidth(20);
    this.NSpin.addActionListener(this);
    this.NEdit.setEnableFloatPoint(true);
    this.NEdit.setMaxLength(10);
    this.NEdit.setEnabled(true);
    this.NEdit.setDelta(1D);
    this.NEdit.setLong(i);
    this.NEdit.setMaxDecimals(0);
    this.NEdit.setSize(24, 24);
    this.NEdit.setMinValue(2.0D);
    this.NEdit.setMaxValue(6.0D);
    this.NSpin.setObject(this.NEdit);
    this.NSpin.addActionListener(this);
    this.NEdit.addActionListener(this);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    Object localObject = paramActionEvent.getSource();
    if (localObject == this.Compute)
    {
      this.Parent.SPane.doLayout();
      this.Parent.InfoCanvas.Compute = true;
      this.Parent.InfoCanvas.repaint();
    }
    else
    {
      switch (paramActionEvent.getModifiers())
      {
      case 64:
      case 128:
        if (localObject != this.NSpin)
          return;
        this.Parent.m_Canvas.N = (int)this.NEdit.getLong();
        this.Parent.m_Canvas.Reset();
        this.Parent.m_Canvas.repaint();
        this.Parent.InfoCanvas.Compute = false;
        this.Parent.InfoCanvas.repaint();
        break;
      case 1:
        if (localObject != this.NEdit)
          return;
        this.Parent.m_Canvas.N = (int)this.NEdit.getLong();
        this.Parent.m_Canvas.Reset();
        this.Parent.m_Canvas.repaint();
        this.Parent.InfoCanvas.Compute = false;
        this.Parent.InfoCanvas.repaint();
      }
    }
  }
}