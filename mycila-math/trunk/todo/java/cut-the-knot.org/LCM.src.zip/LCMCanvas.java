import java.applet.Applet;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.ScrollPane;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

class LCMCanvas extends Canvas
  implements MouseListener, MouseMotionListener
{
  private Image m_Image;
  private Graphics m_Graph;
  private LCM m_Parent;
  private boolean m_bInitialized = false;
  Font FontB;
  int N;
  CTKNumberLim[] Nums;
  int[] Tabs;
  int FontHeight;
  int FontSize = 27;
  int MaxFontSize = this.FontSize;
  int Spread = 2;
  boolean PropogateSpread = false;

  public void IncreaseSpread(int paramInt)
  {
    if (paramInt > this.Spread + 1)
    {
      this.Spread = (paramInt - 1);
      this.PropogateSpread = true;
      repaint();
    }
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(200, 40);
  }

  public LCMCanvas(LCM paramLCM)
  {
    this.m_Parent = paramLCM;
    try
    {
      setBackground(new Color(Integer.parseInt(this.m_Parent.getParameter("BCOLOR"), 16)));
      setForeground(new Color(Integer.parseInt(this.m_Parent.getParameter("FCOLOR"), 16)));
    }
    catch (Exception localException)
    {
      setBackground(Color.lightGray);
      setForeground(Color.black);
    }
    addMouseListener(this);
    addMouseMotionListener(this);
  }

  public void paint(Graphics paramGraphics)
  {
    update(paramGraphics);
  }

  public void update(Graphics paramGraphics)
  {
    if (!(this.m_bInitialized))
      init();
    Dimension localDimension = getSize();
    this.m_Graph.setColor(getBackground());
    this.m_Graph.fillRect(0, 0, localDimension.width, localDimension.height);
    this.m_Graph.setColor(getForeground());
    this.m_Graph.drawRect(0, 0, localDimension.width - 1, localDimension.height - 1);
    DrawNums(this.m_Graph);
    paramGraphics.drawImage(this.m_Image, 0, 0, null);
    if (this.PropogateSpread)
    {
      this.PropogateSpread = false;
      this.m_Parent.InfoCanvas.Compute = true;
      this.m_Parent.SPane.doLayout();
      this.m_Parent.InfoCanvas.repaint();
    }
  }

  private void DrawNums(Graphics paramGraphics)
  {
    Dimension localDimension = getSize();
    int i = 5;
    paramGraphics.setFont(this.FontB);
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int j = this.Spread;
    for (int k = 0; k < this.Nums.length; ++k)
    {
      l = this.Nums[k].GetValue().toString().length();
      if (j < l)
        j = l;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    for (int l = 0; l <= j; ++l)
      localStringBuffer.append("w");
    l = localFontMetrics.stringWidth(localStringBuffer.toString());
    for (int i1 = (localDimension.width - l * (this.N - 1)) / 2; i1 < 0; i1 = (localDimension.width - l * (this.N - 1)) / 2)
    {
      paramGraphics.setFont(this.FontB = new Font(this.FontB.getFamily(), this.FontB.getStyle(), this.FontB.getSize() - 1));
      localFontMetrics = paramGraphics.getFontMetrics();
      l = localFontMetrics.stringWidth(localStringBuffer.toString());
    }
    this.FontHeight = localFontMetrics.getAscent();
    for (int i2 = 0; i2 < this.N; ++i2)
      this.Tabs[i2] = (i1 + l * i2);
    paramGraphics.setColor(Color.red);
    for (i2 = 0; i2 < this.N; ++i2)
    {
      int i3 = localFontMetrics.stringWidth(this.Nums[i2].GetValue().toString());
      this.Nums[i2].SetBorder(new Rectangle(this.Tabs[i2] - i3, localDimension.height - i - this.FontHeight, i3, this.FontHeight));
      this.Nums[i2].Draw(paramGraphics);
    }
  }

  public void init()
  {
    Dimension localDimension = getSize();
    this.m_Image = createImage(localDimension.width, localDimension.height);
    this.m_Graph = this.m_Image.getGraphics();
    try
    {
      ((Graphics2D)this.m_Graph).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }
    catch (Exception localException1)
    {
      this.m_Graph.dispose();
      this.m_Image = createImage(localDimension.width, localDimension.height);
      this.m_Graph = this.m_Image.getGraphics();
    }
    try
    {
      this.N = Integer.parseInt(this.m_Parent.getParameter("N"));
    }
    catch (Exception localException2)
    {
      this.N = 4;
    }
    Reset();
    this.m_bInitialized = true;
  }

  public void Reset()
  {
    Reset(true);
  }

  public void Reset(boolean paramBoolean)
  {
    this.Spread = 2;
    Dimension localDimension = getSize();
    try
    {
      int[] arrayOfInt = new int[this.N];
      this.Nums = new CTKNumberLim[this.N];
      this.Tabs = new int[this.N];
      for (int i = 0; i < this.N; ++i)
      {
        arrayOfInt[i] = (int)(Math.random() * 50.0D + 1D);
        this.Nums[i] = new CTKNumberLim(this, arrayOfInt[i]);
        this.Nums[i].SetLimits(1, 10000);
      }
    }
    catch (Exception localException)
    {
    }
    this.FontB = new Font("Serif", 0, this.FontSize = this.MaxFontSize);
    this.m_Graph.setFont(this.FontB);
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.N; ++i)
      if (this.Nums[i].IsHit(paramMouseEvent.getX(), paramMouseEvent.getY()))
      {
        this.Nums[i].Update();
        this.m_Parent.InfoCanvas.Compute = false;
        this.m_Parent.InfoCanvas.repaint();
        repaint();
        return;
      }
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.N; ++i)
      if (this.Nums[i].IsHit(paramMouseEvent.getX(), paramMouseEvent.getY()))
      {
        this.Nums[i].UpdateFast();
        this.m_Parent.InfoCanvas.Compute = false;
        this.m_Parent.InfoCanvas.repaint();
        repaint();
        return;
      }
  }

  private void StopComputing()
  {
    this.m_Parent.InfoCanvas.Compute = false;
    this.m_Parent.InfoCanvas.repaint();
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
  }
}