import java.applet.Applet;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.ScrollPane;

class LCMInfoCanvas extends Canvas
{
  private Image m_Image;
  private Graphics m_Graph;
  private LCM m_Parent;
  private Dimension PreferredSize = new Dimension(200, 200);
  boolean Compute = false;

  public Dimension getPreferredSize()
  {
    return this.PreferredSize;
  }

  public LCMInfoCanvas(LCM paramLCM)
  {
    this.m_Parent = paramLCM;
    try
    {
      setBackground(new Color(Integer.parseInt(this.m_Parent.getParameter("BCOLOR"), 16)));
      setForeground(new Color(Integer.parseInt(this.m_Parent.getParameter("FCOLOR"), 16)));
    }
    catch (Exception localException)
    {
      setBackground(Color.lightGray);
      setForeground(Color.black);
    }
  }

  public void paint(Graphics paramGraphics)
  {
    update(paramGraphics);
  }

  public void update(Graphics paramGraphics)
  {
    Dimension localDimension = getSize();
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, localDimension.width, localDimension.height);
    if (this.Compute)
      DrawNums(paramGraphics);
  }

  private void DrawNums(Graphics paramGraphics)
  {
    Dimension localDimension = getSize();
    Font localFont = this.m_Parent.m_Canvas.FontB;
    localFont = new Font(localFont.getFamily(), 0, localFont.getSize() - 1);
    paramGraphics.setFont(localFont);
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int i = localFontMetrics.getAscent() - localFontMetrics.getDescent() / 2;
    long[] arrayOfLong1 = new long[this.m_Parent.m_Canvas.Nums.length];
    long[] arrayOfLong2 = new long[this.m_Parent.m_Canvas.Nums.length];
    int j = 0;
    if (j < this.m_Parent.m_Canvas.Nums.length)
    {
      int tmp135_116 = j;
      tmp135_116[(arrayOfLong1[tmp135_116] = this.m_Parent.m_Canvas.Nums[j].GetIntValue())] = j;
    }
    paramGraphics.setColor(getForeground());
    try
    {
      ((Graphics2D)paramGraphics).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }
    catch (Exception localException1)
    {
      this.m_Graph.dispose();
      this.m_Image = createImage(localDimension.width, localDimension.height);
      this.m_Graph = this.m_Image.getGraphics();
    }
    int k = 1;
    int l = 0;
    if ((l == 0) && (!(IsOver(arrayOfLong2))));
    try
    {
      int i1 = Min(arrayOfLong2);
      arrayOfLong2[i1] += arrayOfLong1[i1];
      for (int i2 = 0; (l == 0) && (i2 < this.m_Parent.m_Canvas.Nums.length); ++i2)
      {
        String str = "" + arrayOfLong2[i2];
        int i4 = localFontMetrics.stringWidth(str);
        paramGraphics.setColor((i2 == i1) ? Color.blue : getForeground());
        ((Graphics2D)paramGraphics).drawString(str, this.m_Parent.m_Canvas.Tabs[i2] - i4 - 3, k * i);
      }
      ++k;
    }
    catch (Exception l1)
    {
      long l1 = Max(arrayOfLong2);
      int i3 = "" + l1.length();
      this.m_Parent.m_Canvas.IncreaseSpread(i3);
      if (this.PreferredSize.height != k * i)
      {
        this.PreferredSize.height = (k * i);
        this.m_Parent.SPane.doLayout();
      }
    }
  }

  private boolean IsOver(long[] paramArrayOfLong)
  {
    for (int i = 0; i < paramArrayOfLong.length - 1; ++i)
      if (paramArrayOfLong[i] != paramArrayOfLong[(i + 1)])
        return false;
    return true;
  }

  private int Min(long[] paramArrayOfLong)
  {
    int i = -1;
    long l = 1000000L;
    for (int j = 0; j < paramArrayOfLong.length; ++j)
      if (paramArrayOfLong[j] < l)
      {
        l = paramArrayOfLong[j];
        i = j;
      }
    return i;
  }

  private long Max(long[] paramArrayOfLong)
  {
    long l = -4584371143116324864L;
    for (int i = 0; i < paramArrayOfLong.length; ++i)
      if (paramArrayOfLong[i] > l)
        l = paramArrayOfLong[i];
    return l;
  }

  public void init()
  {
    Dimension localDimension = getSize();
    this.m_Image = createImage(localDimension.width, localDimension.height);
    this.m_Graph = this.m_Image.getGraphics();
    try
    {
      ((Graphics2D)this.m_Graph).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }
    catch (Exception localException)
    {
      this.m_Graph.dispose();
      this.m_Image = createImage(localDimension.width, localDimension.height);
      this.m_Graph = this.m_Image.getGraphics();
    }
    Reset();
  }

  public void Reset()
  {
    Reset(true);
  }

  public void Reset(boolean paramBoolean)
  {
  }
}