import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Panel;
import java.awt.ScrollPane;

public class LCM extends Applet
{
  LCMCanvas m_Canvas;
  ScrollPane SPane;
  LCMInfoCanvas InfoCanvas;

  public java.lang.String getAppletInfo()
  {
    return "Name: LCM - a CTK Applet\r\nAuthor: Alexander Bogomolny";
  }

  public void init()
  {
    super.init();
    try
    {
      setBackground(new Color(Integer.parseInt(super.getParameter("BCOLOR"), 16)));
      setForeground(new Color(Integer.parseInt(super.getParameter("FCOLOR"), 16)));
    }
    catch (Exception localException)
    {
      setBackground(Color.white);
      setForeground(Color.black);
    }
    setLayout(new BorderLayout());
    Panel localPanel = new Panel();
    add(localPanel, "Center");
    localPanel.setLayout(new BorderLayout());
    this.m_Canvas = new LCMCanvas(this);
    localPanel.add(this.m_Canvas, "North");
    localPanel.add(this.SPane = new ScrollPane(0), "Center");
    this.SPane.add(this.InfoCanvas = new LCMInfoCanvas(this));
    localPanel.add(new LCMPanel(this), "South");
    add(new CTKImprint1(this), "South");
  }

  public java.lang.String[][] getParameterInfo()
  {
    [Ljava.lang.String[] arrayOfString; = { { "WIDTH", "int", "(400 will do)" }, { "HEIGHT", "int", "(300 will do)" }, { "FCOLOR", "string", "000000" }, { "BCOLOR", "string", "c0dcc0" } };
    return arrayOfString;;
  }
}