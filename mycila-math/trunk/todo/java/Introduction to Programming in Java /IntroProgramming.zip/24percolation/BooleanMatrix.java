/*************************************************************************
 *  Compilation:  javac BooleanMatrix.java
 *  Execution:    java BooleanMatrix N p
 *
 *  Library of static methods for manipulating boolean matrices.
 *
 *  % java BooleanMatrix 5 .3
 *  5
 *  0 0 1 0 1 
 *  0 0 0 0 0 
 *  0 1 0 0 0 
 *  0 0 0 0 0 
 *  0 0 1 0 0 

 *
 *************************************************************************/

public class BooleanMatrix {

    // read matrix from standard input
    public static boolean[][] read() {
        int N = StdIn.readInt();
        boolean[][] a = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (StdIn.readInt() != 0) a[i][j] = true;
            }
        }
        return a; 
    } 

    // print matrix to standard output
    public static void print(boolean[][] a) {
        int N = a.length;
        System.out.println(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (a[i][j]) System.out.print("1 ");
                else         System.out.print("0 ");
            }
            System.out.println();
        }
    } 

    // random N-by-N matrix, where each entry is true with probability p
    public static boolean[][] random(int N, double p) {
        boolean[][] a = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                a[i][j] = StdRandom.bernoulli(p);
            }
        }
        return a;
    }

    // display the matrix using standard draw
    // depending on variable which, plot true or false entries in foreground color
    public static void show(boolean[][] a, boolean which) {
        int N = a.length;
        StdDraw.setXscale(0, N-1);
        StdDraw.setYscale(0, N-1);
        double r = 0.5;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (a[i][j] == which) {
                    StdDraw.filledSquare(j, N-i-1, r);
                }
            }
        }
    }

    // test client
    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        double p = Double.parseDouble(args[1]);
        boolean[][] a = random(N, p);
        print(a);
        show(a, true);
    }

}
