/*************************************************************************
 *  Compilation:  javac Vector.java
 *  Execution:    java Vector
 *
 *  Implementation of a vector of real numbers.
 *
 *  This class is implemented to be immutable: once the client program
 *  initialize a Vector, it cannot change any of its fields
 *  (N or data[i]) either directly or indirectly. Immutability is a
 *  very desirable feature of a data type.
 *
 *  % java Vector
 *  x        = ( 1.0 2.0 3.0 4.0 )
 *  y        = ( 5.0 2.0 4.0 1.0 )
 *  x + y    = ( 6.0 4.0 7.0 5.0 )
 *  10x      = ( 10.0 20.0 30.0 40.0 )
 *  |x|      = 5.477225575051661
 *  <x, y>   = 25.0
 *  |x - y|  = 5.0990195135927845
 *
 *
 *  Note that Vector is also the name of an unrelated Java library class.
 *
 *************************************************************************/

public class Vector {
    private final int N;         // length of the vector
    private double[] data;       // array of vector's components


    // create the zero vector of length n
    public Vector(int N) {
        this.N    = N;
        this.data = new double[N];
    }

    // create a vector from the array d
    public Vector(double[] d) {
        N = d.length;

        // defensive copy so that client can't alter our copy of data[]
        data = new double[N];
        for (int i = 0; i < N; i++) {
            data[i] = d[i];
        }
    }

    // return the inner product of this Vector a and b
    public double dot(Vector b) {
        Vector a = this;
        if (a.N != b.N)  { throw new RuntimeException("Dimensions don't agree"); }
        double sum = 0.0;
        for (int i = 0; i < N; i++) {
            sum = sum + (a.data[i] * b.data[i]);
        }
        return sum;
    }

    // return the Euclidean norm of this Vector a
    public double magnitude() {
        Vector a = this;
        return Math.sqrt(a.dot(a));
    }

    // return the corresponding unit vector
    public Vector direction() {
        Vector a = this;
        return a.times(1.0 / a.magnitude());
    }

    // return a + b
    public Vector plus(Vector b) {
        Vector a = this;
        if (a.N != b.N) { throw new RuntimeException("Dimensions don't agree"); }
        Vector c = new Vector(N);
        for (int i = 0; i < N; i++) {
            c.data[i] = a.data[i] + b.data[i];
        }
        return c;
    }

    // return a - b
    public Vector minus(Vector b) {
        Vector a = this;
        if (a.N != b.N) { throw new RuntimeException("Dimensions don't agree"); }
        Vector c = new Vector(N);
        for (int i = 0; i < N; i++) {
            c.data[i] = a.data[i] - b.data[i];
        }
        return c;
    }

    // create and return a new object whose value is (this * factor)
    public Vector times(double factor) {
        Vector c = new Vector(N);
        for (int i = 0; i < N; i++) {
            c.data[i] = factor * data[i];
        }
        return c;
    }

    // return the corresponding unit vector
    public double cartesian(int i) {
        return data[i];
    }

    // return a string representation of the vector
    public String toString() {
        String s = "( ";
        for (int i = 0; i < N; i++) {
            s = s + data[i] + " ";
        }
        return s + ")";
    }




    // test client
    public static void main(String[] args) {
        double[] xdata = { 1.0, 2.0, 3.0, 4.0 };
        double[] ydata = { 5.0, 2.0, 4.0, 1.0 };

        Vector x = new Vector(xdata);
        Vector y = new Vector(ydata);

        System.out.println("x        = " + x);
        System.out.println("y        = " + y);
        System.out.println("x + y    = " + x.plus(y));
        System.out.println("10x      = " + x.times(10.0));
        System.out.println("|x|      = " + x.magnitude());
        System.out.println("<x, y>   = " + x.dot(y));
        System.out.println("|x - y|  = " + x.minus(y).magnitude());

    }
}
