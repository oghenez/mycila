
/*************************************************************************
 *  Compilation:  javac RandomQueue.java
 *  Execution:    java RandomQueue
 *
 *  A generic randomized queue, implemented using a doubling array.
 *
 *************************************************************************/

import java.util.Iterator;
import java.util.NoSuchElementException;

// suppress unchecked warnings in Java 1.5.0_6 and later
@SuppressWarnings("unchecked")

public class RandomQueue<Item> implements Iterable<Item> {
    private Item[] a;          // array of items
    private int N = 0;         // number of elements on queue

    public RandomQueue() { this(8); }

    public RandomQueue(int maxN) {
        // need cast because Java does not support generic array creation
        a = (Item[]) new Object[Math.max(1, maxN)];
    }

    public boolean isEmpty() { return N == 0; }
    public int size()        { return N;      }


    // resize the underlying array holding the elements
    private void resize(int max) {
        Item[] temp = (Item[]) new Object[max];
        for (int i = 0; i < N; i++)
            temp[i] = a[i];
        a = temp;
    }

    // insert an item
    public void enqueue(Item item) {
        if (N == a.length) resize(2*a.length);  // double size of array if necessary
        a[N++] = item;                          // add element
    }

    // remove an item
    public Item dequeue() {
        if (isEmpty()) throw new RuntimeException("Random queue underflow");

        // swap random element a[r] with a[N-1]
        int r = StdRandom.uniform(N);
        Item value = a[r];
        a[r] = a[N-1];
        a[N-1] = null;            // to help garbage collector
        N--;
        if (N == a.length/4) resize(a.length/2);
        return value;
    }

    // return a random item - sample with replacement
    public Item sample() {
        if (N == 0) throw new RuntimeException("No such element");
        int r = StdRandom.uniform(N);
        return a[r];
    }


    public Iterator<Item> iterator() { return new RandomQueueIterator(); }

    // an iterator, doesn't implement remove() since it's optional
    private class RandomQueueIterator implements Iterator<Item> {
        private int i = 0;
        private Item[] copy;  // random permutation of the original items

        public RandomQueueIterator() {
            copy = (Item[]) new Object[N];
            for (int j = 0; j < N; j++) {
                int r = StdRandom.uniform(j+1);   // between 0 and j
                copy[j] = copy[r];
                copy[r] = a[j];
            }
        }
        public boolean hasNext()  { return i < N;                               }
        public void remove()      { throw new UnsupportedOperationException();  }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return copy[i++];
        }
    }





    // a test client
    public static void main(String[] args) {
        int N = 10;
        if (args.length > 0) N = Integer.parseInt(args[0]);

        // enqueue the integer 0 to N-1
        RandomQueue<Integer> queue = new RandomQueue<Integer>();
        for (int i = 0; i < N; i++) {
            queue.enqueue(i);
        }

        // print out queue elements in random order
        for (int i : queue) {
            System.out.print(i + " ");
        }
        System.out.println();

        // delete queue elements in random order
        while (!queue.isEmpty()) {
            System.out.print(queue.dequeue() + " ");
        }
        System.out.println();

    }
}
