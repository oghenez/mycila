/*
 * EDU.cis.calculator.jnlpui.JNLPCompatibleUI.java     8/19/02
 *
 * Copyright (c) 2001, 2002 Rod Howell, All Rights Reserved.
 */

package EDU.ksu.cis.calculator.jnlpui;

// jnlp.jar is required to be in the classpath for compilation.  This file
// is available in the JNLP Developer's Pack, which can be downloaded from
// http://java.sun.com/products/javawebstart/download-jnlp.html

import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.event.ActionEvent;
import javax.jnlp.ClipboardService;
import EDU.ksu.cis.calculator.Calculator;
import java.awt.datatransfer.DataFlavor;
import javax.swing.text.DefaultEditorKit;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;
import javax.swing.JPopupMenu;
import javax.swing.text.Keymap;
import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;
import javax.swing.JMenuItem;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.jnlp.ServiceManager;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import javax.jnlp.UnavailableServiceException;

/**
 * A single-line text area with a scrollbar.  When an instance of this class
 * is constructed, it tries to access the {@link ClipboardService} provided by
 * the JNLP API, so that the system clipboard may be accessed when the
 * application is running under Java Web Start.  If this is successful,
 * a popup menu containing Cut, Copy, and Paste actions is associated with
 * the text area.  These actions use the ClipboardService.
 */
public class ScrollingDisplay extends JScrollPane {

  /**
   * Constructs a ScrollingDisplay.
   * @param t  The text field in the display.
   */
  public ScrollingDisplay(JTextArea t) {
    super(t, VERTICAL_SCROLLBAR_NEVER, HORIZONTAL_SCROLLBAR_ALWAYS);
    t.setFont(new Font("Monospaced", Font.PLAIN, 14));
    Keymap map = t.getKeymap();
    KeyStroke homeKey = KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0);
    map.removeKeyStrokeBinding(homeKey);
    map.addActionForKeyStroke(homeKey, new HomeAction(t));
    KeyStroke endKey = KeyStroke.getKeyStroke(KeyEvent.VK_END, 0);
    map.removeKeyStrokeBinding(endKey);
    map.addActionForKeyStroke(endKey, new EndAction(t));
    try {
      setJNLPClipboardActions(t);
    }
    catch (Throwable e) {
      // If unsuccessful, don't worry about it.
    }
  }

  /**
   * Defines the "Cut", "Copy" and "Paste" actions to use the JNLP API.
   * @param t  The text area to which the editing will be done.
   * @throws UnavailableServiceException  if no clipboard service is available.
   *                  (In practice, if no clipboard service is available,
   *                   this is usually because the JNLP API is unavailable.
   *                   In this case, {@link UnavailableServiceException}
   *                   will not be found, so that 
   *                   {@link NoClassDefFoundError} is actually thrown.)
   */
  private void setJNLPClipboardActions(JTextArea t) 
    throws UnavailableServiceException {
    ClipboardService cs = (ClipboardService)
      ServiceManager.lookup("javax.jnlp.ClipboardService");
    JPopupMenu menu = new JPopupMenu();
    menu.add(new JMenuItem(new CutAction(t, cs)));
    menu.add(new JMenuItem(new CopyAction(t, cs)));
    menu.add(new JMenuItem(new PasteAction(t, cs)));
    t.addMouseListener(new PopupListener(menu));
  }
}

/**
 * Event handler for a "Cut" event.
 */
class CutAction extends AbstractAction {

  /**
   * The component to which the cut is to be applied.
   */
  private JTextComponent display;

  /**
   * The system clipboard.
   */
  private ClipboardService clipboard;

  /**
   * Constructs a new CutAction.
   * @param t  The component to which the cut is to be applied.
   * @param cs The system clipboard.
   */
  public CutAction(JTextComponent t, ClipboardService cs) {
    display = t;
    clipboard = cs;
    putValue(Action.NAME, "Cut");
  }

  /**
   * Handles the event.  The parameter is ignored.
   */
  public void actionPerformed(ActionEvent e) {
    String sel = display.getSelectedText();
    if (sel != null) {
      clipboard.setContents(new StringSelection(sel));
      display.replaceSelection("");
    }
  }
}

/**
 * Event handler for a "Copy" event.
 */
class CopyAction extends AbstractAction {

  /**
   * The component to which the copy is to be applied.
   */
  private JTextComponent display;

  /**
   * The system clipboard.
   */
  private ClipboardService clipboard;

  /**
   * Constructs a new CopyAction.
   * @param t  The component to which the copy is to be applied.
   * @param cs The system clipboard.
   */
  public CopyAction(JTextComponent t, ClipboardService cs) {
    display = t;
    clipboard = cs;
    putValue(Action.NAME, "Copy");
  }

  /**
   * Handles the event.  The parameter is ignored.
   */
  public void actionPerformed(ActionEvent e) {
    String sel = display.getSelectedText();
    if (sel != null) {
      clipboard.setContents(new StringSelection(sel));
    }
  }
}

/**
 * Event handler for a "Paste" event.
 */
class PasteAction extends AbstractAction {

  /**
   * The component to which the copy is to be applied.
   */
  private JTextComponent display;

  /**
   * The system clipboard.
   */
  private ClipboardService clipboard;

  /**
   * Constructs a new PasteAction.
   * @param t  The component to which the copy is to be applied.
   * @param cs The system clipboard.
   */
  public PasteAction(JTextComponent t, ClipboardService cs) {
    display = t;
    clipboard = cs;
    putValue(Action.NAME, "Paste");
  }

  /**
   * Handles the event.  The parameter is ignored.
   */
  public void actionPerformed(ActionEvent e) {
    Transferable t = clipboard.getContents();
    try {
      display.replaceSelection
	((String) t.getTransferData(DataFlavor.stringFlavor));
    }
    catch (Exception ex) {
      // Fail silently.
    }
  }
}

/**
 * Event handler for the popup menu trigger.
 */
class PopupListener extends MouseAdapter {

  /**
   * The popup menu.
   */
  private JPopupMenu theMenu;

  /**
   * Constructs a new PopupListener.
   * @param m  The popup menu.
   */
  public PopupListener(JPopupMenu m) {
    theMenu = m;
  }

  /**
   * Handles the given MouseEvent, triggered when the mouse is pressed.
   */
  public void mousePressed(MouseEvent e) {
    handleEvent(e);
  }

  /**
   * Handles the given MouseEvent, triggered when the mouse is released.
   */
  public void mouseReleased(MouseEvent e) {
    handleEvent(e);
  }

  /**
   * The event handler code.  If the event is the popup trigger, show the
   * popup menu.
   */
  private void handleEvent(MouseEvent e) {
    if (e.isPopupTrigger()) theMenu.show(e.getComponent(), e.getX(), e.getY());
  }
}
