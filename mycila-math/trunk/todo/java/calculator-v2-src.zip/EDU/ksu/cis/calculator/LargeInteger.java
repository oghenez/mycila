/*
 * EDU.ksu.cis.calculator.LargeInteger.java    3/20/01
 *
 * Copyright (c) 2001 Rod Howell, All Rights Reserved.
 */

package EDU.ksu.cis.calculator;

/**
 * A class which implements aribitrary-precision integer arithmetic.
 * <tt>LargeIntegers</tt> are stored in any radix within the range
 * 2-36, and radix conversions are done only when necessary; i.e.,
 * computations involving <tt>LargeInteger</tt>s of the same radix are
 * done within that radix.  Thus, if inputs and outputs are all to be
 * in decimal, all of the computations are done in decimal, thereby
 * saving expensive radix conversions.
 *
 * @author Rod Howell
 *         (<a href="mailto:howell@cis.ksu.edu">howell@cis.ksu.edu</a>)
 */
public final class LargeInteger implements Comparable {

  /**
   * The radix positions of the number.
   * The low-order byte is <tt>digits[offset]</tt>, and the high-order byte is
   * <tt>digits[offset + length - 1]</tt>.
   */
  private byte[] digits;

  /**
   * The index of the low-order byte of the number.
   */
  private int offset;

  /**
   * The number of bytes comprising the number.
   */
  private int length;

  /**
   * <tt>true</tt> if the number is negative.
   */
  private boolean negative;

  /**
   * The base to use when converting to a string.
   * 1 &lt; <tt>displayBase</tt> &lt; 37
   */
  private int displayBase;

  /**
   * The base in which the number is stored.  This value is the largest
   * power of <tt>displayBase</tt> less than 257.
   * 16 &lt; <tt>base</tt> &lt; 257
   */
  private int base;

  /**
   * The number of characters stored in one byte.
   * <tt>displayBase<sup>pack</sup> = base</tt>
   */
  private int pack;  

  /** The modulus for all of the FFT calculations.
   *  This is a 47-bit prime, 65550 * 2<sup>30</sup> + 1.
   */
  private static final long mod = 70383776563201L;

  /** Element i is a principal 2**i-th root of unity in the FFT field.
   */
  private static final long[] roots = new long[] {
    1L, 70383776563200L, 53584494145874L, 16491100154340L, 8251729855569L, 
    54141260506933L, 30827116249773L, 11841623934447L, 38938666398922L, 
    40119572768059L, 13382088273171L, 7259789800794L, 245247012133L, 
    48959122674900L, 2057783853341L, 24137967250171L, 17560868529348L, 
    54236099443817L, 31613430409055L, 28568927026433L, 11496597192615L, 
    33252378055270L, 23600998947234L, 22435795378610L, 52431065818252L, 
    30551680809588L, 26713297315242L, 22918355618248L, 15869278321465L, 
    7423219505696L, 31696988370702L};

  /** Element i is the multiplicative inverse of roots[i] in the FFT field.
   */
  private static final long[] rootsInv = new long[] {
    1L, 70383776563200L, 16799282417327L, 61472623878972L, 39229782493121L, 
    50936372324210L, 9362651625339L, 10452472889196L, 9025625771819L, 
    31859598355635L, 39040032295658L, 65913589151130L, 24822682898295L, 
    23045662539716L, 59786918773100L, 39400950333183L, 42896716809001L, 
    4828709384135L, 15241522851548L, 25994160944760L, 41535456258163L, 
    41075902423707L, 19684530485833L, 32566673512488L, 48139603138128L, 
    55660679838838L, 416502740110L, 62354506855284L, 16247553611790L, 
    70223437700930L, 32091152699528L};

  /** Element i is the multiplicative inverse of 2**i in the FFT field.
   */
  private static final long[] lengthInv = new long[] {
    1L, 35191888281601L, 52787832422401L, 61585804492801L, 65984790528001L, 
    68184283545601L, 69284030054401L, 69833903308801L, 70108839936001L, 
    70246308249601L, 70315042406401L, 70349409484801L, 70366593024001L, 
    70375184793601L, 70379480678401L, 70381628620801L, 70382702592001L, 
    70383239577601L, 70383508070401L, 70383642316801L, 70383709440001L, 
    70383743001601L, 70383759782401L, 70383768172801L, 70383772368001L, 
    70383774465601L, 70383775514401L, 70383776038801L, 70383776301001L, 
    70383776432101L, 70383776497651L};

  /**
   * Constructs a new LargeInteger in base 10 from the given String.
   * @throws NumberFormatException if <tt>s</tt> does not encode a 
   *                               decimal integer.
   */
  public LargeInteger(String s) throws NumberFormatException {
    this(s, 10);
  }

  /**
   * Constructs a new LargeInteger in the given base from the given String.
   * @throws NumberFormatException if <tt>s</tt> does not encode an
   *                               integer in the given base, or if the
   *                               given base is less than 2 or greater than
   *                               36.
   */
  public LargeInteger(String s, int b) throws NumberFormatException {
    if (b < 2 || b > 36) throw new NumberFormatException();
    displayBase = b;
    for (int t = b; t <= 256; base = t, pack++, t *= b);
    if (s.charAt(0) == '-') {
      negative = true;
      s = s.substring(1);
    }
    digits = new byte[(s.length() + pack - 1) / pack];
    int i, j;
    for (i = 0, j = s.length() - pack; j >= 0; 
	 digits[i++] = 
	   (byte) Integer.parseInt(s.substring(j, j + pack), displayBase), 
	   j = j - pack);
    if (i < digits.length) 
      digits[i] = (byte) Integer.parseInt(s.substring(0, j + pack), 
					  displayBase);
    length = getEnd(digits);
    if (length == 0) negative = false;
  }

  /**
   * Constructs a new LargeInteger directly from the given parameters.
   * The array is not copied, and no error-checking is done.  If 
   * <tt>negative</tt> is true and the value encoded is zero, it is
   * made nonnegative.
   */
  private LargeInteger(byte[] digits, int offset, int length, 
		       boolean negative, int base, 
		       int displayBase, int pack) {
    this.digits = digits;
    this.offset = offset;
    this.length = length;
    this.negative = negative && length > 0;
    this.base = base;
    this.displayBase = displayBase;
    this.pack = pack;
  }

  /**
   * Compares this LargeInteger with the given Object.
   * @return a negative integer, zero, or a positive integer as this
   * LargeInteger is less than, equal to, or greater than the specified
   * object.
   * @throws ClassCastException if the specified object is not a LargeInteger.
   */
  public int compareTo(Object o) throws ClassCastException {
    LargeInteger other = (LargeInteger) o;
    if (negative) return -negate().compareTo(other.negate());
    if (other.negative) return 1;
    if (base != other.base) other = other.toBase(displayBase);
    if (length > other.length) return 1;
    if (length < other.length) return -1;
    int i, j;
    for (i = offset + length - 1, j = other.offset + other.length - 1; 
	 i >= offset && digits[i] == other.digits[j]; i--, j--);
    if (i < offset) return 0;
    if ((((int) digits[i]) & 0xff) > (((int) other.digits[j]) & 0xff)) 
      return 1;
    return -1;
  }

  /**
   * Returns the sum of this LargeInteger and the given LargeInteger.
   */
  public LargeInteger add(LargeInteger other) {
    if (base != other.base) other = other.toBase(displayBase);
    if (negative) return negate().subtract(other).negate();
    if (other.negative) return subtract(other.negate());
    if (length < other.length) return other.add(this);
    if (length == 0x7fffffff) throw new OutOfMemoryError();
    byte[] sum = new byte[length + 1];
    byte carry = 0;
    int i = offset;
    int j = other.offset;
    int k = 0;
    for ( ; k < other.length; i++, j++, k++) 
      carry = addBytes(digits[i], other.digits[j], carry, base, sum, k);
    for ( ; k < length; i++, k++)
      carry = addBytes(digits[i], (byte) 0, carry, base, sum, k);
    if (carry > 0) {
      sum[length] = carry;
      return new LargeInteger(sum, 0, sum.length, false, base, displayBase,
			      pack);
    }
    return new LargeInteger(sum, 0, length, false, base, displayBase, pack);
  }

  /**
   * Places <tt>(a + b + c) mod m</tt> in <tt>sum[i]</tt>.
   * Both <tt>a</tt> and <tt>b</tt> must be less than <tt>m</tt>, and
   * <tt>c</tt> must be either 0 or 1.  No error checking is performed.
   * @return <tt>(a + b + c) / m</tt>.
   */
  private static byte addBytes(byte a, byte b, byte c, int m, byte[] sum,
			       int i) {
    int result = ((int) a & 0xff) + ((int) b & 0xff) + c;
    if (result >= m) {
      sum[i] = (byte) (result - m);
      return 1;
      }
    else {
      sum[i] = (byte) result;
      return 0;
    }
  }

  /** 
   * Returns the difference of this LargeInteger and the given LargeInteger.
   */
  public LargeInteger subtract(LargeInteger other) {
    if (base != other.base) other = other.toBase(displayBase);
    if (negative) return negate().add(other).negate();
    if (other.negative) return add(other.negate());
    int comp = compareTo(other);
    if (comp == 0) return new LargeInteger("0", displayBase);
    if (comp < 0) return other.subtract(this).negate();
    byte[] diff = new byte[length];
    byte borrow = 0;
    int i = offset;
    int j = other.offset;
    int k = 0;
    for ( ; k < other.length; i++, j++, k++)
      borrow = subtractBytes(digits[i], other.digits[j], borrow, base, diff, 
			     k);
    for ( ; k < length; i++, k++)
      borrow = subtractBytes(digits[i], (byte) 0, borrow, base, diff, k);
    return new LargeInteger(diff, 0, getEnd(diff), false, base, displayBase,
			    pack);
  }

  /**
   * Places <tt>(a - b - c) mod m</tt> in <tt>diff[i]</tt>.
   * Both <tt>a</tt> and <tt>b</tt> must be less than <tt>m</tt>, and
   * <tt>c</tt> must be either 0 or 1.  No error checking is performed.
   * @return <tt>-((a - b - c) / m)</tt>.
   */
  private static byte subtractBytes(byte a, byte b, byte c, int m, byte[] diff,
				    int i) {
    int result = ((int) a & 0xff) - ((int) b & 0xff) - c;
    if (result < 0) {
      diff[i] = (byte) (result + m);
      return 1;
    }
    else {
      diff[i] = (byte) result;
      return 0;
    }
  }

  /**
   * Returns the LargeInteger obtained by changing the sign of this
   * LargeInteger.
   */
  public LargeInteger negate() {
    return new LargeInteger(digits, offset, length, !negative, base, 
			    displayBase, pack);
  }

  /**
   * Returns the product of this LargeInteger and the given LargeInteger.
   */
  public LargeInteger multiply(LargeInteger other) {
    if (base != other.base) other = other.toBase(displayBase);
    if (length >= 0x40000000 || other.length >= 0x40000000)
      throw new OutOfMemoryError();
    int len = length + other.length;
    if (len > 0x40000000) throw new OutOfMemoryError();

    // We must find the smallest power of 2 no smaller than <tt>len</tt>.
    int n = 1;
    int lgn = 0;
    while (n < len) {
      n = n << 1;
      lgn++;
    }

    // The FFT computation requires the bytes of the number to be permuted
    // in bit-reverse order.
    BitReverseCounter counter = new BitReverseCounter(n >>> 1);

    long[] aPermute = new long[n];
    long[] bPermute = new long[n];

    for (int i = offset; i < offset + length; i++) {
      aPermute[counter.next()] = ((long) digits[i]) & 0xffL;
    }
    counter.reset();
    for (int i = other.offset; i < other.offset + other.length; i++) {
      bPermute[counter.next()] = ((long) other.digits[i]) & 0xffL;
    }

    fft(aPermute, roots);
    fft(bPermute, roots);

    // The product of two FFTs is computed by pointwise multiplication.
    for (int i = 0; i < n; i++) {
      aPermute[i] = modmult(aPermute[i], bPermute[i]);
    }

    // We now permute the FFT and compute the inverse FFT.
    counter.reset();
    for (int i = 0; i < n; i++) {
      bPermute[counter.next()] = aPermute[i];
    }
    fft(bPermute, rootsInv);
    for (int i = 0; i < n; i++) {
      bPermute[i] = modmult(bPermute[i], lengthInv[lgn]);
    }

    // Finally, separate out the bytes of the result.
    long accum = 0L;
    byte[] result = new byte[len];
    for (int i = 0; i < len; i++) {
      accum += bPermute[i];
      result[i] = (byte) (accum % base);
      accum = accum / base;
    }
    return new LargeInteger(result, 0, getEnd(result), 
			    negative ^ other.negative, base, displayBase,
			    pack);
  }

  /** This method may be used to compute an FFT or an inverse FFT.
   *  It uses modmult to compute products in the underlying ring.
   *  The first parameter must contain n elements, where n is a power
   *  of two.  
   *  <p>
   *  Computing an FFT:
   *  <p>
   *  The first parameter gives the coefficients of a polynomial
   *  in bit-reverse order.  The second parameter must be an array 
   *  of at least <tt>lg n</tt> elements such that element i is a 
   *  principal 2**i-th root of unity.  The second parameter will be
   *  modified to contain the values of the polynomial at successive
   *  powers of the principal n-th root of unity.
   *  <p>
   *  Computing an inverse FFT:
   *  <p>
   *  The first parameter gives the values of the polynomial at successive
   *  powers of a principal n-th root of unity, given in bit-reverse order.
   *  The second parameter must contain the multiplicative inverses of the 
   *  roots used in the FFT computation.  The second parameter will be
   *  modified to contain values which, when multiplied by the inverse
   *  of n, are the coefficients of the polynomial from low-order term to
   *  high-order term.
   *  <p>
   *  The code is based on the algorithm ITERATIVE-FFT given on p. 794 of
   *  "Introduction to Algorithm", by Cormen, Leiserson, and Rivest
   *  (McGraw Hill, 1990).
   */
  private static void fft(long[] a, long[] ws) {
    int s = 1;
    for (int m = 1; m < a.length; m = m << 1) {
      long w = 1L;
      for (int j = 0; j < m; j++) {
	for (int k = j; k < a.length; k += (m << 1)) {
	  long t = modmult(w, a[k + m]);
	  long u = a[k];
	  long sum = u + t;
	  a[k] = sum >= mod ? sum - mod : sum;
	  long diff = u - t;
	  a[k + m] = diff < 0L ? diff + mod : diff;
	}
	w = modmult(w, ws[s]);
      }
      s++;
    }
  }

  /** Computes the product of its parameters mod 70383776563201.
   *  The parameters must each be nonnegative and contain at most
   *  47 significant bits.
   */
  private static long modmult(long a, long b) {
    long loa = a & 0xffffL;  // The low-order 16 bits.
    long lob = b & 0xffffL;  //
    long hia = (a & 0xffffffffffff0000L) >>> 16;  // The high-order 31 bits.
    long hib = (b & 0xffffffffffff0000L) >>> 16;  //
    long lo = loa * lob;  // 32 bits.
    long mid = loa * hib + lob * hia;  // 48 bits.
    lo += (mid << 16) & 0xffffffffL;   // 33 bits.
    long hi = hia * hib + (mid >>> 16) + (lo >>> 32); // 63 bits.
    lo = lo & 0xffffffffL;  // 32 bits.
    long result = hi % mod;  // 47 bits.
    result = ((result << 16) | (lo >>> 16)) % mod;  // 47 bits.
    result = ((result << 16) | (lo & 0xffffL)) % mod;
    return result;
  }

  /**
   * Returns the index following the last nonzero element in the given array.
   */
  private static int getEnd(byte[] a) {
    int i;
    for (i = a.length - 1; i >= 0 && a[i] == 0; i--);
    return ++i;
  }

  /**
   * Returns a 2-element array whose first element is <tt>this / other</tt> 
   * and whose second element is <tt>this % other</tt>.  Thus, if the two 
   * returned values are <tt>q</tt> and <tt>r</tt>, respectively, the following
   * hold:
   * <ul>
   * <li> <tt>q * other + r = this</tt>
   * <li> <tt>-other &lt; r &lt; other</tt>
   * <li> if <tt>this</tt> is nonnegative, then <tt>r</tt> is nonnegative
   * <li> if <tt>this</tt> is nonpositive, then <tt>r</tt> is nonpositive
   * </ul>
   * @throws ArithmeticException if <tt>other</tt> is 0.
   */
  public LargeInteger[] divide(LargeInteger other) throws ArithmeticException {
    if (base != other.base) other = other.toBase(displayBase);
    if (negative) {
      LargeInteger[] tmp = abs().divide(other);
      tmp[0] = tmp[0].negate();
      tmp[1] = tmp[1].negate();
      return tmp;
    }

    // precision is the number of bytes of accuracy needed in the 
    // reciprocal in order to obtain a result within 1 of the correct quotient.
    int precision = length - other.length + 1;
    LargeInteger[] result = new LargeInteger[2];
    if (precision <= 0) {
      result[0] = new LargeInteger("0", displayBase);
      result[1] = negative ^ other.negative ? negate() : this;
      return result;
    }
    LargeInteger absOther = other.abs();
    LargeInteger recip = absOther.getReciprocal(precision);
    result[0] = multiply(recip);
    result[0] = new LargeInteger(result[0].digits, 
				 result[0].offset + length + 1, 
				 result[0].length - length - 1,
				 result[0].negative, 
				 base, displayBase, pack);

    // At this point, the result may be off by 1, so we must check it.
    LargeInteger prod = absOther.multiply(result[0]);
    result[1] = subtract(prod);
    if (result[1].compareTo(absOther) >= 0) {
      result[1] = result[1].subtract(absOther);
      result[0] = result[0].add(new LargeInteger("1", displayBase));
    }
    else if (result[1].negative) {
      result[1] = result[1].add(absOther);
      result[0] = result[0].subtract(new LargeInteger("1", displayBase));
    }
    if (other.negative) result[0] = result[0].negate();
    return result;
  }

  public LargeInteger abs() {
    return new LargeInteger(digits, offset, length, false, base, displayBase,
			    pack);
  }
    
  /**
   * Returns an approximation of this LargeInteger's reciprocal, scaled
   * to an integer.
   * @return <tt>(1/this) * base<sup>precision-length</sup> + u</tt>,
   *         where <tt>|u|</tt> is no more than <tt>base</tt>.
   * @throws ArithmeticException if this LargeInteger is 0.
   */
  private LargeInteger getReciprocal(int precision) {
    if (precision >= 0x40000000) throw new OutOfMemoryError();
    if (precision <= 2) {
      // Compute an approximation using the first 3 bytes.
      long baseSq = base * base;
      long val = baseSq * baseSq * base / 
	(baseSq * getDigit(0) + base * getDigit(1) + getDigit(2));
      byte[] u = new byte[4];
      for (int i = 0; i < 4; i++) {
	u[i] = (byte) (val % base);
	val = val / base;
      }
      int start = 2 - precision;
      int len = 2 + precision;
      for ( ; len >= 0 && u[start + len - 1] == 0 ; len--);
      return new LargeInteger(u, start, len, false, base,
			      displayBase, pack);
    }
    else {
      LargeInteger z = getReciprocal(precision/2 + 1);
      LargeInteger t = trunc(precision + 2);
      LargeInteger prod = t.multiply(z).multiply(z);
      int diff = 2*(precision/2 + 2);
      LargeInteger prodTrunc = 
	new LargeInteger(prod.digits, prod.offset+diff, prod.length-diff, 
			 false, base, displayBase, pack);
      LargeInteger zPad = z.pad(precision - precision/2 - 1);
      return zPad.add(zPad.subtract(prodTrunc));
    }
  }

  /**
   * Returns the p most significant digits of this LargeInteger.  If
   * there are fewer than p digits, trailing 0s are added.
   */
  private LargeInteger trunc(int p) {
    return p <= length ?
      new LargeInteger(digits, offset + length - p, p, false, base,
		       displayBase, pack) :
      pad(p - length);
  }

  /**
   * Returns this LargeInteger padded with p trailing 0s.
   */
  private LargeInteger pad(int p) {
    byte[] bytes = new byte[length + p];
    System.arraycopy(digits, offset, bytes, p, length);
    return new LargeInteger(bytes, 0, length + p, false, base, 
			    displayBase, pack);
  }

  /**
   * Returns the i-th most significant digit.
   */
  private int getDigit(int i) {
    return i >= length ? 0 :
      ((int) digits[offset + length - i - 1]) & 0xff;
  }

  /**
   * Converts this LargeInteger to the given base.
   * @throws NumberFormatException  If b &lt; 2 or b &gt; 36.
   */
  public LargeInteger toBase(int b) throws NumberFormatException {
    if (b < 2 || b > 36) throw new NumberFormatException();
    int newBase = b;
    int newPack = 0;
    for (int t = b; t <= 256; newBase = t, newPack++, t *= b);
    if (base == newBase) 
      return new LargeInteger(digits, offset, length,
			      negative, newBase, b, newPack);

    // divisors will be used in a divide-and-conquer algorithm to
    // break the number into two parts, which may be converted individually
    // and concatenated.
    // For additional efficiency, the reciprocals and FFTs of the divisors
    // could also be precomputed.
    LargeInteger[] divisors = new LargeInteger[31];
    int i = 0;
    divisors[0] = new LargeInteger(Integer.toString(newBase, displayBase), 
				   displayBase);
    for ( ; compareTo(divisors[i]) >= 0; i++)
      divisors[i+1] = divisors[i].multiply(divisors[i]);
    return toBase(newBase, b, newPack, divisors, i-1);
  }

  /**
   * Returns this LargeInteger converted to base b using precomputed
   * information.
   * @param  b  The base in which the new LargeInteger will be stored.
   * @param  d  The base used to convert this LargeInteger to a String.
   * @param  p  The number of digits to be packed into one byte.
   * @param  divisors An array in which element i is b raised to the
   *                  2<sup>i</sup> power, stored in this LargeInteger's base.
   */
  private LargeInteger toBase(int b, int d, int p,
			      LargeInteger[] divisors,
			      int i) {
    if (i < 0) {
      byte[] bytes = new byte[1];
      bytes[0] = digits[offset];
      if (length > 1) bytes[0] += 
			(byte) ((((int) digits[offset+1]) & 0xff) * base);
      return new LargeInteger(bytes, 0, getEnd(bytes), negative, b, d, p);
    }
    LargeInteger[] div = divide(divisors[i]);
    LargeInteger top = div[0].toBase(b, d, p, divisors, i-1);
    LargeInteger bot = div[1].toBase(b, d, p, divisors, i-1);
    int off = 1 << i;
    byte[] bytes = new byte[top.length + off];
    System.arraycopy(top.digits, top.offset, bytes, off, top.length);
    System.arraycopy(bot.digits, bot.offset, bytes, 0, bot.length);
    return new LargeInteger(bytes, 0, getEnd(bytes), negative, b, d, p);
  }

  /**
   * Returns this LargeInteger raised to the power <tt>other</tt>.
   * Note that it is very easy to generate an OutOfMemoryError.
   * @throws  ArithmeticException  If <tt>other</tt> is negative.
   */
  public LargeInteger pow(LargeInteger other) throws ArithmeticException {
    if (other.negative) throw new ArithmeticException();
    if (base != other.base) other = other.toBase(displayBase);
    LargeInteger x = this;
    LargeInteger z = new LargeInteger("1", displayBase);
    for (int i = other.offset; i < other.offset + other.length; i++) {
      z = z.multiply(x.pow(((int) other.digits[i]) & 0xff));
      x = x.pow(base);
    }
    return z;
  }

  /**
   * Returns this LargeInteger raised to the power <tt>exp</tt>.
   * @throws  ArithmeticException  If <tt>exp</tt> is negative.
   */
  public LargeInteger pow(int exp) throws ArithmeticException {
    if (exp < 0) throw new ArithmeticException();
    if (exp == 0) return new LargeInteger("1", displayBase);
    LargeInteger z = pow(exp/2);
    z = z.multiply(z);
    if ((exp & 1) == 1) return multiply(z);
    else return z;
  }

  /**
   * Returns <tt>a</tt> raised to the power <tt>exp</tt>.
   * @throws  ArithmeticException  If <tt>exp</tt> is negative.
   */
  public static LargeInteger pow(int a, LargeInteger exp) 
    throws ArithmeticException {
    if (exp.negative) throw new ArithmeticException();
    LargeInteger z = new LargeInteger("1", exp.displayBase);
    for (int i = exp.offset + exp.length - 1; i >= exp.offset; i--) {
      z = z.pow(exp.base).multiply(pow(a, ((int) exp.digits[i]) & 0xff, 
				       exp.displayBase));
    }
    return z;
  }

  /**
   * Returns the LargeInteger <tt>a<sup>exp</sup></tt>, stored in base
   * <tt>db</tt>.
   * @throws ArithmeticException   If <tt>exp</tt> is negative.
   * @throws NumberFormatException If <tt>db &lt; 2</tt> or <tt>db &gt; 36</tt>
   */
  public static LargeInteger pow(int a, int exp, int db) 
    throws ArithmeticException {
    if (exp < 0) throw new ArithmeticException();
    if (exp == 0) return new LargeInteger("1", db);
    LargeInteger z = pow(a, exp/2, db);
    z = z.multiply(z);
    if ((exp & 1) == 1) return z.multiply(a);
    else return z;
  }

  /**
   * Returns the product of this LargeInteger and <tt>a</tt>.
   */
  public LargeInteger multiply(int a) {
    byte[] bytes = new byte[length + 8];
    int absa = Math.abs(a);
    long accum = 0;
    int j = 0;
    for (int i = offset; i < offset + length; i++, j++) {
      accum += (((long) digits[i]) & 0xffL) * absa;
      bytes[j] = (byte) (accum % base);
      accum = accum / base;
    }
    for ( ; accum > 0; accum = accum / base, j++) {
      bytes[j] = (byte) (accum % base);
    }
    return new LargeInteger(bytes, 0, getEnd(bytes), negative ^ (a < 0), base,
			    displayBase, pack);
  }

  /**
   * Returns an array whose first element is <tt>this / a</tt> and whose
   * second element is <tt>this % a</tt>.
   * @throws ArithmeticException  If <tt>a = 0</tt>.
   */
  public LargeInteger[] divide(int a) {
    byte[] bytes = new byte[length];
    int absa = Math.abs(a);
    long accum = 0;
    int j = bytes.length - 1;
    for (int i = offset + length - 1; i >= offset; i--) {
      accum += ((long) digits[i]) & 0xffL;
      bytes[j] = (byte) (accum / absa);
      accum = (accum % absa) * base;
    }
    LargeInteger[] result = new LargeInteger[2];
    result[0] = new LargeInteger(bytes, 0, getEnd(bytes), negative ^ (a < 0),
				 base, displayBase, pack);
    if (negative) accum = -accum;
    result[1] = new LargeInteger(Long.toString(accum, displayBase), 
				 displayBase);
    return result;
  }

  /**
   * Returns the String representation of this LargeInteger.  The format
   * is the same as that of {@link java.lang.Integer#toString(int)}, where the
   * given <tt>int</tt> is the radix associated with this LargeInteger.
   */
  public String toString() {
    String zeros = "00000000";
    StringBuffer sb = new StringBuffer(length * pack + 2);
    if (negative) sb.append("-");
    if (length == 0) sb.append("0");
    else sb.append(Integer.toString(((int) digits[offset + length - 1]) & 0xff,
				    displayBase));
    for (int i = offset + length - 2; i >= offset; i--) {
      String next = Integer.toString(((int) digits[i]) & 0xff, displayBase);
      sb.append(zeros.substring(0, pack - next.length())).append(next);
    }
    return sb.toString();
  }

  public int getBase() {
    return displayBase;
  }
}

/** This class implements a counter in which the bits are reversed.
 *  It is constructed with a mask, which should contain a single
 *  1 bit.  This bit marks the position at which the value should be
 *  "incremented", with carries propogating to the right.  For example,
 *  <pre>
 *  new BitReverseCounter(4);
 *  </pre>
 *  constructs a counter which produces the sequence (shown in binary):
 *  <pre>
 *  000
 *  100
 *  010
 *  110
 *  001
 *  101
 *  011
 *  111
 *  </pre>
 *  The next value is returned in constant amortized time.
 */
class BitReverseCounter {

  /** The mask for this counter.
   */
  private int mask;

  /** The next value to be returned.
   */
  private int count;

  /** Constructs a new BitReverseCounter with the given mask.
   */
  public BitReverseCounter(int m) {
    mask = m;
  }

  /** Returns the next value.
   */
  public int next() {
    int ret = count;
    count = count ^ mask;
    int m = mask;
    while (m != 0 && (count & m) == 0) {
      m = m >>> 1;
      count = count ^ m;
    }
    return ret;
  }

  /** Resets the counter to 0.
   */
  public void reset() {
    count = 0;
  }
}
