/*
 * EDU.ksu.cis.calculator.javamodel.ClearStack.java    3/20/01
 *
 * Copyright (c) 2001 Rod Howell, All Rights Reserved.
 */

package EDU.ksu.cis.calculator.javamodel;

import java.math.BigInteger;
import EDU.ksu.cis.calculator.Operation;

/**
 * The clear stack operation.  Objects of this class are used to
 * encapsulate a clear stack request.
 *
 * @author Rod Howell
 *         (<a href="mailto:howell@cis.ksu.edu">howell@cis.ksu.edu</a>)
 */
public class ClearStack implements Operation {

  /**
   * Returns 0.
   */
  public int numOperands() {
    return 0;
  }
}
