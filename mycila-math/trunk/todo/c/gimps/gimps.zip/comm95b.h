/* Common definitions in Prime95, Saver95, and NTPrime */

int isWindows95 ();
int isWindows2000 ();
int isWindowsVista ();

