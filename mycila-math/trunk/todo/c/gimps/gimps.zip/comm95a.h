/* Common definitions in Prime95, Saver95, and NTPrime */

