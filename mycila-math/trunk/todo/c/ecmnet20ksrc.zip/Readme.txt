Running the client
==================

To start the client, edit the ecmclient.cfg file in your client directory
to suit your setup and then run ecmclient.exe.  There are descriptions of
all the parameters in the ecmclient.cfg file.  The client will not run
unless you configure your email address.  The other settings will cause
your client to attempt to connect to the server every 12 hours.

To install the NT service client, use "ecmclientsvc.exe -install".  Be sure
to set the 'curdir' variable in ecmclientsvc.cfg or else it will stop
immediately after starting.

Running the server
==================

Use of the server is not required or recommended for the average user.

If you want to have control over which composites are being factored, then
use can use the server.

To start the server, edit the ecmserver.cfg file in your server directory.
At the very least, you must configure an email address.  Create an
ecmserver.ini file in your server directory (see the ecmserver.ini.sample
file provided for formatting, as well as my web page -- link is below).
Make sure at least one number is labelled "A" (active).  Run ecmserver.exe.

The client and server are both relatively new.  However, I have been using
them for a couple of weeks as I developed them, and they work in my setup.
Please let me know if you experience any trouble with either the client or
server.  Check the following page for updates.

More information is available at http://www.interlog.com/~tcharron/ecm.html.

-- Tim

