// This code based on BLAT code (see http://www.interlog.com/~tcharron/blat.html)
// Copyright Tim Charron 1998 (tcharron@interlog.com)

// Nov 8 1998 Fixed compiling under UNIX
// Apr 15 1999 Moved inet_address() from here to common.cpp

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include <sys/types.h>

#ifdef WIN32
	#include <conio.h>
	#include <dos.h>
   #include <winsock.h>
#endif

#ifdef UNIX
   #include <unistd.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <arpa/inet.h>
	#include <netdb.h>
   #include <fcntl.h>
#endif

#include "defs.h"
#include "mail.h"

extern unsigned int inet_address(const char *host); // From common.cpp

char * inittext(int out, char * subject, char * destid, char * smtp, int port, char * fromid) {
	char my_hostname[255];
	time_t time_of_day;
	char dttext[255];
	char * mailmessagetext;

	gethostname(my_hostname,255);

	if ( out == 1 ) {
		printf("my_hostname: %s\n",my_hostname);
		printf("Mail server:port is %s:%d\n",smtp,port);
		printf("Mail id is %s\n",fromid);
		printf("Destination is %s\n",destid);
	}

	time_of_day = time( NULL );
	strftime( dttext, 80, "%a, %d %b %Y %T", localtime( &time_of_day ) );

	mailmessagetext = new char[400+strlen(my_hostname)+strlen(fromid)+
										strlen(smtp)+strlen(destid)+strlen(dttext)];

	sprintf(mailmessagetext,"Subject: %s\r\nFrom: %s", subject, fromid);
	if (strchr(fromid, '@') == NULL) {
		strcat(mailmessagetext,"@");
		strcat(mailmessagetext,smtp);
	}
	strcat(mailmessagetext,"\r\nTo: ");
	strcat(mailmessagetext,destid);
	strcat(mailmessagetext,"\r\nDate: ");
	strcat(mailmessagetext,dttext);
	strcat(mailmessagetext,"\r\n\r\n");

	return (mailmessagetext);
}

int open_smtp_server(int address,int port)
{
	static int on=1;
	SOCKET sock=INVALID_SOCKET;
	struct sockaddr_in sin;

	memset((void *) &sin, 0, sizeof(sin));

	sin.sin_family    = AF_INET;
	sin.sin_addr.s_addr  = address;
	sin.sin_port      = htons(port);

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if ( sock == INVALID_SOCKET ) {
		printf("SMTP socket\n");
		return (-1);
	}

	if ( setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0 ) {
		closesocket(sock);
		printf("SMTP setsockopt\n");
		return (-1);
	}

	if ( connect(sock, (struct sockaddr *) &sin, sizeof(sin)) != 0 ) {
		closesocket(sock);
		printf("SMTP connect\n");
		return (-1);
	}

	return (sock);
}

int get_smtp_line( SOCKET sock )
{
	char ch = '.';
	char in_data [255];
	char * index;

	index = in_data;

	while ( ch != '\n' ) {
		if ( recv(sock, &ch, 1,0) != 1 ) {
			printf("recv error\n");
			return (-1);
		} else {
			*index = ch;
			index++;
		}
	}

	/* this is to support multi-line responses, common with */
	/* servers that speak ESMTP */
	/* I know, I know, it's a hack 8^) */
	if ( in_data[3] == '-' ) return ( get_smtp_line(sock) );
	else return (atoi(in_data));
}

int put_smtp_line( SOCKET sock, char * line, unsigned int nchars )
{
	if ( send(sock, (char const *) line, nchars,0) != nchars ) {
		printf("send error\n");
		return (-1);
	}
	return (0);
}

void smtp_error (SOCKET sock,char * message)
{
	printf("%s\n",message);
	put_smtp_line (sock, "QUIT\r\n", 6);
	closesocket(sock);
}

// 'destination' is the address the message is to be sent to
// 'message' is a pointer to a null-terminated 'string' containing the
// entire text of the message.
int prepare_smtp_message(char * MailAddress, char * destination, SOCKET sock)
{
	char out_data[255];
	char str[1024];
	char my_hostname[1024];
	char *ptr;
	int len, startLen;

	if ( get_smtp_line(sock) != 220 ) {
		smtp_error (sock,"SMTP server error");
		return (-1);
	}

	gethostname(my_hostname,1024);

	sprintf( out_data, "HELO %s\r\n", my_hostname );
	if ( 0 != put_smtp_line( sock, out_data, strlen (out_data) ) ) {
		smtp_error(sock,"SMTP server error");
		return (-1);
	}

	if ( get_smtp_line(sock) != 250 ) {
		smtp_error (sock,"SMTP server error");
		return (-1);
	}

	sprintf (out_data, "MAIL From:<%s>\r\n", MailAddress);
	if ( 0 != put_smtp_line( sock, out_data, strlen (out_data) ) ) {
		smtp_error(sock,"SMTP server error");
		return (-1);
	}

	if ( get_smtp_line(sock) != 250 ) {
		smtp_error (sock,"The mail server doesn't like the sender name,\nhave you set your mail address correctly?\n");
		return (-1);
	}

	// do a series of RCPT lines for each name in address line
	for ( ptr = destination; *ptr; ptr += len + 1 ) {
		// if there's only one token left, then len will = startLen,
		// and we'll iterate once only
		startLen = strlen (ptr);
		if ( (len = strcspn (ptr, " ,\n\t\r")) != startLen ) {
			ptr[len] = '\0';								 // replace delim with NULL char
			while ( strchr (" ,\n\t\r", ptr[len+1]) )	  // eat white space
				ptr[len++] = '\0';
		}

		sprintf (out_data, "RCPT To: <%s>\r\n", ptr);
		if ( 0 != put_smtp_line( sock, out_data, strlen (out_data) ) ) {
			smtp_error(sock,"SMTP server error");
			return (-1);
		}

		if ( get_smtp_line(sock) != 250 ) {
			sprintf (str, "The mail server doesn't like the name %s.\nHave you set the 'To' field correctly\n",ptr);
			smtp_error (sock,str);
			return (-1);
		}

		if ( len == startLen )							 // last token, we're done
			break;
	}

	sprintf (out_data, "DATA\r\n");
	if ( 0 != put_smtp_line( sock, out_data, strlen (out_data) ) ) {
		smtp_error(sock,"SMTP server error");
		return (-1);
	}

	if ( get_smtp_line(sock) != 354 ) {
		smtp_error (sock,"Mail server error accepting message data");
		return (-1);
	}

	return (0);
}

int transform_and_send_edit_data( SOCKET sock, char * editptr )
{
	char *index;
	char *header_end;
	char previous_char = 'x';
	unsigned int send_len;
	BOOL done = 0;

	send_len = strlen(editptr);
	index = editptr;

	header_end = strstr (editptr, "\r\n\r\n");

	while ( !done ) {
		// room for extra char for double dot on end case
		while ( (unsigned int) (index - editptr) < send_len ) {
			switch ( *index ) {
			case '.':
				if ( previous_char == '\n' )
					/* send _two_ dots... */
					if ( send(sock, (char const *) index, 1,0) != 1 ) {return (-1);}
				if ( send(sock, (char const *) index, 1,0) != 1 ) {return (-1);}
				break;
			case '\r':
				// watch for soft-breaks in the header, and ignore them
				if ( index < header_end && (strncmp (index, "\r\r\n", 3) == 0) )
					index += 2;
				else
					if ( previous_char != '\r' )
					if ( send(sock,(char const *) index, 1,0) != 1 ) {return (-1);}
					// soft line-break (see EM_FMTLINES), skip extra CR */
				break;
			case '\n':										 // all \n's should be preceeded by \r's...
				if ( previous_char != '\r' ) {
					if ( send(sock,  "\r\n"      , 2,0) != 2 ) {return (-1);}
				} else {
					if ( send(sock,(char const *) index, 1,0) != 1 ) {return (-1);}
				}
				break;
			default:
				if ( send(sock, (char const *) index, 1,0) != 1 ) {return (-1);}
			}
			previous_char = *index;
			index++;
		}
		if ( (unsigned int) (index - editptr) == send_len ) done = 1;
	}

	// this handles the case where the user doesn't end the last
	// line with a <return>

	if ( editptr[send_len-1] != '\n' ) {
		if ( send(sock, "\r\n.\r\n", 5,0) != 5 ) {return (-1);}
	} else {
		if ( send(sock, ".\r\n", 3,0) != 3 ) {return (-1);}
	}

	return (0);
}

int send_smtp_edit_data (char * message, SOCKET sock)
{
	transform_and_send_edit_data( sock, message );

	if ( get_smtp_line(sock) != 250 ) {
		smtp_error (sock,"Message not accepted by server");
		return (-1);
	}
	return (0);
}

int finish_smtp_message( SOCKET sock )
{
   int ret;

   ret = put_smtp_line( sock, "QUIT\r\n", 6 );
   // wait for a 221 message from the server
   get_smtp_line( sock );
   return(ret);
}

int sendmessage(char * msg, char * subject, char * destid, char * smtp, int port, char * fromid) {
	// Get the SMTP server name, destination mailid from the INI file...
	int address;
	SOCKET sock;
	char * mailmessagetext;

	// Set up the headers...
	mailmessagetext = inittext(0, subject, destid, smtp, port, fromid);
	mailmessagetext = (char *) realloc(mailmessagetext, strlen(mailmessagetext)+1
									  +strlen(msg)+1);
	strcat(mailmessagetext, msg);

	// Connect to the server...
	address = inet_address((const char *) smtp);
	sock=open_smtp_server(address,port);
	if ( sock == -1 ) {
		printf("Unable to connect to smtp server\n");
		free(mailmessagetext);
		return (-1);
	} else {
		if ( prepare_smtp_message( fromid, destid, sock ) != -1 ) {
			if ( 0 == send_smtp_edit_data( mailmessagetext ,sock ) )
				finish_smtp_message(sock);
			closesocket(sock);
			free(mailmessagetext);
			return (0);
		} else {
			printf("Error in prepare_smtp_message\n");
			free(mailmessagetext);
			return (-1);
		}
	}
}

#if 0
char *inet_name(struct in_addr in)
{
	char *cp;
	static char line[50];
	struct hostent *hp;
	static char domain[MAXGETHOSTSTRUCT + 1];
	static int first = 1;

	if (first) {
		first = 0;
		cp=strchr(domain, '.');
      if (gethostname(domain, MAXGETHOSTSTRUCT) == 0 && (cp != NULL) )
			strcpy(domain, cp + 1);
		else
			domain[0] = 0;
	}

	cp = 0;

	if (in.s_addr != INADDR_ANY) {
		hp = gethostbyaddr((char *)&in, sizeof (in), AF_INET);
		if (hp) {
			cp=strchr(hp->h_name, '.');
			if ( (cp != NULL) && !strcmp(cp + 1, domain) )
				*cp = 0;

			cp = hp->h_name;
		}
	}

	if (cp)
		(void) strcpy(line, cp);
	else {
		in.s_addr = ntohl(in.s_addr);
		sprintf(line, "%u.%u.%u.%u",
			(unsigned char) ((in.s_addr >> 24) & 0xFF),
			(unsigned char) ((in.s_addr >> 16) & 0xFF),
			(unsigned char) ((in.s_addr >>  8) & 0xFF),
			(unsigned char) ((in.s_addr      ) & 0xFF));
	}

	return (line);
}
#endif
