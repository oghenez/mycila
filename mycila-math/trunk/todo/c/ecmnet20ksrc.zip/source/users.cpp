/*
  user.cpp -- a component of ecmserver

The most recent version of this source is available from http://www.interlog.com/~tcharron/ecm.html
Oct 24 1998 Fixed error in parsing where a "," was part of the first field.

*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <memory.h>
#include <string.h>

#include "users.h"

void switchusers(userdetail * user1, userdetail * user2);

user::user()
{
   number_of_users = 0;
   changes=0;
   oneuser = (userdetail *) malloc(sizeof(userdetail));
   usrname = NULL;
   changethreshold=1;
   sorttype=0; // no sorting
}

// Destructor.  Note that strings which were allocated are freed here as well.
user::~user()
{
   while ( number_of_users > 0 ) {
      free(oneuser[number_of_users-1].email);
      free(oneuser[number_of_users-1].firsttime);
      free(oneuser[number_of_users-1].lasttime);
      free(&oneuser[number_of_users-1]);
      number_of_users--;
   }
   delete usrname;
}

int user::LoadUsers(char * filename, int thresh) {
   FILE * fp;
   char * line;
   char * ptr1;
   char * ptr2;
   char * ptr3;
   char * ptr4;
   char * ptr5;
   char * ptr6;
   int row=0,ncurves=0, rowok=0;
   double work=0;
   int factors;
   double b1=0;

   usrname = new char[strlen(filename)+2];
   strcpy(usrname, filename);
   changethreshold=thresh;

   if ( (fp = fopen(filename,"rt")) == NULL ) {
//      printf("Can't open file:%s\n",filename);
      return (-1);
   }

   line = (char *) malloc( 10001 );
   if ( line == NULL ) {
      printf("malloc error!\n");
      fclose(fp);
      return (-1);
   }

   while ( fgets(line,10000,fp) != NULL ) {
      row++;
      rowok=0;
      if ( strlen(line) > 1 ) {
         if ( *(line+strlen(line)-1) == 0x0A )   *(line+strlen(line)-1)=0;
         if ( *(line+strlen(line)-1) == 0x0D )   *(line+strlen(line)-1)=0;

         ptr6 = strrchr((char const *) line, ',');
         if ( ptr6 != NULL) {
            // ptr6+1 == lasttime
            *ptr6=0;
            ptr5 = strrchr((char const *) line, ',');
            if ( ptr5 != NULL) {
               // ptr5+1 == firsttime
               *ptr5=0;
               ptr4=strrchr((char const *) line, ',');
               if ( ptr4 != NULL) {
                  // ptr4+1 == factors
                  *ptr4=0;
                  factors = atoi(ptr4+1);
                  ptr3=strrchr((char const *) line, ',');
                  if ( ptr3 != NULL) {
                     // ptr3+1 == work
                     *ptr3=0;
                     work = atol(ptr3+1);
                     ptr2=strrchr((char const *) line, ',');
                     if ( ptr2 != NULL) {
                        // ptr2+1 == b1
                        *ptr2=0;
                        b1 = atol(ptr2+1);
                        ptr1=strrchr((char const *) line, ',');
                        if ( ptr1 != NULL ) {
                           // ptr1+1 == ncurves
                           *ptr1=0;
                           ncurves=atoi(ptr1+1);
                           rowok=1;
                        }
                     }
                  }
               }
            }
         }
      }
      if (!rowok) {
         printf("Malformed information in %s at row #%d.\n",filename,row);
      } else {
         storeuser(line, ncurves, b1, work, factors, ptr5+1, ptr6+1);
      }
   }// end while

   free( line );

   fclose(fp);
   changes=0;                                    // Since StoreDetails() will increment it.
   return (0);
}

void user::sortme() {
   // Sort the user file based on work completed.
   // The list will already be more-or-less sorted, so use a simple bubble sort.
   // Note that each call to adduser will be causing 1 row to move 'up' the list, so scan backwards
   // This minimizes the number of passes through the list
   int ok=0;
   while (!ok) {
      ok=1;
      for (int i=number_of_users-2 ; i>=0 ; i--) {
         if (oneuser[i].work < oneuser[i+1].work) {
            switchusers(&oneuser[i], &oneuser[i+1]);
            ok=0;
         }
      } // for
   } // while
} // sortme()

void user::adduser(const char * email, int ncurves, double b1, double work, int factors, const char * curtime) {

   if ((usrname==NULL) || (strlen(usrname)==0)) return;
   for (int i=0; i<number_of_users ; i++) {
      if (strcmp(oneuser[i].email, email) == 0) {
         strcpy(oneuser[i].lasttime, curtime);
         oneuser[i].ncurves += ncurves;
         oneuser[i].b1      += b1/1000.;
         oneuser[i].work    += work/1000000.;
         oneuser[i].factors += factors;

         changes++;
         if (factors>0) changes += changethreshold;

         if (sorttype == 1) {
            for (int j=i+1 ; j<number_of_users ; j++)
               switchusers(&oneuser[j-1], &oneuser[j]);
         }
         if (sorttype == 2) sortme();

         WriteUsers_as_required();
         return;
      }
   }
   storeuser(email, ncurves, b1/1000., work/1000000., factors, curtime, curtime);
   WriteUsers_as_required();
}

void user::storeuser(const char * email, int ncurves, double b1, double work, int factors, const char * firsttime, const char * lasttime) {
   oneuser = (userdetail *) realloc(oneuser, sizeof(userdetail) * (number_of_users+1) );
   oneuser[number_of_users].email     = new char[strlen(email)+1];
   oneuser[number_of_users].firsttime = new char[30];
   oneuser[number_of_users].lasttime  = new char[30];

   strcpy(oneuser[number_of_users].email, email);
   oneuser[number_of_users].ncurves = ncurves;
   oneuser[number_of_users].b1      = b1;
   oneuser[number_of_users].work    = work;
   oneuser[number_of_users].factors = factors;
   strcpy(oneuser[number_of_users].firsttime, firsttime);
   strcpy(oneuser[number_of_users].lasttime,  lasttime);

   number_of_users++;
   changes++;
}

int user::WriteUsers() {
   FILE *fp;

   if ((usrname==NULL) || (strlen(usrname)==0)) return -1;

   if ( ( fp = fopen(usrname, "wt")) == NULL ) {
      printf("Can't open file %s for writing.\n", usrname);
      return (-1);
   }

   for ( int i=0 ; i<number_of_users ; i++ ) {
      fprintf(fp, "%s,%d,%.0lf,%.0lf,%d,%s,%s\n",
                 oneuser[i].email,
                 oneuser[i].ncurves,
                 oneuser[i].b1,
                 oneuser[i].work,
                 oneuser[i].factors,
                 oneuser[i].firsttime,
                 oneuser[i].lasttime);
   }
   fclose(fp);
   changes=0;  // # of unsaved changes in memory is now 0.
   return (0);
}

void user::WriteUsers_as_required() {
   if ( changes >= changethreshold )  WriteUsers();
   return;
}

void user::printuser(FILE * fp, char * email) {

   if ((usrname==NULL) || (strlen(usrname)==0)) return;

   for ( int i=0 ; i<number_of_users ; i++ ) {
      if (strcmp(email, oneuser[i].email)==0) {
         fprintf(fp, "%s %d %lf %lf %d %s %s\n",
                    oneuser[i].email,
                    oneuser[i].ncurves,
                    oneuser[i].b1,
                    oneuser[i].work,
                    oneuser[i].factors,
                    oneuser[i].firsttime,
                    oneuser[i].lasttime);
      }
   }
}

void switchusers(userdetail * user1, userdetail * user2) {
   userdetail tempuser;

   memcpy(&tempuser, user1, sizeof(userdetail));
   memcpy(user1, user2, sizeof(userdetail));
   memcpy(user2, &tempuser, sizeof(userdetail));
}
