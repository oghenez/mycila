//  Oct 9 1998 Added get_work and get_sumb1

#ifndef ecmlist_h
   #define ecmlist_h

   #define min(a,b)  (((a) < (b)) ? (a) : (b))
   #define max(a,b)  (((a) > (b)) ? (a) : (b))
   
   struct b1_curves
   {
      double b1;
      int curvecount;
      int curvecount_from_downstream;
      int curvecount_for_upstream;
   };
   typedef struct b1_curves b1_curves;

   struct factor_detail
   {
      char * factor;
      char * fromname;
      double b1level;
      double sigma;
      int needs_upstream;
   };
   typedef struct factor_detail factor_detail;

   struct number_to_factor {
      char * shortname;
      char * base10rep;
      int b1_details_number;
      b1_curves * b1_details;
      int factor_details_number;
      factor_detail * factor_details;
      int activeflag;
      int LocalControl;
      int newinfoflag;
   };
   typedef struct number_to_factor number_to_factor;

   class ecm_list {
   public:
      int changes;
      int changethreshold;
      int sorttype;

   private:
      int number_of_numbers;
      number_to_factor * numbers_to_factor;
      char ecmfilename[300];

   public:
      ecm_list();
      ~ecm_list();
      int LoadDetails( char * filename );
      void StoreDetails( char * shortname, char * base10rep );
      int WriteDetails(char * name);
      void WriteDetails_as_required();
      void WriteDetails_as_required(char * name);
      int Add_Factor( int k, char * factor, int noremove, char * fromname, double b1level, double sigma);
      int Add_Factor( char * shortname, char * number, char * factor, int noremove, char * fromname, double b1level, double sigma);
      int Add_Factor( int k, char * factor, int noremove, char * fromname, double b1level, double sigma, int factor_needs_upstream);
      int Add_Factor( char * shortname, char * number, char * factor, int noremove, char * fromname, double b1level, double sigma, int factor_needs_upstream);

      int get_index( char * name );
      int get_index_base10( char * number );

      int get_number_of_numbers();
      int get_number_of_active();
      char * get_number_shortname( int k );
      char * get_number_base10rep( int k );
      char * get_number_base10rep( char * name );
      void SetActive(char * shortname );
      void SetActive( int k );
      void SetInActive(char * shortname );
      void SetInActive( int k );
      void SetInActiveAll();
      void SetLocalControl( char * shortname );
      void SetLocalControl( int k );
      void UnsetLocalControl( int k );
      int is_active( char * name);
      int is_active( int k );
      int hasnewinfo( int k );
      void SetNewinfo( int k );
      void UnsetNewinfo( int k );
      int is_LocalControl( char * name );
      int is_LocalControl( int k );
      int get_number_of_b1details(int k);
      double get_number_b1details_b1(int k, int i);
      int get_number_b1details_curves(int k, int i);
      int get_number_b1details_curves_from_downstream(int k, int i);
      int get_number_b1details_curves_for_upstream(int k, int i);
      int get_number_b1details(int k, double b1);
      int get_number_b1details(char * name, double b1);
      int Add_to_b1details(int k, double b1, int curves);
      int Add_to_b1details(char * name, char * number, double b1, int curves);
      int Add_to_b1details(int k, double b1, int curves, int curves_from_downstream, int curves_for_upload);
      int Add_to_b1details(char * name, char * number, double b1, int curves, int curves_from_downstream, int curves_for_upload);
      double get_bestb1(int k);
      double get_bestb1(int k, int * maxncurves);
      double get_sumb1(int k);
      double get_work(int k);
      char * get_allb1info(char * shortname);
      char * get_allb1info(int k);
      void set_allb1info(int k, char * buffer);
      void get_activeinfo(char * buffer);
      char * get_facinfo( char * shortname, int whichfactor);
      char * get_facinfo( int k, int whichfactor );
      int set_facinfo( int k, char * buffer , int noremove);

      int get_number_of_factors(int k);
      char * get_factor_details_factor(int k, int i);
      char * get_factor_details_finder(int k, int i);
      double get_factor_details_b1level(int k, int i);
      double get_factor_details_sigma(int k, int i);
      int get_factor_details_needs_upstream(int k, int i);
      void set_factor_details_needs_upstream(int k, int i, int value);

      void printnumber(int k);
      void printnumber(int k, int skipbase10);
      void printnumber(FILE * fp, int k);
      void printnumber(FILE * fp, int k, int skipbase10);
      void printnumberlist();
      void printnumberlist(int skipbase10);
      void printnumberlist(FILE * fp);
      void printnumberlist(FILE * fp, int skipbase10);

      void sortme();
      int newnumber(char * sourcename, char * base10rep);
   };
#endif

