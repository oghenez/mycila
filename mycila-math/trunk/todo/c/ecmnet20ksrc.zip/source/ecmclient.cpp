/*
  ecmclient

  Revision history:
  September 9, 1998 Original creation by Tim Charron <tcharron@interlog.com>
  September 20 1998 Version 1.1 Tim Charron
  September 22 1998 Version 1.2 Tim Charron
  September 25 1998 Version 1.3 Tim Charron
  September 30 1998 Version 1.4 Tim Charron
    Removed separate server connections for getting/returning work.
    Cleaned up '-admin' option
  October 2 1998 version 1.4b Tim Charron
    Added support for idle on Unix (Courtesy of RZG <gevaryah@netaxs.com>)
    Fixed some printfs that were missing the [] around the time
    Code now searches work.out for "Step 2 took" instead of "ECM".  If this is missing
     (and no factor was found), then it assumes user hit break, and quits.

  October 5, 1998 version 1.5a Tim Charron
    Changes for NT service version
  October 5 1998 version 1.5b  (no significant changes -- keep version in line with server)
  October 7 1998 version 1.6   (no significant changes -- keep version in line with server)
  October 8 1998 version 1.7   (no significant changes -- keep version in line with server)
  Oct 9 1998 version 1.7b Fixed problem of extra curve getting counted on break
  Oct 13 1998 version 1.8 Client/Server provide messages about total work completed as per upstream server.
  Oct 13 1998 version 1.8 Client now produces 'daily' and 'crv' logs.
  Oct 16 1998 version 1.8b Client now sends cofactor to server, as well as primality of factor&cofactor.
  Oct 18 1998 version 1.8d Support for admin_setlocal/admin_unsetlocal commands
  Oct 23 1998 version 1.8f Fixed small memory leaks
  Oct 24 1998 version 1.9 - Fixed crash when some composites have ',' in their name
                          - "Admin" options changed so that only those that change server config. require password.
  Oct 27 1998 version 1.9b Fixed bug when server sends 'down' a new factor -- sigma info was occasionally lost.
                           - default error timeout changed to 5 minutes
                           - Added support for server specifed 'max # curves' to process
                           - Added support for identifying factors found in step1 vs step2
  Oct 30 1998 version 1.9c - Sped up communications to upstream server
  Nov 2 1998 version 1.9d - Added support for "GETGREETING"
  Nov 8 1998 version 2.0 - version # incremented to match server.
             version 2.0a - errtimeout set to 20 minutes
                          - Added message indicating why a connection occurred before the timer interval
  Apr 15 1999 Version 2.0g - Allowed specification of server names using name (instead of IP address)
  Apr 22 1999 Version 2.0h - server names > 20 characters weren't working properly.
  Jun 21 1999 Version 2.0j - Fixed misc. problems with getstring() NULL/"" return values and strlen()/free() etc.

The most recent version of this source is available from http://www.interlog.com/~tcharron/ecm.html

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>

#ifdef WIN32
   #include <winsock.h>
   #include <io.h> // unlink()
   #include <sys\stat.h>
   #include <direct.h>
#endif

#ifdef UNIX
   #include <unistd.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <arpa/inet.h>
   #include <sys/stat.h>
   #include <signal.h>
#endif

#include "defs.h"
#include "ecm_list.h"
#include "common.h"
#include "users.h"

int get_work(int s, char * name, char * number, double *b1, int * ncurves, int * maxncurves, ecm_list * ecmlist)
{
   char * buf2;
   char * ptr;
   *maxncurves = -1;

   int err=1;
   putstring(s, "GETWORK\n");
   buf2 = getstring(s);
   if ( strncmp(buf2, "ECMname: ", 9)==0 ) {
      strcpy(name, buf2+9);
      free(buf2);
      buf2 = getstring(s);
      if ( strncmp(buf2, "ECMnumber: ", 11)==0 ) {
         strcpy(number, buf2+11);
         free(buf2);
         buf2 = getstring(s);
         if ( strncmp(buf2, "ECMB1: ", 7) ==0 ) {
            *b1 = atol(buf2+7);
            free(buf2);
            buf2 = getstring(s);
            if ( strncmp(buf2,"ECMCurves: ", 11) == 0 ) {
               *ncurves = atoi(buf2+11);
               err=0;
               if ((ptr=strchr(buf2+11,':')) != NULL) {
                  *maxncurves = atoi(ptr+1);
                  if ((*maxncurves) == 0) *maxncurves = -1; // 0 would be a bad thing
               }
            }
         }
      }
   }
   if (buf2 != NULL) free(buf2);

   if ( err ) {
//      log(logname,"GetWork Error.\n");
      printf("[%s] GetWork error\r", Time());
      fflush(stdout);
      return (1);
   } else {
      if ( ecmlist->get_index( name ) == 0 ) {
         // Not in the client's ini file yet...
         ecmlist->StoreDetails( name, number );
      } else {
         buf2 = ecmlist->get_number_base10rep( name );
         if ( buf2 != NULL ) {
            if ( strcmp(buf2 , number) != 0 ) {
               sprintf(logmsg, "Returned base10 representation for %s doesn't match stored copy.\n", name);
               log(logname,logmsg);
               return (1);
            }
         }
      }
      getb1andfacinfo(ecmlist, 0, s, ecmlist->get_index(name) );
      putstring(s, "QUIT\n");
   }
   return (0);
}

int factor_count(char * filename , int * curves, int * foundcount)
{
   // Counts "ECM" and "Found" occurrences in filename.
   // Returns the "ECM" count amount

   // 98.10.2 Now checks for "Step 2 took" instead of "ECM"

   char line[241];
   FILE * fp;

   *foundcount = 0;
   *curves = 0;
   if ( (fp = fopen(filename,"r")) == NULL ) return (*foundcount);

   // count no of lines in file
   while ( fgets(line,240,fp) != NULL ) {
      if ( strstr(line,"Step 2 took") != NULL ) (*curves)++;
      if ( strstr(line,"Found "     ) != NULL ) (*foundcount)++;
   }
   fclose(fp);
   return (*foundcount);
}

int getfactors(char * work_out, char * name, char * number, ecm_list * ecmlist, char * fromname) {
   FILE * fp;
   char * ptr;
   char *factorstring;
   char *factortype;
   char *cofactorstring;
   char *cofactortype;
   char *tempstring;

   char *line;
   int foundcount=0;
   int step=0;
   double B1=0.0, sigma=0.0;

   if ( (fp = fopen(work_out,"r")) == NULL ) {
      printf("Can't open file:%s\n",work_out);
      return (0);
   }

   B1=0.0;
   sigma=0.0;
   factorstring=NULL;  // base 10 factor
   factortype=NULL;    // status (prime, probable, composite)
   cofactorstring=NULL;
   cofactortype=NULL;
   line = new char[BUFFERSIZE];

   // The work.out file has the output of ONE run of ecm.
   // Look for: "Found " ...next word is type of factor (prime, composite, probable)
   //                    ...get the factor after the ":" on this row.
   //                    ...First word of next row is type of cofactor (prime, composite, probable)
   //         : "Using B1="...get the b1/sigma values from this row
   //         : cofactor ...next word is the base10 cofactor
   //         : "Step " ...next character is the step that factor was found in.
   while ( fgets(line,BUFFERSIZE-1,fp) != NULL ) {
      // Check if we have found a factor, but have no information on the cofactor.
      // If so, then the first word of this row is the type of cofactor...
      if ( (factorstring != NULL) && (cofactortype==NULL)) {
         cofactortype=nextword(line);
      }
      if ( (ptr = strstr(line,"Found ") )!= NULL ) {
         // Get factor type...
         factortype=nextword(ptr+6);

         // Get factor base10 representation...
         ptr = strstr(ptr, ": ");
         if (ptr != NULL) {
            ptr += 2;

            // Remove any trailing CR/LF...
            stripCRLF(ptr);

            if ( strcmp(ptr, number) != 0 ) {
               factorstring = new char[strlen(ptr)+1];
               strcpy(factorstring, ptr);
            } else {
               log(logname, "Found input number.\n");
            }
         } else {
            log(logname, "Found input number.\n");
         }
      } else if ( (ptr = strstr(line,"Using B1=") )!= NULL ) {
         // parse "Using B1=11000 ... sigma=151754956"
         B1 = atol(ptr+9);
         ptr = strstr(line, "sigma=");
         sigma = atol(ptr+6);
      } else if ( (ptr = strstr(line, "ofactor ") ) != NULL) {
         // next word is the cofactor.
         // First word of this row is the cofactor type.
         cofactorstring=nextword(ptr+8);
      } else if ( strncmp(line,"Step ",5) == 0) {
         step = atoi(line+5);
      }
   }
   fclose(fp);

   if (factorstring != NULL) {
      tempstring = new char[strlen(factorstring)+strlen(factortype)+
                            strlen(cofactorstring)+strlen(cofactortype)+15];
      strcpy(tempstring, factorstring);
      strcat(tempstring, ":");
      strcat(tempstring, factortype);
      strcat(tempstring, ":");
      strcat(tempstring, cofactorstring);
      strcat(tempstring, ":");
      strcat(tempstring, cofactortype);
      if (step==1) strcat(tempstring, ":STEP1");

      if (0 == ecmlist->Add_Factor(name, number, tempstring, 1, fromname, B1, sigma)) {
         sprintf(logmsg,"Dup. factor found!  %s / %s  B1: %.0lf sigma: %.0lf\n", name, factorstring, B1, sigma );
         log(logname, logmsg);
      } else {
         sprintf(logmsg,"Factor found!  %s / %s  B1: %.0lf sigma: %.0lf  Type: %s  Cofactor is \'%s\': %s (found in step %d)\n",
                 name, factorstring, B1, sigma,
                 factortype,cofactortype, cofactorstring, step);
         log(logname, logmsg);
         logfile("Factors.log",logmsg);
         foundcount++;
      }
      free(factorstring);
      free(tempstring);
   }
   if (factortype != NULL)     free(factortype);
   if (cofactorstring != NULL) free(cofactorstring);
   if (cofactortype != NULL)   free(cofactortype);

   free(line);
   return (foundcount);
}

void Usage(char *name) {
   printf("Usage: %s [-s addr] [-p port#] [-e email] [-id machineid] [-x exefile] [-idle | -noidle] [-hide] [-maxfreq min] [-errtimeout n] [-loglimit n] [-smallini] [-curdir dir]\n",name);
   printf("    -s addr    Specify address of server to connect to.\n");
   printf("    -p port #  Specify port number to connect to.\n");
   printf("    -e email   Specify email address to provide to server.\n");
   printf("    -id email  Specify unique machine ID to provide to server.\n");
   printf("    -x exefile Specify the ECM executable (default: ecm2i.exe)\n");
   printf("    -idle      Run in idle priority class\n");
   printf("    -noidle    Do not run in idle priority class\n");
#ifdef WIN32
   printf("    -hide      Remove the console window\n");
#endif
   printf("    -maxfreq X    Connect no more often than every X minutes\n");
   printf("    -errtimeout n Set delay on communication errors to n minutes\n");
   printf("    -loglimit n   Limit log size to 'n' bytes\n");
   printf("    -smallini     Remove old entries from ecmclient.ini file\n");
   printf("    -curdir dir   Make 'dir' the current directory\n");
}

void do_admin_getfile(char * server, int port, char * fromname, char * adminpass, char * commandtext, int usepass, char * destfile) {
   int s;
   char tempt[200];
   char * ptr;
   FILE * fp;

   unlink(destfile);
   if ( (fp = fopen(destfile,"wt")) == NULL ) {
      printf("Couldn't create %s.\n",destfile);
      return;
   }

   s = -1;
   while ( s == -1 ) {
      s = open_server(server, port, fromname);
      if ( s==-1 ) {
         printf("[%s] Connect error.  Pausing 15 seconds\r", Time());
         fflush(stdout);
         Sleep((int) (  15000. * 0.90
                      + 15000. * 0.20 * rand() / RAND_MAX) );
      }
   }

   if (usepass) {
      sprintf(tempt, "ADMIN %s\n", adminpass);
      putstring(s, tempt);
   }

   putstring(s, commandtext);
   putstring(s, "\n");

   int done=0;
   while (done==0) {
      ptr = getstring(s);
		if (ptr==NULL) {
			done=1;
		} else if ( strlen(ptr) == 0) {
			done=1;
		} else if ( strncmp(ptr, "OK", 2)==0 ) {
			done=1;
		} else if ( strncmp(ptr, "ERR", 3)==0) {
			done=1;
		}
      if (ptr!=NULL) {
			printf("%s\n", ptr);
         if (!done) fprintf(fp , "%s\n", ptr);
			free( ptr );
		}
   }

   fclose(fp);

   putstring(s, "ADMIN_QUIT\n");
   putstring(s, "QUIT\n");
   closesocket(s);
   getstring(-1);                             // Reset any partial pre-read information in buffer.
   return;
}

void do_admin(char * server, int port, char * fromname, char * adminpass, char * commandtext, int usepass, int OK_num) {
   int s;
   char tempt[200];
   char * ptr;

//printf("%s %d %s %s %s\n",server, port, fromname, adminpass, commandtext);
   s = -1;
   while ( s == -1 ) {
      s = open_server(server, port, fromname);
      if ( s==-1 ) {
         printf("[%s] Connect error.  Pausing 15 seconds\r", Time());
         fflush(stdout);
         Sleep((int) (  15000. * 0.90
                      + 15000. * 0.20 * rand() / RAND_MAX) );
      }
   }

   // Echo any greeting to the screen that was supplied...
//   if (upstreamgreeting[0] != 0) printf(upstreamgreeting);

   if (usepass) {
      sprintf(tempt, "ADMIN %s\n", adminpass);
      putstring(s, tempt);
   }

   putstring(s, commandtext);
   putstring(s, "\n");

   int done=0;
   while (done != OK_num) {
      ptr = getstring(s);
		if (ptr==NULL) {
			done=OK_num;
		} else if ( strlen(ptr) == 0) {
			done=OK_num;
		} else if ( strncmp(ptr, "OK", 2)==0 ) {
			done++;
		} else if ( strncmp(ptr, "ERR", 3)==0) {
			done=OK_num;
		}
		if (ptr!=NULL) {
			printf("%s\n", ptr);
			free( ptr );
		}
   }

   if (usepass) putstring(s, "ADMIN_QUIT\n");
   putstring(s, "QUIT\n");
   closesocket(s);
   getstring(-1);                             // Reset any partial pre-read information in buffer.
   return;
}

void admin(char * server, int port, char * fromname) {
   int menuitem=-1;
   char adminpass[100];
   char name[100];
   char * number;

   number = new char[BUFFERSIZE];

   strcpy(adminpass, "-");
   while (menuitem != 0) {
      printf("Admin menu\n");
      printf("==========\n");
      printf("0. Quit.\n"
             "1. Enter admin password.\n"
             "2. Enter server address (%s).\n"
             "3. Enter server port # (%d).\n"
             "4. Get Server status of all known numbers.\n"
             "5. Get Server status of all active numbers.\n"
             "6. Query details by name.\n"
             "7. Query details by number (base 10 representation).\n",server,port);
      if (strcmp(adminpass,"-") != 0) {
         printf("8. Copy the server's INI file to ecmserver.ini.copy\n"
                "9. Set a number to 'active' status.\n"
                "10. Set a number to 'inactive' status.\n"
                "11. Set a number to 'local control'\n"
                "12. Remove a number from 'local control'\n"
                "13. Enter details of a new number.\n");
      }
      printf("14. Get B1 & Factor information by name.\n"
             "15. Get Base 10 representation by name.\n"
             "16. Get list of all active numbers on server.\n"
             "17. Get a copy of the server's Factors.log file.\n"
             "18. View server's Greeting.txt file.\n");

      fgets(logmsg,BUFFERSIZE-1,stdin);
      menuitem = atoi(logmsg) ;
      if ( menuitem == 1) {
         printf("Enter password.\n");
         fgets(adminpass, 99, stdin);
         stripCRLF(adminpass);
      } else if ( menuitem == 2) {
         fgets(server, 16, stdin);
         stripCRLF(server);
      } else if ( menuitem == 3) {
         fgets(name, 99, stdin);
         port = atoi( name );
      } else if ( menuitem == 4) {
         sprintf(logmsg, "ADMIN_STATUS");
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 5) {
         sprintf(logmsg, "ADMIN_STATUS_ACTIVE");
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 6) {
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "ADMIN_QUERY NAME %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 7) {
         printf("Enter number:\n");
         fgets(number, BUFFERSIZE-1, stdin);
         stripCRLF(number);
         sprintf(logmsg, "ADMIN_QUERY NUMBER %s", number);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 8) {
         sprintf(logmsg, "ADMIN_GETINI");
         do_admin_getfile(server, port, fromname, adminpass, logmsg, 1, "ecmserver.ini.copy");
      } else if ( menuitem == 9) {
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "ADMIN_SETACTIVE %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 10) {
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "ADMIN_SETINACTIVE %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 11) {
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "ADMIN_SETLOCAL %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 12) {
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "ADMIN_UNSETLOCAL %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 13) {
         printf("Enter name:\n");
         fgets(name  , 99, stdin);
         stripCRLF(name);
         printf("Enter number:\n");
         fgets(number, BUFFERSIZE-1, stdin);
         stripCRLF(number);
         sprintf(logmsg, "ADMIN_NEW %s %s", name, number);
         do_admin(server, port, fromname, adminpass, logmsg,1, 1);
      } else if ( menuitem == 14) {
         // This isn't an 'admin' command, but I put it in here anyway for testing purposes.  -- Tim
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "GETB1DET %s\nGETFAC %s", name, name);
         do_admin(server, port, fromname, adminpass, logmsg,0, 2);
      } else if ( menuitem == 15) {
         // This isn't an 'admin' command, but I put it in here anyway for testing purposes.  -- Tim
         printf("Enter name:\n");
         fgets(name, 99, stdin);
         stripCRLF(name);
         sprintf(logmsg, "GETBASE10 %s", name);
         do_admin(server, port, fromname, adminpass, logmsg,0, 1);
      } else if ( menuitem == 16) {
         // This isn't an 'admin' command, but I put it in here anyway for testing purposes.  -- Tim
         sprintf(logmsg, "GETACTIVES");
         do_admin(server, port, fromname, adminpass, logmsg,0, 1);
      } else if ( menuitem == 17) {
         sprintf(logmsg, "ADMIN_GETFACTORS");
         do_admin_getfile(server, port, fromname, adminpass, logmsg, 1, "Factors.log.copy");
      } else if ( menuitem == 18) {
         sprintf(logmsg, "GETGREETING");
         do_admin(server, port, fromname, adminpass, logmsg, 0, 1);
      } else if ( menuitem == 0) {
         // Do nothing...
      } else {
         printf("Invalid choice.\n");
      }
      printf("Hit enter key to continue...\n");
      fgets(name, 99, stdin);
   }

   delete number;
   return;
}

#if defined(NTSERVICE)
int actualmain(int argc, char * argv[])
#else
int main(int argc, char *argv[])
#endif
{
   int s, thiscurves, curves, ncurves, maxncurves, totcurves=0, oldtotfactors=0, totfactors=0, port=8194, elapseds=0;
   int thisfac_count=0;
   int timeh=0, timem=0, times=0;
   double b1, totb1=0.0, totwork=0.0;
   char * ptr;
   char * bigbuffer;
   char server[200];
   char email[300];
   char curdir[300];
   char machineid[150];
   char exefile[150];
   char name[100];
   char cmdline[400];
   char inifile[200];
   char line[240];
   char cfgfile[200];
   int errorflag;
   int hide=0, idle=1, smallini=0;
   FILE * fp;
   ecm_list ecmlist;
   time_t timestart;
   time_t loopstart;
   int maxfreq=720;
   int adminreq=0;
   int errtimeout=20; // 20 minute timeout by default
   int quit=0;
   char curvelistfile[200];
   char dailyworkfile[200];
   user curvelist;
   user dailywork;

   timestart = time( NULL );

   bigbuffer = new char[BUFFERSIZE];
   logmsg = new char[BUFFERSIZE];
   upstreamgreeting = new char[BUFFERSIZE];
   upstreamgreeting[0]=0;
   loglimit=0;

   strcpy(server,"127.0.0.1");
   strcpy(email,"");
   strcpy(machineid,"machine_1");
   strcpy(exefile, "ecm2i.exe");
   strcpy(curdir,"");

   // Process any CFG file supplied...
   strcpy(cfgfile, argv[0]);
   ptr = strrchr(cfgfile,'/');
   if (ptr == NULL) {
      ptr = strrchr(cfgfile,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcpy(curvelistfile, cfgfile);
   strcpy(dailyworkfile, cfgfile);
   strcat(cfgfile, ".cfg");
   strcat(curvelistfile, ".crv");
   strcat(dailyworkfile, ".daily");

   if ( (fp = fopen(cfgfile,"r")) == NULL ) {
      printf("'%s' not found\n",cfgfile);
   } else {
      while ( fgets(line,239,fp) != NULL ) {
         stripCRLF(line);
         if ( strncmp(line, "email=", 6) == 0) {
            strcpy(email, line+6);
         } else if ( strncmp(line, "server=", 7) == 0) {
            strcpy(server, line+7);
         } else if ( strncmp(line, "curdir=", 7) == 0) {
            strcpy(curdir, line+7);
         } else if ( strncmp(line, "id=", 3) == 0) {
            strcpy(machineid, line+3);
         } else if ( strncmp(line, "exefile=", 8) == 0) {
            strcpy(exefile, line+8);
         } else if ( strncmp(line, "port=", 5) == 0) {
            port = atoi( line+5 );
         } else if ( strncmp(line, "idle=1", 6) == 0) {
            idle=1;
         } else if ( strncmp(line, "idle=0", 6) == 0) {
            idle=0;
         } else if ( strncmp(line, "debug=1", 7) == 0) {
            setdebug();
         } else if ( strncmp(line, "hide=1", 6) == 0) {
            hide=1;
         } else if ( strncmp(line, "smallini=1", 10) == 0) {
            smallini=1;
         } else if ( strncmp(line, "maxfreq=", 8) == 0) {
            maxfreq = atoi( line+8 );
         } else if ( strncmp(line, "loglimit=", 9) == 0) {
            loglimit = atol( line+9 );
         } else if ( strncmp(line, "errtimeout=",11) == 0) {
            errtimeout = atoi(line+11);
         }
      }
      fclose(fp);
   }

   // Process the command line...
   for ( int i=1; i<argc; i++ ) {
      if ( strcmp(argv[i],"-p")==0 ) {
         port=atoi(argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-s") == 0 ) {
         strcpy(server, argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-e") == 0 ) {
         strcpy(email, argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-curdir") == 0 ) {
         strcpy(curdir, argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-id") == 0 ) {
         strcpy(machineid, argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-x") == 0 ) {
         strcpy(exefile, argv[i+1]);
         i++;
      } else if ( strcmp(argv[i],"-idle") == 0 ) {
         idle=1;
      } else if ( strcmp(argv[i],"-noidle") == 0 ) {
         idle=0;
      } else if ( strcmp(argv[i], "-hide") == 0) {
         hide=1;
      } else if ( strcmp(argv[i], "-smallini") == 0) {
         smallini=1;
      } else if ( strcmp(argv[i], "-debug") == 0) {
         setdebug();
      } else if ( strcmp(argv[i], "-maxfreq") == 0) {
         maxfreq = atoi(argv[i+1]);
         i++;
      } else if ( strcmp(argv[i], "-loglimit") == 0) {
         loglimit = atol(argv[i+1]);
         i++;
      } else if ( strcmp(argv[i], "-errtimeout") == 0) {
         errtimeout = atoi(argv[i+1]);
         i++;
      } else if ( strcmp(argv[i], "-admin") == 0) {
         adminreq=1;
      } else {
         Usage(argv[0]);
         return (0);
      }
   }

#ifdef WIN32
   if (idle) {
      SetPriorityClass( GetCurrentProcess(), IDLE_PRIORITY_CLASS );
      SetThreadPriority(GetCurrentThread() ,THREAD_PRIORITY_IDLE );
      printf("Client will run in idle class.\n");
   }

   if (hide) FreeConsole();
#endif

#ifdef UNIX
   // Courtesy of RZG <gevaryah@netaxs.com> October 2, 1998...
   if (idle) {
     if (nice(20) == -1) printf("Warning: Could not nice!\n");
   }
   /* Ignore SIGHUP, as to not die on logout.
      We log to file in most cases anyway. */
   signal(SIGHUP, SIG_IGN);
#endif

   if (maxfreq<1) maxfreq=1;
   if (errtimeout<1) errtimeout=1;

   strcpy(logname, argv[0]);
   ptr = strrchr(logname,'/');
   if (ptr == NULL) {
      ptr = strrchr(logname,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcat(logname, ".log");

   if (strlen(email) == 0) {
      printf("An email address must be configured with '-e'.  '%s -help' for help.\n",argv[0]);
      exit(-1);
   }
   if ((NULL==strchr(email,'@') ) || (strchr(email,':') != NULL) ) {
      printf("Email address supplied (%s) is not valid.\n",email);
      exit(-1);
   }

   if (strlen(curdir) > 0) chdir(curdir);

   struct stat buf;
   if ( -1 == stat(exefile,&buf) ) {
      // File doesn't exist
      sprintf(logmsg, "Couldn't find %s.\n",exefile);
      log(logname, logmsg);
      exit(-1);
   }

   /* read in the prior file of completed calculations. */
   strcpy(inifile, argv[0]);
   ptr = strrchr(inifile,'/');
   if (ptr == NULL) {
      ptr = strrchr(inifile,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcat(inifile, ".ini");

   if ( ecmlist.LoadDetails( inifile ) ) {
      sprintf(logmsg, "Couldn't open %s\n", inifile );
      log(logname,logmsg);
   }

   if (!smallini) {
      if ( curvelist.LoadUsers( curvelistfile, 1 ))  {
         sprintf(logmsg, "Couldn't open %s\n", curvelistfile );
         log(logname, logmsg);
      }
      curvelist.sorttype=2;

      if ( dailywork.LoadUsers( dailyworkfile, 1 )) {
         sprintf(logmsg, "Couldn't open %s\n", dailyworkfile );
         log(logname, logmsg);
      }
      dailywork.sorttype=0;
   }

#ifdef WIN32
   /* miscellaneous windows initializations */
   ///////////////////////////////////////////////////////////////////////////
   WSADATA wsaData;
   WSAStartup(MAKEWORD(1,1), &wsaData);
   ///////////////////////////////////////////////////////////////////////////
#endif

   if (adminreq) {
      admin(server, port, email);
      return 0;
   }

   sprintf(logmsg, "ECMnet Client application v%d.%d%c started.\n",VERSIONMAJOR, VERSIONMINOR, VERSIONMINOR2);
   log(logname,logmsg);
   log(logname,"Please visit http://www.interlog.com/~tcharron/ecm.html for information.\n");

   sprintf(logmsg, "Configured to connect to %s:%d\n",server,port);
   log(logname,logmsg);
   sprintf(logmsg, "User email address is %s\n",email);
   log(logname,logmsg);
   sprintf(logmsg, "ECM binary file is set to %s\n", exefile);
   log(logname,logmsg);

   strcat(email,":");
   strcat(email, machineid);
   strcat(email,":");
   sprintf(logmsg, "v%d.%d%c", VERSIONMAJOR, VERSIONMINOR,VERSIONMINOR2);
   strcat(email,logmsg);

   // The main loop...
   // 1. Connect and get some work.
   // 2. Do the work
   // 3. Return the work details (completed curve + possible factors)

   while ( !quit ) {

      // Open a connection to the server...
      s = -1;
      while ( s == -1 ) {
         s = open_server(server, port, email);
         if ( s==-1 ) {
            printf("[%s] Connect error.  Pausing %d minutes\r", Time(), errtimeout);
            fflush(stdout);
            Sleep((int) (  60000. * errtimeout * 0.90
                         + 60000. * errtimeout * 0.20 * rand() / RAND_MAX ) );
         }
      }

//      sprintf(logmsg, "Connected to %s:%d\n",server, port);
//      log(logname,logmsg);

      // Echo any greeting to the screen that was supplied...
      if (upstreamgreeting[0] != 0) printf(upstreamgreeting);

      // Attempt to send any information upstream that might be available.
      // (either from prior shutdown, or from prior iteration of main 'while' loop
      errorflag = returnwork(s, &ecmlist, 0, 0); // Doesn't close the socket

      // Get a chunk of work...
      if (-1 != errorflag) {
         errorflag = get_work(s, (char *) name, bigbuffer, &b1, &ncurves, &maxncurves, &ecmlist);
      }
      closesocket(s);
      getstring(-1);                         // Reset any partial pre-read information in buffer.

      if (smallini) {
         ecmlist.WriteDetails_as_required( name ); // Commit changes
      } else {
         ecmlist.WriteDetails_as_required(); // Commit changes
      }

      if ( 0 == errorflag ) {
         if (ncurves != 1) {
            sprintf(logmsg, "Received %s/B1=%.0lf * %d curves\n",name, b1, ncurves);
         } else {
            sprintf(logmsg, "Received %s/B1=%.0lf\n",name, b1);
         }
         log(logname,logmsg);

         if ( (fp = fopen("work.in" ,"wt")) == NULL ) {
            printf("Couldn't write 'work.in'\n");
            exit(-1);
         }
         fprintf(fp, "%s\n",bigbuffer);
         fclose(fp);

         // do the work...
         unlink("work.out");
         curves=0;
         loopstart = time( NULL );
         oldtotfactors = totfactors;
         // Loop until a factor is found.  Do at least as many curves as the server assigned
         // (up to the maximum specified)
         // until the next scheduled connect interval.
         while (    ( oldtotfactors == totfactors)
                 && (!quit)
                 && ( curves != maxncurves)
                 && ( (ncurves>curves) || (difftime( time( NULL ) , loopstart) < maxfreq*60) ) ) {
            // "Command.com /c exefile b1 < work.in >> work.out"
            sprintf(cmdline, "%s %.0lf < work.in >> work.out", exefile, b1);
            system( (const char *) cmdline);

            thisfac_count=0;
            factor_count("work.out", &thiscurves, &thisfac_count);
            curves += thiscurves;
            totb1 += b1;
            totwork += b1*strlen(name)*strlen(name)/1000000.;
            if (thiscurves+thisfac_count == 0) {
               quit=1;
               log(logname, "Quitting due to detected interruption\n");
            }

            ecmlist.Add_to_b1details(name, bigbuffer, b1, thiscurves);
            if (thisfac_count != 0) {
               totfactors += getfactors("work.out", name, bigbuffer, &ecmlist, email);
            }
            if (!quit) unlink("work.out");

            printf("[%s] Done %d curves for %s (B1=%.0lf).\r",Time(), curves,name,b1);
            fflush(stdout);

            if (smallini) {
               ecmlist.WriteDetails_as_required( name ); // Commit changes
            } else {
               ecmlist.WriteDetails_as_required(); // Commit changes

               double work = curves * b1 * strlen(bigbuffer) * strlen(bigbuffer);
               curvelist.adduser((const char *) name,    curves, curves * b1, work, thisfac_count, Time() );
               dailywork.adduser((const char *) Date() , curves, curves * b1, work, thisfac_count, Time() );
            }
         }
         unlink("work.in");
         sprintf(logmsg,"Done %d curves for %s.  Found %d factors.\n",curves, name, thisfac_count );
         log(logname,logmsg);

         totcurves += curves;

         elapseds = (int) difftime( time( NULL ) , timestart);
         timeh = elapseds/3600;
         timem = (elapseds - timeh*3600) / 60;
         times = elapseds - timeh*3600 - timem*60;
         sprintf(logmsg, "El:%3d:%02d:%02d Crvs: %d totwork: %.0lf Fac: %d\n",
                                  timeh, timem, times, totcurves, totwork, totfactors);
         log(logname, logmsg);

         if ( curves == maxncurves) {
            sprintf(logmsg, "Contacting server due to maximum curves processed for this B1\n");
            log(logname, logmsg);
         }
      } else {
         Sleep(1000);                               // pause a bit
      }
      fflush(stdout);
   }

   log(logname,"Client shutdown complete\n");
   return (0);
}

