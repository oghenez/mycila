int sendmessage(char * msg, char * subject, char * destid, char * smtp, int port, char * fromid);
char *inet_name(struct in_addr in);

