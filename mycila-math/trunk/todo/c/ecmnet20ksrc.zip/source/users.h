#ifndef users_h
   #define users_h

   struct userdetail {
      char * email;
      int ncurves;
      double b1;
      double work;
      int factors;
      char * firsttime;
      char * lasttime;
   };
   typedef struct userdetail userdetail;

   class user {
   public:
      int changes;
      int changethreshold;
		int sorttype; // 0=none.  1=Most recent at bottom.  2=most work at top.

   private:
      int number_of_users;
      userdetail * oneuser;
      char * usrname;

   public:
      user();
      ~user();
      int LoadUsers( char * filename , int thresh);
      void adduser(const char * email, int ncurves, double b1, double work, int factors, const char * curtime);
      void storeuser(const char * email, int ncurves, double b1, double work, int factors, const char * firsttime, const char * lasttime);
		void user::sortme();
      int WriteUsers();
      void WriteUsers_as_required();
      void printuser(FILE * fp, char * email);
   };
#endif

