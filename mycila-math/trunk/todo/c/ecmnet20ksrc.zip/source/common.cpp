/*

  September 9, 1998 Original creation by Tim Charron <tcharron@interlog.com>
  September 20 1998 Version 1.1 Tim Charron
  Oct 9 1998 version 1.7b New Time()/Date() format.
                          getstring() fixed for potential overflow problem

  Oct 23 1998 Fixed 2 small memory leaks
  Oct 30 1998 version 1.9c - Sped up communications to upstream server
  Nov 7 1998 version 1.9f - Fixed a bug in open_server that caused a hang
                            when the upstream socket was opened, but no data was available
  Nov 20 1998 version 2.0e - Improved comm. error detection for unix systems (no affect on Win32)
  Apr 15 1999 Version 2.0g - Moved inet_address() to this file
  Jun 21 1999 Version 2.0j - Fixed misc. problems with getstring() NULL/"" return values and strlen()/free() etc.
                           
The most recent version of this source is available from http://www.interlog.com/~tcharron/ecm.html

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>

#ifdef WIN32
   #include <winsock.h>
   #include <io.h> // unlink()
#endif

#ifdef UNIX
   #include <unistd.h>
   #include <sys/types.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <arpa/inet.h>
   #include <fcntl.h>
#endif

#include "defs.h"
#include "ecm_list.h"
#include "common.h"

char * logmsg;
char logname[100];
long loglimit=0;
char * upstreamgreeting;

int debug=0;
void setdebug() {
   debug=1;
}

const char * Time( void )
{
   time_t timenow;
   struct tm * gmt;
   static char timestring[64];
   timestring[0] = 0;

   timenow = time( NULL );

   gmt = gmtime(&timenow );
   if ( !gmt ) gmt = localtime(&timenow);
   if ( gmt ) {
      sprintf( timestring, "%04d-%02d-%02d %02d:%02d:%02d GMT",
         1900+gmt->tm_year,
         gmt->tm_mon + 1,
         gmt->tm_mday,
         gmt->tm_hour, gmt->tm_min, gmt->tm_sec );
   }
   return ( timestring );
}

const char * Date( void )
{
   time_t timenow;
   struct tm * gmt;
   static char datestring[14];
   datestring[0] = 0;

   timenow = time( NULL );
   gmt = gmtime(&timenow );
   if ( !gmt ) gmt = localtime(&timenow);
   if ( gmt ) sprintf( datestring, "%04d-%02d-%02d", 1900+gmt->tm_year, gmt->tm_mon + 1,gmt->tm_mday);

   return ( datestring );
}

void logger(char * filename, char * msg, int quietflag, int respectsizelimit) {
   FILE *fp;
   struct stat buf;
   char filenameold[400];

   if ( (fp = fopen(filename,"at")) == NULL ) {
      // couldn't open for appending
      if ( -1 == stat(filename,&buf) ) {
         // File doesn't exist
         if ( (fp = fopen(filename,"wt")) == NULL ) {
            printf("Couldn't create %s.\n",filename);
         } else {
            if (!quietflag) fprintf(stdout, "[%s] %s", Time(), msg);
            fprintf(fp    , "[%s] %s", Time(), msg);
            fclose(fp);
         }
      }
   } else {
      if (!quietflag) {
         printf("[%s] %s", Time(), msg);
         if (debug) fflush(stdout);
      }
      fprintf(fp    , "[%s] %s", Time(), msg);
      fclose(fp);
   }

   if (respectsizelimit && (loglimit>0)) {
      // See if the file has grown too big...
      if( stat( filename, &buf ) != -1 ) {
         if (buf.st_size > loglimit) {
            strcpy(filenameold, filename);
            strcat(filenameold, ".old");
            // delete filename.old
            unlink(filenameold);
            // rename filename to filename.old
            rename((const char *) filename, (const char *) filenameold);
         }
      }
   }
}

void log(char * filename, char * msg) {
   if (loglimit != -1) logger(filename, msg, 0, 1);
   if (debug) logger("debug.log", msg, 1, 1);
}
void logfile(char * filename, char * msg) {
   logger(filename, msg, 1, 0);
}

int putstring(int s, char * text) {
   char * ptr;
   int quit, ret;
   char * msg;

   if (debug) {
      msg = new char[strlen(text)+10];
      sprintf(msg, ">>>>>> %s\n",text);
      logger("debug.log", msg, 0, 1);
      delete msg;
   }
   quit=0;
   ptr = text;
   while ( ( ptr != text+strlen(text) ) && (!quit)) {
      ret = send(s, ptr, strlen(ptr), 0 );
      if (ret == -1) {
         if ( BLOCKING_ERROR == comm_errno ) {
            Sleep(50);                           // 50ms pause to prevent racing
         } else {
            quit=1;
         }
      } else {
         ptr += ret;
      }
   }

   if (quit) {
      if (debug) {
         logger("debug.log", ">>>>>> !!! error in putstring !!! \n", 0, 1);
      }
      return -1;
   }
   return 0;
}

char * getstring(int s) {
   static int storedsize=0;
   static int allocsize=0;
   static char * buffer=NULL;

   time_t time1;
   int bytes;
   int quit=0;
   char * buf2;
   char * msg;
   int foundlength=0;
   int i;

   time1 = time( NULL );

   if (s == -1) {
      // A special flag to purge anything stuck in the pre-loaded buffer...
      storedsize=0;
      return NULL;
   }

   if (allocsize ==0) {
      // First time called.
      buffer = new char[10000];
      allocsize += 10000;
   }

   while ( !quit ) {

   // First, check if there's a 'complete' valid string at the start of 'buffer'...
      for ( i=0; i<storedsize ; i++ ) {
         if ( foundlength==0 ) {
            if ( (buffer[i]==0) || (buffer[i]==0x0A) ) {
               foundlength = i+1;
            }
         }
      }

      if ( foundlength != 0 ) {
         // Make a copy of the string from the buffer...
         buf2 = new char[foundlength+2];
         strncpy(buf2, buffer, foundlength);
         // Make sure it's terminated.
         *(buf2+foundlength)=0;
         // remove any trailing CR/LF...
         stripCRLF(buf2);
         // Move the rest of the stored information to the front of the buffer...
         for ( i=foundlength ; i<storedsize ; i++ ) {
            buffer[i-foundlength] = buffer[i];
         }
         // Fix the 'storedsize' variable...
         storedsize -= foundlength;
         // Return the new string...
         if (debug) {
            msg = new char[strlen(buf2)+8];
            sprintf(msg, "<<<< %s\n",buf2);
            logger("debug.log", msg, 0, 1);
            delete msg;
         }
         return (buf2);
      }

      // Get some more from the socket...
      // Make sure that there's room to receive at least 10000 bytes
      if ( allocsize-storedsize < 10000 ) buffer = (char *) realloc(buffer, storedsize+10000);

      bytes = recv(s, buffer+storedsize, allocsize-storedsize, 0);   // Don't overflow buffer space.
      if ( bytes == -1 ) {
         if ( BLOCKING_ERROR == comm_errno ) {
            Sleep(50);                           // 50ms pause to prevent racing
         } else {
            quit=1;
         }
      } else {
         if ( bytes>0 ) {
            time1 = time( NULL );                // Time of last reception.
            *(buffer+storedsize+bytes)=0;
            storedsize += bytes;
         }
      }
      if ( difftime( time( NULL ) , time1) > 15 ) {
//         log(logname, "Timeout.\n");
         quit=1;                                 // 15 second timeout.
      }
   }

   // Error of some sort.  Return whatever we have or a NULL string.
   if ( storedsize>0 ) {
      buf2 = new char[storedsize+2];
      strncpy(buf2, buffer, storedsize);
      *(buf2+storedsize)=0;
      storedsize=0;
      if (debug) {
         msg = new char[strlen(buf2)+8];
         printf("\n");
         sprintf(msg, "<<<< %s\n",buf2);
         logger("debug.log", msg, 0, 1);
         delete msg;
      }
      return buf2;
   } else {
      if (debug) logger("debug.log", "<<<< \n", 0, 1);
      return NULL;
   }
}

void stripCRLF(char * string) {
   if ((*string == 0x00) || (string==NULL)) return;
   if (*(string+strlen(string)-1) == 0x0A) *(string+strlen(string)-1)=0;
   if (*(string+strlen(string)-1) == 0x0D) *(string+strlen(string)-1)=0;
}

unsigned int inet_address(const char *host)
{
   unsigned int addr;
   struct hostent *hp;
   int host_alias_i=0;
   int host_alias=0;
   #ifdef UNIX
   extern int h_errno;
   #endif

   if ((int) (addr = inet_addr(host)) == -1) {

      hp = gethostbyname(host);
      if (!hp) {
         perror("gethostbyname");
         printf("gethostbyname(%s) generated error %d\n",host,
#ifdef WIN32
         WSAGetLastError());
#endif
#ifdef UNIX
         h_errno);
#endif
         return (-1);
      }
      for (host_alias_i=0;hp->h_addr_list[host_alias_i];host_alias_i++);
         host_alias = rand() % host_alias_i;

      memcpy((void *) &addr, (void *) hp->h_addr_list[host_alias], sizeof(addr));
   }

   return (addr);
}

int open_server(char * server, int port, char * email)
{
   static int on=1;
   SOCKET sock=-1;
   struct sockaddr_in sin;
   char * ptr;
   int quit;

   memset((void *) &sin, 0, sizeof(sin));

   sin.sin_family    = AF_INET;
   sin.sin_addr.s_addr  = inet_address( server );
   sin.sin_port      = htons( port );

#if 0
   printf("Opening %s (%s:%u.%u.%u.%u) \n",server,inet_name(sin.sin_addr.s_addr),
          (unsigned char) ((sin.sin_addr.s_addr      ) & 0xFF),
          (unsigned char) ((sin.sin_addr.s_addr >>  8) & 0xFF),
          (unsigned char) ((sin.sin_addr.s_addr >> 16) & 0xFF),
          (unsigned char) ((sin.sin_addr.s_addr >> 24) & 0xFF));
#endif

   sock = socket(AF_INET, SOCK_STREAM, 0);
#ifdef WIN32
   if ( sock == INVALID_SOCKET ) return (-1);
#else
   if ( sock < 0 ) return (-1);
#endif

   if ( setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0 ) {
      closesocket(sock);
      return (-1);
   }

   if ( connect(sock, (struct sockaddr *) &sin, sizeof(sin)) != 0 ) {
      closesocket(sock);
      return (-1);
   }

   /*
   * Put the socket into non-blocking mode and set keepalive
   */
   unsigned long optval = 1;
   if ( setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, (char*)&optval, sizeof(optval)) != 0 ) {
      perror("Warning: setsockopt(SO_KEEPALIVE) failed");
      return (-1);
   }

   optval = 1;
#ifdef WIN32
   if ( ioctlsocket(sock, FIONBIO, &optval) != 0 ) {
      log(logname,"Warning: Couldn't set non-blocking mode");
      return (-1);
   }
#else
   if ( fcntl(sock, F_SETFL, O_NONBLOCK ) == -1) {
      log(logname,"Warning: Couldn't set non-blocking mode");
      return (-1);
   }
#endif

   putstring(sock, "FROM ");
   putstring(sock, email);
   putstring(sock, "\n");

   // Attempt to get upstream greeting if possible...
   // Store it into the global "upstreamgreeting" character string.
   // If the server understands this command, then it sends a series of greeting strings, followed by an "OK." string.
   putstring(sock, "GETGREETING\n");
   ptr = getstring(sock);
   quit=0;
	if (ptr == NULL) {
		quit=1;
	} else if (strlen(ptr) == 0) {
      quit=1;
   } else {
      strcpy(upstreamgreeting, "");
      if (ptr[0] != '?') {
         while ((!quit) && (strncmp(ptr, "OK.", 3) != 0)) {
            stripCRLF(ptr);
            strcat(upstreamgreeting, ptr);
            strcat(upstreamgreeting, "\n");
            if (ptr!=NULL) free(ptr);
            ptr = getstring(sock);
				if (ptr == NULL) {
					quit=1;
				} else if (strlen(ptr) == 0) {
					quit=1;
				}
         }
      }
		if (ptr!=NULL) free(ptr);
   }
   
   if (quit) {
      getstring(-1);
      closesocket(sock);
      return(-1);
   }
   return (sock);
}

void getb1andfacinfo(ecm_list * ecmlist, int noremove, int s, int k) {
   char * details;
   char * tempstring;
   char * name;
   int i;

   // Note that this does all the putstrings before any getstrings, in a somewhat feeble
   // attempt to shorten network latency slowdowns...

   for (i = 0 ; i < ecmlist->get_number_of_numbers(); i++) {
      if (ecmlist->is_active(i+1) || ecmlist->hasnewinfo(i+1) || (i+1 == k) ) {
         name = ecmlist->get_number_shortname(i+1);
         putstring(s, "GETB1DET ");
         putstring(s, name);
         putstring(s, "\n");
         // Also, pick up any factor information...
         putstring(s, "GETFAC ");
         putstring(s, name);
         putstring(s, "\n");
      }
   }

   for (i = 0 ; i < ecmlist->get_number_of_numbers(); i++) {
      if (ecmlist->is_active(i+1) || ecmlist->hasnewinfo(i+1) || (i+1 == k) ) {
         name = ecmlist->get_number_shortname(i+1);

         // Get the B1 detail information back from the server...
         details = getstring(s);
			if (details == NULL) {
			} else if (strlen(details)==0) {
			} else {
            // Be careful...It's possible that the upstream server has no information on this number.
            // In this case, don't overwrite our information for it.
            if (details[0] == ' ') ecmlist->set_allb1info( i+1 , details );
         }
         if (details!=NULL) free(details);
			details=getstring(s);
         if (details!=NULL) free ( details ); // Get the "OK" and throw it away.

         // Get the factor information back from the server...
         int done=0;
         while (!done) {
            details = getstring(s);
				if (details==NULL) {
					done=1;
				} else if (strlen(details)==0) {
					done=1;
				} else {
               if (details[0] == ' ') {
                  if (ecmlist->set_facinfo( i+1 , details , noremove)) {
                     tempstring = new char[100+strlen(name)];
                     sprintf(tempstring, "Server sent factor of %s\n",name);
                     log(logname,tempstring);
                     delete tempstring;
                  }
               }
               if ( strncmp(details, "OK.", 3) == 0 ) done=1;
            }
            if (details!=NULL) free(details);
         }
      }
   } // for
}

int returnwork(int s, ecm_list * ecmlist, int closesocketflag, int noremove)
{
   // Send our new b1 information to the server, then get all its b1 information
   // for the relevant numbers.
   // Returns -1 on error, or if non-negative, then the number of curves accepted by server.

   char * buf2;
   int foundcount=0;
   double b1;
   int curves,j;
   char * name;
   char * number;
   char * factor;
   char * finder;
   int socket_down=0;
   char * tempstring;
   int i;

   for (i = 0 ; (!socket_down) && (i < ecmlist->get_number_of_numbers()); i++) {

      name   = ecmlist->get_number_shortname(i+1);
      number = ecmlist->get_number_base10rep(i+1);

      // Check if any new B1 information to upload...
      ecmlist->UnsetNewinfo(i+1);
      for (j=0 ; (!socket_down) && (j < ecmlist->get_number_of_b1details(i+1)) ; j++) {

         b1     = ecmlist->get_number_b1details_b1(i+1,j);
         curves = ecmlist->get_number_b1details_curves_for_upstream(i+1,j);

         if ((curves != 0) && (!socket_down)) {
            ecmlist->SetNewinfo(i+1);

            tempstring = new char[200+strlen(name)];
            sprintf(tempstring,"Uploading %d curves for %s (B1=%.0lf)\n", curves,name, b1);
            log(logname, tempstring);
            delete tempstring;
            fflush(stdout);

            putstring(s, "RETURNWORK\n");

            putstring(s, "return_ECMname: ");
            putstring(s, name);
            putstring(s, "\nreturn_ECMnumber: ");
            putstring(s, number);
            putstring(s, "\n");

            tempstring = new char[200];
            sprintf(tempstring, "return_B1: %.0lf\nreturn_Curves: %d\n",b1,curves);
            putstring(s, tempstring);
            delete tempstring;

            buf2 = getstring(s);
				if (buf2==NULL) {
					buf2 = new char[52];
               strcpy(buf2, "ERR: Connection lost");
               socket_down=1;
				} else if (strlen(buf2)==0) {
               buf2 = (char *) realloc(buf2, 50);
               strcpy(buf2, "ERR: Connection lost");
               socket_down=1;
            } else if ( strncmp(buf2, "OK.", 3) == 0 ) {
//               tempstring = new char[250];
//               sprintf(tempstring,"%d curves for %s (B1=%.0lf) accepted.\n",curves,name,b1);
//               log(logname, tempstring);
//               delete tempstring;

               ecmlist->Add_to_b1details(name, number, b1, 0, 0, -curves);
               foundcount += curves;
            } else {
               tempstring = new char[strlen(buf2)+2];
               strcpy(tempstring, buf2);
               strcat(tempstring, "\n");
               log(logname, tempstring);
               delete tempstring;
               if ( strncmp(buf2, "INFO", 4) == 0)
                  ecmlist->Add_to_b1details(name, number, b1, 0, 0, -curves);
            }
            if (buf2!=NULL) free(buf2);
         }
      } // Done checking for new B1 information

      // Check for any factors that need upload...
      for (j=0 ; (!socket_down) && (j < ecmlist->get_number_of_factors(i+1)) ; j++) {
         if ((ecmlist->get_factor_details_needs_upstream(i+1, j) > 0) && (!socket_down)) {
            ecmlist->SetNewinfo(i+1);

            factor=ecmlist->get_factor_details_factor(i+1, j);
            finder=ecmlist->get_factor_details_finder(i+1, j);

            tempstring = new char[200+strlen(name)+strlen(factor)];
            sprintf(tempstring, "Uploading factor for %s: %s\n",name,factor);
            log(logname, tempstring);
            delete tempstring;
            fflush(stdout);

            putstring(s, "RETURNFACTOR\n");
            putstring(s, "factor_ECMname: ");
            putstring(s, name);
            putstring(s, "\nfactor_ECMnumber: ");
            putstring(s, number);
            putstring(s, "\nfactor_FACTOR: ");
            putstring(s, factor);
            putstring(s, "\nfactor_FINDER: ");
            putstring(s, finder);
            putstring(s, "\n");

            tempstring = new char[200];
            sprintf(tempstring, "factor_B1: %.0lf\n",ecmlist->get_factor_details_b1level(i+1, j) );
            putstring(s, tempstring);
            sprintf(tempstring, "factor_sigma: %.0lf\n",ecmlist->get_factor_details_sigma(i+1, j) );
            putstring(s, tempstring);
            delete tempstring;

            buf2 = getstring(s);
				if (buf2==NULL) {
					buf2 = new char[52];
               strcpy(buf2, "ERR: Connection dropped.");
               socket_down=1;
				} else if (strlen(buf2)==0) {
               buf2 = (char *) realloc(buf2, 50);
               strcpy(buf2, "ERR: Connection dropped.");
               socket_down=1;
            } else if ( strncmp(buf2, "OK.", 3) == 0 ) {
               tempstring = new char[200+strlen(name)+strlen(factor)];
               sprintf(tempstring, "Factor of %s was accepted: %s\n",name, factor);
               log(logname, tempstring);
               delete tempstring;
               ecmlist->set_factor_details_needs_upstream(i+1, j, 0);
            } else {
               tempstring=new char[strlen(buf2)+2];
               strcpy(tempstring, buf2);
               strcat(tempstring, "\n");
               log(logname, tempstring);
               delete tempstring;

               if ( strncmp(buf2, "INFO: ",6) == 0 )
                  ecmlist->set_factor_details_needs_upstream(i+1, j, 0);
            }
            if (buf2 != NULL) free(buf2);
         }
      } // Done checking for new factors to upload
   } // for

   // Get b1/fac information from server for all actives or flagged (hasnewinfo()) #s...
   if (!socket_down) {
      getb1andfacinfo(ecmlist, noremove, s, 0);
   }

   // Echo to screen status of any numbers we sent information to main server for...
   for (i = 0 ; i < ecmlist->get_number_of_numbers(); i++) {
      if ( ecmlist->hasnewinfo( i+1 ) ) {
         name = ecmlist->get_number_shortname(i+1);
         tempstring = new char[strlen(name)+500];
         sprintf(tempstring, "(Upstream) %s: Sum(B1): %.0lf  Work: %.0lf\n",
                 name,
                 ecmlist->get_sumb1(i+1),
                 ecmlist->get_work(i+1));
         log(logname, tempstring);
         delete tempstring;
         ecmlist->UnsetNewinfo(i+1);
      }
   } // for

   if (closesocketflag) {
      if (!socket_down) putstring(s, "QUIT\n");
      closesocket(s);
      getstring(-1);                             // Reset any partial pre-read information in buffer.
   }

   if (socket_down) return (-1); // Signal that error occurred by returning -1.

   return (foundcount);
}

char * nextword(char * ptr) {
   // Return the word pointed to by ptr (delimited by space or colon or EOL)
   // The calling function is responsible for deleting the string returned.
   char * ptr2;
   char * tempstring;
   char x;

   ptr2=ptr;
   while ( ((*ptr2)!= ' ') && ((*ptr2)!= ':') && ((*ptr2)!=0) ) ptr2++;

   tempstring = new char[ptr2-ptr+1];
   x=*ptr2;
   *ptr2=0;
   strcpy(tempstring, ptr);
   *ptr2=x;

   return tempstring;
}

