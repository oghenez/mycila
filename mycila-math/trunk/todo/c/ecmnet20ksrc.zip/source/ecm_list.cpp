/*
  ecm_list -- a component of ecmserver

  Revision history:
  September 9, 1998 Original creation by Tim Charron <tcharron@interlog.com>
  September 20 1998 Version 1.1 Tim Charron
  Oct 9 1998 Added get_work and get_sumb1
  Oct 20 1998 Fixed bug in 'newnumber' that wasn't freeing memory properly
  Oct 26 1998 Changed 2900000*5250 to 3000000*5100 curves in ecm_list::get_bestb1
  Oct 27 1998 version 1.9b Fixed bug when server sends 'down' a new factor -- sigma info was being lost.
  Oct 28 1998 get_sumb1 now returns the better of upstream server totals, or downstream totals.
              Corrected minor bug in get_bestb1
  Nov 9 1998 Fixed bug in newnumber that was causing 'sourcename's b1 information to not be copied
             to the new number.
  Nov 10 1998 version 2.0c - Added ability to sort INI file by name, b1, sum(b1), work, len(composite)
  Nov 27 1998 version 2.0f - Fixed bug in is_LocalControl -- it was getting the local control
                             status of the NEXT number in the list.

The most recent version of this source is available from http://www.interlog.com/~tcharron/ecm.html

*/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <memory.h>
#include <string.h>

#include "ecm_list.h"
extern char * nextword(char *); // in common.cpp, but common.h references ecm_list.h.

void switchnumbers(number_to_factor * number1, number_to_factor * number2);

ecm_list::ecm_list()
{
   number_of_numbers = 0;
   changes=0;
   changethreshold=1;
   ecmfilename[0]=0;

   // 0=no sorting
   // 1=sort by name
   // 2=sort by b1
   // 3=sort by sum(b1)
   // 4=sort by work
   // 5=sort by length(composite)
   sorttype=4; // Sort by work by default

}

// Destructor.  Note that name/strings which were allocated are freed here as well.
ecm_list::~ecm_list()
{
   while ( number_of_numbers > 0 ) {
      free(numbers_to_factor[number_of_numbers-1].shortname);
      free(numbers_to_factor[number_of_numbers-1].base10rep);
      free(numbers_to_factor[number_of_numbers-1].b1_details);
      for (int j=0 ; j<numbers_to_factor[number_of_numbers-1].factor_details_number ; j++) {
         free(numbers_to_factor[number_of_numbers-1].factor_details[j].factor);
         free(numbers_to_factor[number_of_numbers-1].factor_details[j].fromname);
      }
      free(numbers_to_factor[number_of_numbers-1].factor_details);
      free(&numbers_to_factor[number_of_numbers-1]);
      number_of_numbers--;
   }
}

// Methods to get relevant number details...
int ecm_list::get_number_of_active() {
   int ret=0;
   for (int i=0 ; i<number_of_numbers ; i++) ret += numbers_to_factor[i].activeflag;
   return ret;
}

int ecm_list::get_number_of_numbers() {
   return (number_of_numbers);
}

char * ecm_list::get_number_shortname(int k) {
   return (numbers_to_factor[k-1].shortname);
}

char * ecm_list::get_number_base10rep(char * name) {
   int i = get_index(name);
   if (i!=0) return get_number_base10rep(i);
   return NULL;
}

char * ecm_list::get_number_base10rep(int k) {
   return (numbers_to_factor[k-1].base10rep);
}

int ecm_list::is_active( char * name) {
   int i = get_index(name);
   if (i!=0) return is_active(i);
   return 0;
}
int ecm_list::is_active( int k ) {
   return (numbers_to_factor[k-1].activeflag);
}
int ecm_list::hasnewinfo( int k ) {
   return (numbers_to_factor[k-1].newinfoflag);
}
int ecm_list::is_LocalControl( char * name ) {
   int i = get_index(name);
   if (i!=0) return numbers_to_factor[i-1].LocalControl;
   return 0;
}
int ecm_list::is_LocalControl( int k ) {
   return numbers_to_factor[k-1].LocalControl;
}

int ecm_list::get_number_of_b1details(int k) {
   return numbers_to_factor[k-1].b1_details_number;
}

double ecm_list::get_number_b1details_b1(int k, int i) {
   return numbers_to_factor[k-1].b1_details[i].b1;
}

int ecm_list::get_number_b1details_curves(int k, int i) {
   return numbers_to_factor[k-1].b1_details[i].curvecount;
}

int ecm_list::get_number_b1details_curves_from_downstream(int k, int i) {
   return numbers_to_factor[k-1].b1_details[i].curvecount_from_downstream;
}

int ecm_list::get_number_b1details_curves_for_upstream(int k, int i) {
   return numbers_to_factor[k-1].b1_details[i].curvecount_for_upstream;
}

int ecm_list::get_number_b1details(char * name, double b1) {
   int i = get_index(name);
   if (i!=0) get_number_b1details(i, b1);
   return 0;
}

int ecm_list::get_number_b1details(int k, double b1) {
   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      if ( b1 == numbers_to_factor[k-1].b1_details[i].b1 ) {
         return (numbers_to_factor[k-1].b1_details[i].curvecount);
      }
   }
   return (0);
}

int ecm_list::get_number_of_factors(int k) {
   return numbers_to_factor[k-1].factor_details_number;
}

char * ecm_list::get_factor_details_factor(int k, int i) {
   return numbers_to_factor[k-1].factor_details[i].factor;
}

char * ecm_list::get_factor_details_finder(int k, int i) {
   return numbers_to_factor[k-1].factor_details[i].fromname;
}

double ecm_list::get_factor_details_b1level(int k, int i) {
   return numbers_to_factor[k-1].factor_details[i].b1level;
}

double ecm_list::get_factor_details_sigma(int k, int i) {
   return numbers_to_factor[k-1].factor_details[i].sigma;
}

int ecm_list::get_factor_details_needs_upstream(int k, int i) {
   return numbers_to_factor[k-1].factor_details[i].needs_upstream;
}
void ecm_list::set_factor_details_needs_upstream(int k, int i, int value) {
   numbers_to_factor[k-1].factor_details[i].needs_upstream = value;
}

int ecm_list::get_index_base10( char * number ) {
   for ( int i=0 ; i<number_of_numbers ; i++ ) {
      if ( strcmp(numbers_to_factor[i].base10rep,number)==0 )
         return (i+1);
   }
   return (0);
}

int ecm_list::get_index( char * name ) {
   for ( int i=0 ; i<number_of_numbers ; i++ ) {
      if ( strcmp(numbers_to_factor[i].shortname,name)==0 )
         return (i+1);
   }
   return (0);
}

int ecm_list::Add_Factor(char * name, char * number, char * factor, int noremove, char * fromname,
                         double b1level, double sigma) {
   return Add_Factor(name, number, factor, noremove, fromname, b1level, sigma, (int) 1);
}
int ecm_list::Add_Factor(int k, char * factor, int noremove, char * fromname,
                         double b1level, double sigma) {
   return Add_Factor(k, factor, noremove, fromname, b1level, sigma, (int) 1);
}

int ecm_list::Add_Factor(char * name, char * number, char * factor, int noremove, char * fromname,
                         double b1level, double sigma, int factor_needs_upstream) {
   if ( get_index(name) == 0) StoreDetails( name, number );
   return Add_Factor( get_index(name), factor, noremove, fromname, b1level, sigma, factor_needs_upstream);
}
int ecm_list::Add_Factor(int k, char * factor, int noremove, char * fromname,
                         double b1level, double sigma, int factor_needs_upstream) {
   char * word1;
   char * word2;

   for ( int i=0 ; i<numbers_to_factor[k-1].factor_details_number ; i++ ) {
      word1=nextword(factor);
      word2=nextword(numbers_to_factor[k-1].factor_details[i].factor);
      if ( strcmp(word1, word2 ) == 0) {
         free(word1);
         free(word2);
         return 0;
      }
      free(word1);
      free(word2);
   }

   numbers_to_factor[k-1].factor_details_number ++;
   int c = numbers_to_factor[k-1].factor_details_number;
   numbers_to_factor[k-1].factor_details = (factor_detail *) realloc(
                                                            numbers_to_factor[k-1].factor_details,
                                                            c * sizeof(factor_detail));
   numbers_to_factor[k-1].factor_details[c-1].factor   = (char *) malloc(strlen(factor)+2);
   strcpy(numbers_to_factor[k-1].factor_details[c-1].factor , factor);
   numbers_to_factor[k-1].factor_details[c-1].b1level  = b1level;
   numbers_to_factor[k-1].factor_details[c-1].sigma          = sigma;
   numbers_to_factor[k-1].factor_details[c-1].needs_upstream = factor_needs_upstream;
   numbers_to_factor[k-1].factor_details[c-1].fromname = (char *) malloc(strlen(fromname)+2);
   strcpy(numbers_to_factor[k-1].factor_details[c-1].fromname, fromname);

   if (!noremove) SetInActive( k );

   changes++;
   return (1);
}

int ecm_list::Add_to_b1details(char * name, char * number, double b1, int curves) {
   return Add_to_b1details(name, number, b1, curves, curves, curves);
}
int ecm_list::Add_to_b1details(int k, double b1, int curves) {
   return Add_to_b1details(k, b1, curves, curves, curves);
}

int ecm_list::Add_to_b1details(char * name, char * number, double b1, int curves,
                               int curves_from_downstream, int curves_for_upload) {
   if ( get_index(name) == 0 ) StoreDetails( name , number );
   return (Add_to_b1details( get_index(name), b1, curves,
                             curves_from_downstream, curves_for_upload));
}
int ecm_list::Add_to_b1details(int k, double b1, int curves,
                               int curves_from_downstream, int curves_for_upload) {
   int c;

   if (b1 <= 0.0) return 0;

   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      if ( b1 == numbers_to_factor[k-1].b1_details[i].b1 ) {
         changes++;
         numbers_to_factor[k-1].b1_details[i].curvecount                 += curves;
         numbers_to_factor[k-1].b1_details[i].curvecount_from_downstream += curves_from_downstream;
         numbers_to_factor[k-1].b1_details[i].curvecount_for_upstream    += curves_for_upload;
         return (numbers_to_factor[k-1].b1_details[i].curvecount);
      }
   }

   numbers_to_factor[k-1].b1_details_number ++;
   c = numbers_to_factor[k-1].b1_details_number;
   numbers_to_factor[k-1].b1_details = (b1_curves *) realloc(
                                                            numbers_to_factor[k-1].b1_details,
                                                            c * sizeof(b1_curves));
   numbers_to_factor[k-1].b1_details[c-1].b1         = b1 ;
   numbers_to_factor[k-1].b1_details[c-1].curvecount                 = curves ;
   numbers_to_factor[k-1].b1_details[c-1].curvecount_from_downstream = curves_from_downstream;
   numbers_to_factor[k-1].b1_details[c-1].curvecount_for_upstream    = curves_for_upload ;
   changes++;
   return curves;
}


// Misc. methods to print out the number details...
void ecm_list::printnumberlist() {
   printnumberlist(stdout);
}
void ecm_list::printnumberlist(int skipbase10flag) {
   printnumberlist(stdout, skipbase10flag);
}

void ecm_list::printnumberlist(FILE * fp) {
   printnumberlist(fp, 0);
}
void ecm_list::printnumberlist(FILE * fp, int skipbase10flag) {
   fprintf(fp, "%d numbers are stored:\n",number_of_numbers);
   fflush(fp);
   for ( int j=1 ; j<=number_of_numbers ; j++ ) printnumber(fp, j, skipbase10flag);
}

void ecm_list::sortme() {
   // Bubble sort will work fine since the list is already nearly perfectly sorted.
   int ok=0;

   // 0=no sorting
   // 1=sort by name
   // 2=sort by b1
   // 3=sort by sum(b1)
   // 4=sort by work
   // 5=sort by length(composite)
   if (sorttype == 0) {
      return;
   } else if (sorttype == 1) {
      while (!ok) {
         ok=1;
         for (int i=0 ; i<number_of_numbers-1 ; i++) {
            if (strcmp(get_number_shortname(i+1),get_number_shortname(i+2)) > 0) {
               switchnumbers(&numbers_to_factor[i], &numbers_to_factor[i+1]);
               ok=0;
            }
         } // for
      } // while
   } else if (sorttype == 2) {
      while (!ok) {
         ok=1;
         for (int i=0 ; i<number_of_numbers-1 ; i++) {
            if (get_bestb1(i+1) < get_bestb1(i+2)) {
               switchnumbers(&numbers_to_factor[i], &numbers_to_factor[i+1]);
               ok=0;
            }
         } // for
      } // while
   } else if (sorttype == 3) {
      while (!ok) {
         ok=1;
         for (int i=0 ; i<number_of_numbers-1 ; i++) {
            if (get_sumb1(i+1) < get_sumb1(i+2)) {
               switchnumbers(&numbers_to_factor[i], &numbers_to_factor[i+1]);
               ok=0;
            }
         } // for
      } // while
   } else if (sorttype == 4) {
      while (!ok) {
         ok=1;
         for (int i=0 ; i<number_of_numbers-1 ; i++) {
            if (get_work(i+1) < get_work(i+2)) {
               switchnumbers(&numbers_to_factor[i], &numbers_to_factor[i+1]);
               ok=0;
            }
         } // for
      } // while
   } else if (sorttype == 5) {
      while (!ok) {
         ok=1;
         for (int i=0 ; i<number_of_numbers-1 ; i++) {
            if (strlen(get_number_base10rep(i+1)) < strlen(get_number_base10rep(i+2))) {
               switchnumbers(&numbers_to_factor[i], &numbers_to_factor[i+1]);
               ok=0;
            }
         } // for
      } // while
   }
}

void ecm_list::printnumber(int k) {
   printnumber(k, 0);
}
void ecm_list::printnumber(int k, int skipbase10flag) {
   printnumber(stdout, k, skipbase10flag);
   return;
}

void ecm_list::printnumber(FILE * fp, int k) {
   printnumber(fp, k, 0);
}
void ecm_list::printnumber(FILE * fp, int k, int skipbase10flag) {
   double totalB1=0;

   fprintf(fp, "# %d...%s (%s):", k, numbers_to_factor[k-1].shortname,
           (numbers_to_factor[k-1].activeflag?"Active":"Not Active") );
   if (numbers_to_factor[k-1].LocalControl && numbers_to_factor[k-1].activeflag) {
      fprintf(fp, " (local control)");
   }
   if ( skipbase10flag ) {
      fprintf(fp, "   _n%d\n",strlen(numbers_to_factor[k-1].base10rep));
   } else {
      fprintf(fp, "\n         %s\n",numbers_to_factor[k-1].base10rep);
   }

   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      if ( numbers_to_factor[k-1].b1_details[i].b1 != 0. ) {
         printf("   b1: %.0lf  %d (downstream: %d) (need upload: %d)\n",
                numbers_to_factor[k-1].b1_details[i].b1,
                numbers_to_factor[k-1].b1_details[i].curvecount,
                numbers_to_factor[k-1].b1_details[i].curvecount_from_downstream,
                numbers_to_factor[k-1].b1_details[i].curvecount_for_upstream);
         totalB1 += numbers_to_factor[k-1].b1_details[i].b1 *
                    numbers_to_factor[k-1].b1_details[i].curvecount;
      }
   }
   printf("   sum(b1): %.0lf\n",totalB1);

   if (numbers_to_factor[k-1].factor_details_number == 0) {
      printf("   No known factors.\n");
   } else {
      for ( int i=0 ; i<numbers_to_factor[k-1].factor_details_number ; i++ ) {
         printf("   Factor: %s\n   Finder: %s  B1: %.0lf  sigma: %.0lf  needs_upload: %d\n",
                numbers_to_factor[k-1].factor_details[i].factor,
                numbers_to_factor[k-1].factor_details[i].fromname,
                numbers_to_factor[k-1].factor_details[i].b1level,
                numbers_to_factor[k-1].factor_details[i].sigma,
                numbers_to_factor[k-1].factor_details[i].needs_upstream);
      }
   }
}

void ecm_list::get_activeinfo(char * buffer) {
   strcpy(buffer, "");
   for (int i=0 ; i<number_of_numbers ; i++) {
      if (numbers_to_factor[i].activeflag) {
         strcat(buffer, " ");
         strcat(buffer, numbers_to_factor[i].shortname);
      }
   }
}

char * ecm_list::get_allb1info(char * shortname) {
   char * buffer;

   int k=get_index(shortname);
   if (k == 0) {
      buffer = new char[1];
      *buffer=0;
      return buffer;
   }
   return get_allb1info( k );
}

void ecm_list::set_allb1info(int k, char * buffer) {
   char * ptr1;
   char * ptr2;
   double b1level;
   int curves;

   if (buffer == NULL) return;
   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      numbers_to_factor[k-1].b1_details[i].curvecount = 0;
   }

   ptr1 = buffer;
   while (ptr1 != NULL) {
      b1level = atol(ptr1+1);
      ptr2 = strchr(ptr1+1, ' ');
      curves = atoi(ptr2+1);
      Add_to_b1details(k, b1level, curves, 0, 0);
      ptr1 = strchr(ptr2+1, ' ');
   }
   changes++;
   return;
}

char * ecm_list::get_allb1info(int k) {
   char * buffer;
   char tempstring[240];

   buffer = new char[1];
   *buffer=0; // Ensure we're starting with an empty string.

   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      sprintf(tempstring," %.0lf %d",
              numbers_to_factor[k-1].b1_details[i].b1,
              numbers_to_factor[k-1].b1_details[i].curvecount);
      buffer = (char *) realloc(buffer, strlen(buffer)+strlen(tempstring)+2);
      strcat(buffer, tempstring);
   }
   return buffer;
}

char * ecm_list::get_facinfo( char * shortname, int whichfactor ) {
   char * buffer;

   int k = get_index( shortname );
   if (k==0) {
      buffer = new char[1];
      *buffer=0;
      return buffer;
   }
   return get_facinfo( k, whichfactor );
}

char * ecm_list::get_facinfo( int k, int whichfactor) {
   char * buffer;
   char * word1;

   word1 = numbers_to_factor[k-1].factor_details[whichfactor].factor;
   buffer = new char[strlen(word1)
                  +strlen(numbers_to_factor[k-1].factor_details[whichfactor].fromname)
                  +250]; // 250 is for spaces, plus b1level and sigma.

   sprintf(buffer, " %s %s %.0lf %.0lf",
          word1,
          numbers_to_factor[k-1].factor_details[whichfactor].fromname,
          numbers_to_factor[k-1].factor_details[whichfactor].b1level,
          numbers_to_factor[k-1].factor_details[whichfactor].sigma);
   return buffer;
}

int ecm_list::set_facinfo( int k, char * buffer , int noremove) {
   char * ptr;
   char * factorptr;
   char * fromnameptr;
   char * b1levelptr;
   char * sigmaptr;
   double b1level, sigma;

   factorptr = buffer+1;
   ptr = strchr(factorptr, ' ');
   if (ptr == NULL) return 0;
   *ptr=0;

   fromnameptr=ptr+1;
   ptr = strchr(fromnameptr, ' ');
   if (ptr == NULL) return 0;
   *ptr=0;

   b1levelptr=ptr+1;
   ptr = strchr(b1levelptr, ' ');
   if (ptr == NULL) return 0;
   *ptr=0;

   sigmaptr = ptr+1;
   b1level = atol(b1levelptr);
   sigma = atol(sigmaptr);

   return Add_Factor( k, factorptr, noremove, fromnameptr, b1level, sigma, 0);
}

double ecm_list::get_bestb1(int k) {
   int maxncurves;
   return get_bestb1(k, &maxncurves);
}

double ecm_list::get_bestb1(int k, int * maxncurves) {
   double totalB1=0.;

   totalB1 = 1000. * get_sumb1(k);

/*
  10        300   8
  15       2000   25
  20      11000   90
  25      50000   300
  30     250000   700
  35    1000000   1800
  40    3000000   5100    Changed Oct 26, 1998 from "40    2900000   5250"
  45   11000000   10600
  50   43000000   19300
  55  110000000   49000
  60  260000000   124000
  65  850000000   210000
  70 2900000000   340000
  75 9900000000   550000
*/
   if ( totalB1 <        300. * 8      ) {*maxncurves =       9 - totalB1/300.       ; return (300.);     }
   totalB1 -=            300. * 8 ;
   if ( totalB1 <       2000. * 25     ) {*maxncurves =      26 - totalB1/2000.      ; return (2000.);     }
   totalB1 -=           2000. * 25;
   if ( totalB1 <      11000. * 90     ) {*maxncurves =      91 - totalB1/11000.     ; return (11000.);     }
   totalB1 -=          11000. * 90;
   if ( totalB1 <      50000. * 300    ) {*maxncurves =     301 - totalB1/50000.     ; return (50000.);     }
   totalB1 -=          50000. * 300;
   if ( totalB1 <     250000. * 700    ) {*maxncurves =     701 - totalB1/250000.    ; return (250000.);    }
   totalB1 -=         250000. * 700;
   if ( totalB1 <    1000000. * 1800   ) {*maxncurves =    1801 - totalB1/1000000.   ; return (1000000.);   }
   totalB1 -=        1000000. * 1800;
// if ( totalB1 <    2900000. * 5250   ) {*maxncurves =    5251 - totalB1/2900000.   ; return (2900000.);   }
// totalB1 -=        2900000. * 5250;
   if ( totalB1 <    3000000. * 5100   ) {*maxncurves =    5101 - totalB1/3000000.   ; return (3000000.);   }
   totalB1 -=        3000000. * 5100;
   if ( totalB1 <   11000000. * 10600  ) {*maxncurves =   10601 - totalB1/11000000.  ; return (11000000.);  }
   totalB1 -=       11000000. * 10600;
   if ( totalB1 <   43000000. * 19300  ) {*maxncurves =   19301 - totalB1/43000000.  ; return (43000000.);  }
   totalB1 -=       43000000. * 19300;
   if ( totalB1 <  110000000. * 49000  ) {*maxncurves =   49001 - totalB1/110000000. ; return (110000000.); }
   totalB1 -=      110000000. * 49000;
   if ( totalB1 <  260000000. * 124000 ) {*maxncurves =  124001 - totalB1/260000000. ; return (260000000.); }
   totalB1 -=      260000000. * 124000;
   if ( totalB1 <  850000000. * 210000 ) {*maxncurves =  210001 - totalB1/850000000. ; return (850000000.); }
   totalB1 -=      850000000. * 210000;
   if ( totalB1 < 2900000000. * 340000 ) {*maxncurves =  340001 - totalB1/2900000000.; return (2900000000.);}
   totalB1 -=     2900000000. * 340000;
   *maxncurves = 0;
   return (9900000000.);
/* For ecm-gmp 3, this list is a bit different.
This is a current 'best guess' by Zimmermann...
update: Oct 26, 1998.  Paul suggests that this is 'wrong' and not to use it.
      20      11000    60
      25      50000    200
      30     250000    450
      35    1000000    1100
      40    3000000    3000
      45   11000000    5900
      50   43000000   10300
      55  110000000   26400
      60  260000000   67000
      65  850000000  116000
      70 2900000000  185000
      75 9900000000  ?????? (unchanged)
*/
}

double ecm_list::get_sumb1(int k) {
   double totalB1=0.;
   double totalB1downstream=0.;
   for ( int i=0 ; i<numbers_to_factor[k-1].b1_details_number ; i++ ) {
      totalB1 += numbers_to_factor[k-1].b1_details[i].b1
                 * numbers_to_factor[k-1].b1_details[i].curvecount
                 / 1000.;
      totalB1downstream += numbers_to_factor[k-1].b1_details[i].b1
                 * numbers_to_factor[k-1].b1_details[i].curvecount_from_downstream
                 / 1000.;
   }
   return max(totalB1,totalB1downstream);;
}

double ecm_list::get_work(int k) {
   int len = strlen(numbers_to_factor[k-1].base10rep);
//printf("k:%d len:%d ",k,len);fflush(stdout);
//printf("sumb1: %.0lf ",get_sumb1(k));fflush(stdout);
//printf("work: %.0lf\n",get_sumb1(k)*len*len/1000.);fflush(stdout);
   return get_sumb1(k) * len*len / 1000.;
}

void ecm_list::SetActive(char * shortname ) {
   int i = get_index(shortname);
   if (i != 0) SetActive( i );
}
void ecm_list::SetActive( int k ) {
   numbers_to_factor[k-1].activeflag = 1;
   changes++;
}
void ecm_list::SetNewinfo( int k ) {
   numbers_to_factor[k-1].newinfoflag = 1;
}
void ecm_list::SetLocalControl( char * shortname ) {
   int i = get_index(shortname);
   if (i != 0) SetLocalControl(i);
}
void ecm_list::SetLocalControl( int k ) {
   numbers_to_factor[k-1].LocalControl=1;
   changes++;
}
void ecm_list::UnsetLocalControl( int k ) {
   numbers_to_factor[k-1].LocalControl=0;
   changes++;
}

void ecm_list::SetInActiveAll() {
   for (int i=0 ; i<number_of_numbers ; i++) {
      numbers_to_factor[i].activeflag = 0;
   }
   changes++;
}

void ecm_list::SetInActive(char * shortname ) {
   int i = get_index(shortname);
   if (i != 0) SetInActive( i );
}
void ecm_list::SetInActive( int k ) {
   numbers_to_factor[k-1].activeflag = 0;
   changes++;
}
void ecm_list::UnsetNewinfo( int k ) {
   numbers_to_factor[k-1].newinfoflag = 0;
}

// Method to store a new ecm number...
void ecm_list::StoreDetails( char * shortname, char * base10rep ) {

   // Make room for the new number description...
   number_of_numbers++;
   if ( number_of_numbers == 1 ) {
      numbers_to_factor = new number_to_factor;
   } else {
      numbers_to_factor = (number_to_factor * ) realloc( numbers_to_factor ,
                                                         number_of_numbers * sizeof(number_to_factor) );
   }
   // Store the starting values...
   numbers_to_factor[number_of_numbers-1].shortname = new char[ strlen(shortname) + 1 ];
   numbers_to_factor[number_of_numbers-1].base10rep = new char[ strlen(base10rep) + 1 ];
   numbers_to_factor[number_of_numbers-1].b1_details_number=0;
   numbers_to_factor[number_of_numbers-1].b1_details = new b1_curves;
   numbers_to_factor[number_of_numbers-1].factor_details_number=0;
   numbers_to_factor[number_of_numbers-1].factor_details = new factor_detail;
   numbers_to_factor[number_of_numbers-1].activeflag=0;
   numbers_to_factor[number_of_numbers-1].LocalControl=0;
   numbers_to_factor[number_of_numbers-1].newinfoflag=0;

   strcpy( numbers_to_factor[number_of_numbers-1].shortname, shortname );
   strcpy( numbers_to_factor[number_of_numbers-1].base10rep, base10rep );
   numbers_to_factor[number_of_numbers-1].b1_details[0].b1         = 0. ;
   numbers_to_factor[number_of_numbers-1].b1_details[0].curvecount                 = 0 ;
   numbers_to_factor[number_of_numbers-1].b1_details[0].curvecount_from_downstream = 0 ;
   numbers_to_factor[number_of_numbers-1].b1_details[0].curvecount_for_upstream    = 0 ;
   numbers_to_factor[number_of_numbers-1].factor_details[0].factor   = NULL ;
   numbers_to_factor[number_of_numbers-1].factor_details[0].fromname = NULL ;
   numbers_to_factor[number_of_numbers-1].factor_details[0].b1level  = 0.0 ;
   numbers_to_factor[number_of_numbers-1].factor_details[0].sigma    = 0.0 ;
   numbers_to_factor[number_of_numbers-1].factor_details[0].needs_upstream=0;

//printf("X1: %s %s\n",shortname, base10rep);
//fflush(stdout);
   changes++;
}

void ecm_list::WriteDetails_as_required(char * name) {
   if ( changes >= changethreshold )  WriteDetails( name );
   return;
}

void ecm_list::WriteDetails_as_required() {
   if ( changes >= changethreshold )  WriteDetails( NULL );
   return;
}

int ecm_list::WriteDetails(char * name) {
   FILE *fp;
   int j;
   int newb1;

   if ( ( fp = fopen(ecmfilename, "wt")) == NULL ) {
      printf("Can't open file %s for writing.\n",ecmfilename);
      return (-1);
   }

   sortme(); // Keep sorted if required.

   for ( int i=0 ; i<number_of_numbers ; i++ ) {
      newb1 = 0;
      for ( j=0 ; j<numbers_to_factor[i].b1_details_number ; j++ ) {
         newb1 += numbers_to_factor[i].b1_details[j].curvecount_for_upstream;
      }
      if (   (name == NULL)
          || (strcmp(name, numbers_to_factor[i].shortname)==0)
          || (newb1>0)                                         ) {
         fprintf(fp, "%s N %s\n",
                 numbers_to_factor[i].shortname,
                 numbers_to_factor[i].base10rep);
         for ( j=0 ; j<numbers_to_factor[i].factor_details_number ; j++ ) {
            fprintf(fp, "%s F %s %s %.0lf %.0lf %d\n",
                    numbers_to_factor[i].shortname,
                    numbers_to_factor[i].factor_details[j].factor,
                    numbers_to_factor[i].factor_details[j].fromname,
                    numbers_to_factor[i].factor_details[j].b1level,
                    numbers_to_factor[i].factor_details[j].sigma,
                    numbers_to_factor[i].factor_details[j].needs_upstream);
         }
         if (numbers_to_factor[i].activeflag)
            fprintf(fp, "%s A\n",numbers_to_factor[i].shortname);
         if (numbers_to_factor[i].LocalControl)
            fprintf(fp, "%s L\n",numbers_to_factor[i].shortname);

         for ( j=0 ; j<numbers_to_factor[i].b1_details_number ; j++ ) {
            fprintf(fp, "%s B %.0lf %d %d %d\n",
                    numbers_to_factor[i].shortname,
                    numbers_to_factor[i].b1_details[j].b1,
                    numbers_to_factor[i].b1_details[j].curvecount,
                    numbers_to_factor[i].b1_details[j].curvecount_from_downstream,
                    numbers_to_factor[i].b1_details[j].curvecount_for_upstream);
         }
      }
   }
   fclose(fp);
   changes=0;  // # of unsaved changes in memory is now 0.
   return (0);
}

int ecm_list::LoadDetails(char * filename) {
   FILE * fp;
   char * line;
   char * ptr1;
   char * ptr2;
   char * ptr3;
   char * ptr4;
   char * ptr5;
   int row=0,curves=0;
   double b1=0;
   int curves_from_downstream=0;
   int curves_for_upload=0;
   int factor_needs_upstream=0;

   strcpy(ecmfilename, filename);

   if ( (fp = fopen(filename,"rt")) == NULL ) {
      printf("Can't open file:%s\n",filename);
      return (-1);
   }

   line = (char *) malloc( 10001 );
   if ( line == NULL ) {
      printf("malloc error!\n");
      fclose(fp);
      return (-1);
   }

   while ( fgets(line,10000,fp) != NULL ) {
      row++;
      // format is "short_name N base10_representation"
      //        or "short_name B B1level #curves"
      if ( strlen(line) > 1 ) {
         ptr1 = strchr((char const *) line, ' ');
         if ( ptr1 != NULL ) {
            *ptr1=0;
            if ( *(ptr1+1) == 'N' ) {
               // Remove any trailing CR/LF from base10rep...
               ptr1 += 3;
               if ( *(ptr1+strlen(ptr1)-1) == 0x0A )   *(ptr1+strlen(ptr1)-1)=0;
               if ( *(ptr1+strlen(ptr1)-1) == 0x0D )   *(ptr1+strlen(ptr1)-1)=0;
               StoreDetails(line, ptr1);
            } else if ( *(ptr1+1) == 'A' ) {
               SetActive( line );
            } else if ( *(ptr1+1) == 'L' ) {
               SetLocalControl( line );
            } else if ( *(ptr1+1) == 'B' ) {
               b1 = atol(ptr1+3);
               // Make ptr1 point to the first number after the 'B'
               ptr1 = strchr((char const *) ptr1+3, ' ');
               if ( ptr1 != NULL ) {
                  curves = atoi(ptr1+1);
                  // Make ptr2 point to the second number after the 'B'
                  ptr2 = strchr((char const *) ptr1+1, ' ');
                  if (ptr2 != NULL) {
                     curves_for_upload = atoi(ptr2+1);
                     ptr3 = strchr((char const *) ptr2+1, ' ');
                     if (ptr3 != NULL) {
                        curves_from_downstream = curves_for_upload;
                        curves_for_upload      = atoi(ptr3+1);
                     } else {
                        curves_from_downstream = 0;
                     }
                  } else {
                     curves_from_downstream = curves_for_upload = curves;
                  }
                  Add_to_b1details(get_index(line), b1, curves, curves_from_downstream, curves_for_upload);
               } else {
                  printf("Malformed information in %s at row #%d.\n",filename,row);
               }
            } else if ( *(ptr1+1) == 'F' ) {
               ptr1+=3;
               if ( *(ptr1+strlen(ptr1)-1) == 0x0A )   *(ptr1+strlen(ptr1)-1)=0;
               if ( *(ptr1+strlen(ptr1)-1) == 0x0D )   *(ptr1+strlen(ptr1)-1)=0;
               while (*(ptr1+strlen(ptr1)-1) == ' ')   *(ptr1+strlen(ptr1)-1)=0;
               if ( (ptr2 = strchr(ptr1, ' ')) != NULL ) {
                  *ptr2=0;
                  if ( (ptr3 = strchr(ptr2+1, ' ')) != NULL) {
                     *ptr3=0;
                     ptr4 = strchr(ptr3+1, ' ');
                     ptr5 = strchr(ptr4+1, ' ');
                     if (ptr5 == NULL) {
                        factor_needs_upstream = 1;
                     } else {
                        factor_needs_upstream = atoi(ptr5+1);
                     }
                     Add_Factor(get_index(line), ptr1, 0, ptr2+1, atol(ptr3+1), atol(ptr4+1), factor_needs_upstream);
                  } else {
                     Add_Factor(get_index(line), ptr1, 0, ptr2+1, 0., 0.);
                  }
               } else {
                  Add_Factor(get_index(line), ptr1, 0, "", 0., 0.);
               }
            } else {
               printf("Malformed information in INI file at row #%d.\n",row);
            }
         }
      }
   }

   free( line );

   fclose(fp);
   changes=0;                                    // Since StoreDetails() will increment it.
   sortme(); // if required
   return (0);
}

void switchnumbers(number_to_factor * number1, number_to_factor * number2) {
   number_to_factor tempnumber;

   memcpy(&tempnumber, number1, sizeof(number_to_factor));
   memcpy(number1, number2, sizeof(number_to_factor));
   memcpy(number2, &tempnumber, sizeof(number_to_factor));
}

int ecm_list::newnumber(char * sourcename, char * base10rep) {
   char * newname;
   char * ptr;
   char * tempstring;

   newname = new char[strlen(sourcename)+100];
   strcpy(newname, sourcename);

   if ( (ptr=strrchr(newname, '.')) != NULL) *ptr=0;
   strcat(newname, ".c");
   tempstring=new char[50];
   sprintf(tempstring, "%d", strlen(base10rep));
   strcat(newname, tempstring);
   free(tempstring);

   int i;
   while ((i = get_index(newname)) != 0 ) strcat(newname, "x");

   StoreDetails( newname, base10rep );
   SetActive( newname ); // Activate it
   i=get_index( newname );

   // Copy the b1 information from the source number to this one...
   int j=get_index( sourcename );
   for ( int k=0 ; k<numbers_to_factor[j-1].b1_details_number ; k++ ) {
      Add_to_b1details(i,
                       numbers_to_factor[j-1].b1_details[k].b1,
                       numbers_to_factor[j-1].b1_details[k].curvecount,
                       0,
                       numbers_to_factor[j-1].b1_details[k].curvecount);
   }

   free(newname);
   return i;
}

