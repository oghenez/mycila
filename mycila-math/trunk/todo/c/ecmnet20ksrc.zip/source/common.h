#ifndef _commonh_

   #define min(a,b)  (((a) < (b)) ? (a) : (b))
   #define max(a,b)  (((a) > (b)) ? (a) : (b))

   #define _commonh_
   #define BUFFERSIZE 50000
   extern char * logmsg;
   extern char * upstreamgreeting;
   extern char logname[100];
   extern long loglimit;
   void setdebug();

   const char * Time( void );
   const char * Date( void );
   void log(char * filename, char * msg);
   void logfile(char * filename, char * msg);
   int putstring(int s, char * text);
   char * getstring(int s);
   void stripCRLF(char * string);
   unsigned int inet_address(const char *host);
   int open_server(char * server, int port, char * email);
   int returnwork(int s, ecm_list * ecmlist, int closesocketflag, int noremove);
   void getb1andfacinfo(ecm_list * ecmlist, int noremove, int s, int k );
   char * nextword(char *);
#endif

