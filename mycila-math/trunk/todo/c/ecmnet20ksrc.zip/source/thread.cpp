// thread.h/thread.cpp
//
// Written by Tim Charron November 12, 1998
// Copyright Tim Charron

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "thread.h"

//This is used to end the thread...
void EndThread( _thread_handle * thandle ) {
#ifdef WIN32
   WaitForSingleObject((HANDLE) thandle->threadid, INFINITE);
#endif

#ifdef UNIX
   pthread_join( thandle->threadid, NULL );
#endif
}

// This is used locally to actually start the thread.
// This function is the entry point in the new thread.
void runthread( void * thread_details ) {
   struct _thread_info *thread_data = (_thread_info *) thread_details;

   void (*tfunc)(void *) = thread_data->func;
   void *tparams = thread_data->params;

   thread_data->status=2;                        // started.

   (*tfunc)( tparams );                          // Run the thread

   thread_data->status=3;                        // Finished.

   return;
}

// MakeThread starts the new thread.
void MakeThread( _thread_handle * thandle, void (*func)(void *), void *params) {
   
   void *threadparam = (void *) &(thandle->threadinfo);
   void (*threadproc)(void *) = runthread;       // 'runthread' is function from above

   thandle->threadinfo.status = 1;        // Starting up
   thandle->threadinfo.func   = func;
   thandle->threadinfo.params = params;

#ifdef WIN32
   thandle->threadid = _beginthread( threadproc, 8192, threadparam);   // 0 if error.
#endif

#ifdef UNIX
   #ifdef _POSIX_THREAD_PRIORITY_SCHEDULING
   int ret;
   pthread_attr_t t_sched;
printf("calling pthread_attr_init.\n");fflush(stdout);
   ret=pthread_attr_init( &t_sched );
printf("calling pthread_attr_setscope.\n");fflush(stdout);
   ret=pthread_attr_setscope( &t_sched, PTHREAD_SCOPE_SYSTEM );
printf("calling pthread_attr_setinheritsched.\n");fflush(stdout);
   ret=pthread_attr_setinheritsched( &t_sched, PTHREAD_INHERIT_SCHED );
printf("calling pthread_create.\n");fflush(stdout);
   if ( ret=pthread_create( &(thandle->threadid), &t_sched, (void *(*)(void*)) threadproc, threadparam) ) {
      thandle->threadid = (pthread_t) NULL;
   }
   #else
printf("calling pthread_create.\n");fflush(stdout);
   if ( pthread_create( &(thandle->threadid), NULL, (void *(*)(void*)) threadproc, threadparam) ) {
      thandle->threadid = (pthread_t) NULL;
   }
   #endif
#endif

   // Wait for the thread to start up...
   if ( (void*)(thandle->threadid) != NULL ) {
      while ( thandle->threadinfo.status != 2 ) Sleep(100);   // 1/10th second
   }

   return ;                             // Calling function must destroy it when done.
}

