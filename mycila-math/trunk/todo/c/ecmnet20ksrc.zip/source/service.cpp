/*
 * service.cpp -- Tim Charron Oct 1998.
 *
 * Based on code written by Magnus Hagander 1997.
 *
 * Permission to compile and distribute yourself.
 * If you make any modifications, chose another name and clearly state
 * that it is not the official version. Also state that it is based on
 * this code (C) 1997 Magnus Hagander.
 *
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <direct.h>              //Required to do _chdir()

extern int actualmain(int argc, char * argv[]); // The main() from the actual binary

static SERVICE_STATUS_HANDLE serviceStatusHandle;
static HANDLE hThreadEvent;
static HANDLE killServiceEvent;
static int serviceCurrentStatus;

static char exename[1024];

/*
 * Stop the current service
 */
void KillService(void) {
   SetEvent(hThreadEvent);
   Sleep(2000);
   SetEvent(killServiceEvent);
}

/*
 * Simple wrapper for the working thread
 */
DWORD WINAPI WorkerThread(LPDWORD param) {
char * argv[2];

   argv[0]=exename;
   argv[1]=NULL;
   actualmain((int) 1, argv); // The real work is done here.
   KillService();
   return 0;
}

/*
 * An even simplier wrapper that just starts the working thread
 */
void StartServiceThread(void) {
   DWORD dwd;
   CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)WorkerThread,NULL,0,&dwd);
}

/*
 * Update the service status (in the SCM)
 */
BOOL UpdateSCMStatus (DWORD dwCurrentState,
                      DWORD dwWin32ExitCode,
                      DWORD dwServiceSpecificExitCode,
                      DWORD dwCheckPoint,
                      DWORD dwWaitHint)
{
   BOOL success;
   SERVICE_STATUS serviceStatus;
   // Fill in all of the SERVICE_STATUS fields
   serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS; //We don't want to mess up the system
   serviceStatus.dwCurrentState = dwCurrentState;
   // If in the process of something, then accept
   // no control events, else accept anything
   if (dwCurrentState == SERVICE_START_PENDING)
   {
      serviceStatus.dwControlsAccepted = 0;
   }
   else
   {
      serviceStatus.dwControlsAccepted =
         SERVICE_ACCEPT_STOP |
         SERVICE_ACCEPT_SHUTDOWN;
   }
   // if a specific exit code is defines, set up
   // the Win32 exit code properly
   if (dwServiceSpecificExitCode == 0)
   {
      serviceStatus.dwWin32ExitCode = dwWin32ExitCode;
   }
   else
   {
      serviceStatus.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
   }
   serviceStatus.dwServiceSpecificExitCode =   dwServiceSpecificExitCode;
   serviceStatus.dwCheckPoint = dwCheckPoint;
   serviceStatus.dwWaitHint = dwWaitHint;
   // Pass the status record to the SCM
   success = SetServiceStatus (serviceStatusHandle, &serviceStatus);
   if (!success)
   {
      /*
       * Ouch. We couldn't update the status. Well. Better exit, then
      */
      KillService();
   }
   return success;
}

/*
 * Signal we are down
 */
void terminateService (int code, int wincode) {
   UpdateSCMStatus(SERVICE_STOPPED,wincode?wincode:ERROR_SERVICE_SPECIFIC_ERROR,(wincode)?0:code,0,0);
   return;
}

//   Handles the events dispatched by the Service Control Manager.
VOID ServiceCtrlHandler (DWORD controlCode)
{
   switch(controlCode)
   {
      // There is no START option because
      // ServiceMain gets called on a start
      // Update the current status for the SCM.
      case SERVICE_CONTROL_INTERROGATE:
         // This does nothing, here we will just fall through to the end
         // and send our current status.
         break;
      // For a shutdown, we can do cleanup but it must take place quickly
      // because the system will go down out from under us.
      // For this app we have time to stop here, which I do by just falling
      // through to the stop message.
      case SERVICE_CONTROL_SHUTDOWN:
      // Stop the service
      case SERVICE_CONTROL_STOP:
         // Tell the SCM we're about to Stop.
         serviceCurrentStatus = SERVICE_STOP_PENDING;
         UpdateSCMStatus(SERVICE_STOP_PENDING, NO_ERROR, 0, 1, 5000);
         KillService();
         UpdateSCMStatus(SERVICE_STOPPED,NO_ERROR,0,0,0);
         return;
      default:
          break;
   }
   UpdateSCMStatus(serviceCurrentStatus, NO_ERROR, 0, 0, 0);
}


VOID ServiceMain(DWORD argc, LPTSTR *argv)
{
   BOOL success;
   HKEY MyKey;
   DWORD type=0,size=0;


   // First we must call the Registration function
   serviceStatusHandle = RegisterServiceCtrlHandler(NTSERVICE,
                           (LPHANDLER_FUNCTION) ServiceCtrlHandler);
   if (!serviceStatusHandle)
   {
      terminateService(1,GetLastError());
      return;
   }
   // Next Notify the Service Control Manager of progress
   success = UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 1, 1000);
   if (!success)
   {
      terminateService(2,GetLastError());
      return;
   }

   killServiceEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
   hThreadEvent = CreateEvent(NULL,TRUE,FALSE,NULL);

   if (!killServiceEvent || !hThreadEvent) {
      terminateService(99,GetLastError());
      return;
   }

   //Now open the registry key, query values and close it
   char keyname[300];
   sprintf(keyname, "SYSTEM\\CurrentControlSet\\Services\\");
   strcat(keyname, NTSERVICE);

   if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,keyname,NULL,KEY_QUERY_VALUE,&MyKey) != ERROR_SUCCESS) {
      terminateService(3,GetLastError());
      return;
   }
   size = sizeof(exename);
   if (RegQueryValueEx(MyKey,"Exename",NULL,&type,(unsigned char *)exename,&size) != ERROR_SUCCESS) {
      terminateService(5,GetLastError());
      return;
   }
   RegCloseKey(MyKey);

   success = UpdateSCMStatus(SERVICE_START_PENDING, NO_ERROR, 0, 2, 1000);
   if (!success)
   {
      terminateService(2,GetLastError());
      return;
   }

   // Start the service execution thread by calling our StartServiceThread function...
   StartServiceThread();
   // The service is now running.  Notify the SCM of this fact.
   serviceCurrentStatus = SERVICE_RUNNING;
   success = UpdateSCMStatus(SERVICE_RUNNING, NO_ERROR, 0, 0, 0);
   if (!success)
   {
      terminateService(6,GetLastError());
      return;
   }
   // Now just wait for our killed service signal, and then exit, which
   // terminates the service!
   WaitForSingleObject (killServiceEvent, INFINITE);
//   success = UpdateSCMStatus(SERVICE_STOPPED, NO_ERROR, 0, 0, 0);
}


/*
 * Misc functions - not actual part of the service!
 */

/*
 * Install the service in the SCM
 */
void InstallService(char * exename) {
   SC_HANDLE myService, scm;
   HKEY MyKey;
   DWORD Disposition = 0;

   char modname[256];
   GetModuleFileName(NULL,modname,sizeof(modname));


   printf("Installing service...\n");

   scm = OpenSCManager(0,0,SC_MANAGER_CREATE_SERVICE);
   if (!scm) {
      printf("Failed to open Service Control Manager! (Error code %i)\n",GetLastError());
      return;
   }

   char svcname[50];
   strcpy(svcname, "ECM ");
   strcat(svcname, 3+NTSERVICE);
   myService = CreateService(scm,
          NTSERVICE,                                //Internal service name
          svcname,                                  //Show name
          SERVICE_ALL_ACCESS,                         //We want full control
          SERVICE_WIN32_OWN_PROCESS,                  //Let's not mess it up for somebody else..
          SERVICE_AUTO_START,                         //The service requires manual start
          SERVICE_ERROR_NORMAL,                       //Normal handling when error in startup
          modname,                                    //Binary file
          0,0,0,0,0);                                 //Misc :)

   if (!myService) {
      printf("Failed to create the %s service! (Error code %i)\n",NTSERVICE, GetLastError());
      CloseServiceHandle(scm);
      return;
   }

   char keyname[300];
   sprintf(keyname, "SYSTEM\\CurrentControlSet\\Services\\");
   strcat(keyname, NTSERVICE);

   if (
      RegCreateKeyEx(HKEY_LOCAL_MACHINE,
                     keyname,
                     NULL, //Reserved
                     NULL, //Class
                     REG_OPTION_NON_VOLATILE,
                     KEY_ALL_ACCESS,
                     NULL, //Security attributes :)
                     &MyKey,
                     &Disposition)
      != ERROR_SUCCESS) {
         printf("Failed to open registry key!\n");
         return;
      }
   if (
       RegSetValueEx(MyKey,"Exename",NULL,REG_SZ,(unsigned char *)exename,strlen(exename)+1)
      != ERROR_SUCCESS) {
         printf("Failed to write binary executable name to registry!\n");
         RegCloseKey(MyKey);
         return;
      }

   RegCloseKey(MyKey);

   printf("Service successfully installed.\nYou may now start it manually using \"Net start %s\".  It has been set to start automatically at startup.\n",NTSERVICE);
   CloseServiceHandle(myService);
   CloseServiceHandle(scm);
}

/*
 * Remove the service from the SCM
 */
void RemoveService(void) {
   SC_HANDLE myService, scm;

   printf("Removing service...\n");

   scm = OpenSCManager(0,0,SC_MANAGER_CREATE_SERVICE);
   if (!scm) {
      printf("Failed to open Service Control Manager! (Error code %i)\n",GetLastError());
      return;
   }

   myService = OpenService(scm,NTSERVICE,SERVICE_ALL_ACCESS);
   if (!myService) {
      printf("Failed to open service! (Error code %i)\n",GetLastError());
      CloseServiceHandle(scm);
      return;
   }

   if (!DeleteService(myService)) {
      printf("Failed to delete service! (Error code %i)\n",GetLastError());
      CloseServiceHandle(myService);
      CloseServiceHandle(scm);
      return;
   }

   CloseServiceHandle(myService);
   CloseServiceHandle(scm);

   printf("Service successfully removed.\n");
}

/*
 * Guess...
 */
void SvcUsage(char * name) {
   printf("Usage:\n\n"
          "   %s -install         To install service\n"
          "   %s -remove          To remove service\n",name,name);
}

/*
 * main()
 *
 * As suspected, this is the entrypoint in the program :-)
 *
 * If no parameters are given, assume that we are started by the SCM,
 *    and there for start the Service Control Dispatcher.
 * If one parameter is given, it is checked against the allowed ones.
 *    If one of them, the appropriate actionn is taken.
 * If wrong number of parameters or an incorrect parameter is given,
 *    the usage instructions are shown.
 *
 * May be a dirty way to find out if we are a service or not, but who cares
 */
int main(int argc, char *argv[]) {
   switch(argc) {
      case 1: {
            SERVICE_TABLE_ENTRY serviceTable[]= { {NTSERVICE, (LPSERVICE_MAIN_FUNCTION)ServiceMain},{NULL,NULL}};
            StartServiceCtrlDispatcher(serviceTable);
            }
            break;
      case 2:
          printf("%s Service - by tcharron@interlog.com\n\n",NTSERVICE);
            if (!stricmp(argv[1],"-install"))
               InstallService(argv[0]);
            else if (!stricmp(argv[1],"-remove"))
               RemoveService();
            else
               SvcUsage(argv[0]);
            break;
      default:
            SvcUsage(argv[0]);
   }
   return 0;
}

