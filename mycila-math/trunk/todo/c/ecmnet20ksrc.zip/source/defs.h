/*
  Nov 20 1998 version 2.0e - Improved comm. error detection for unix systems (no affect on Win32)
  Nov 27 1998 version 2.0f - Fixed bug in is_LocalControl -- it was getting the local control
                             status of the NEXT number in the list.
  Apr 15 1999 Version 2.0g - Allowed specification of server names using name (instead of IP address)
  Apr 22 1999 Version 2.0h - server names > 20 characters weren't working properly.
  Jun 20 1999 Version 2.0i - Server drops connections from client if no composites are available
                             (factored or unfactored composites) (Courtesy of RZG <gevaryah@netaxs.com>
                             Server can be started in slave mode with no INI file available.
  Jun 20 1999 Version 2.0i - Added RAND_MAX def if not already defined (RZG <gevaryah@netaxs.com>)
  Jun 20 1999 Version 2.0i - Added include files errno.h/netdb.h for UNIX compiles (RZG <gevaryah@netaxs.com>)
  Jun 21 1999 Version 2.0j - Fixed possible crash when processing returning a factor. (courtesy of Paul Abelian)
                           - Fixed command line parsing when last parameter is incomplete (courtesy of Paul Abelian)
  Jun 21 1999 Version 2.0k - Chained server code was broken (affected downstrem server only)
*/

#define VERSIONMAJOR 2
#define VERSIONMINOR 0
#define VERSIONMINOR2 'k'

#ifdef WIN32
   #define comm_errno GetLastError()
   #define BLOCKING_ERROR WSAEWOULDBLOCK
#endif
#ifdef UNIX
   #include <errno.h>
   #include <netdb.h>
   
   #define comm_errno errno
   #define BLOCKING_ERROR EAGAIN
// #define BLOCKING_ERROR EWOULDBLOCK
   #define Sleep(x) usleep((x)*1000)
// #define usleep(x) sleep(x/1000000)
   #define closesocket(x) close(x)
   #define SOCKET int
   #define INVALID_SOCKET -1
   #define stricmp(x,y)  strcasecmp(x,y)
   #define BOOL int
   #ifndef RAND_MAX
      #define RAND_MAX (2^15)-1
   #endif
#endif

