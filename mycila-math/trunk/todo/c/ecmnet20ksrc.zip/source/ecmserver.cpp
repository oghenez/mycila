/*
  ecmserver

  Revision history:
  September 9, 1998 Original creation by Tim Charron <tcharron@interlog.com>
  September 20 1998 Version 1.1 Tim Charron
  September 22 1998 Version 1.2 Tim Charron
  September 25 1998 Version 1.3 Tim Charron
  September 30 1998 Version 1.4 Tim Charron
    ...addition of "GETACTIVES" and "GETBASE10 number" commands

  October 5, 1998 version 1.5a Tim Charron
    Changes for NT service version
  October 5 1998 version 1.5b
    Hitting 'X' will exit, hitting 'U' forces upstream server connect
  October 7 1998 version 1.6
    Addition of ".crv"/".usr"/".us2" file support
                 version 1.6b
    Addition of ".daily" file support
  October 8 1998 version 1.7  Many security related changes (fgets, strcpy, sprintf)
  Oct 9 1998 version 1.7b more security changes, ".us1" file
  Oct 9 1998 version 1.7c Added 'work' calculation to ecm_list and output to admin functions
  Oct 13 1998 version 1.8 Client/Server provide messages about total work completed as per upstream server.
  Oct 16 1998 version 1.8a 'totwork' displayed on screen & in ecmserver.log was calculated incorrectly
  Oct 16 1998 version 1.8b New strategy (#4) which selects 'shortest' composite.
                      1.8b Accepts prime status, cofactor and cofactor status (compositeness)
                           from client if provided.  Automatically activates new composite if
                           factor or cofactor are composite!
                      1.8b 'recurse' option controls this behaviour.
                      1.8c Upstream comm. errors weren't being retried properly after errtimeout minutes.
   Oct 18 1998 version 1.8d Added "Local Control" ability. 'L' flag in INI file means that server
                            will not activate/deactivate those numbers from an upstream server.
   Oct 20 1998 version 1.8e Fixed bug in 'recurse' that caused crash
                            Added "minb1" parameter
   Oct 23 1998 version 1.8f Fixed small memory leaks
   Oct 24 1998 version 1.9 - Fixed crash when some composites have ',' in their name
                           Recurse option now copies b1 information from parent composite when
                           adding new composite to list
                           - UNIX ONLY: Added signal "SIGUSR1" to request an update, and
                           "SIGINT" (ctrl-c) and "SIGTERM" (kill) to request it to exit
                           (RZG <gevaryah@netaxs.com>)
                           - "Admin" options changed so that only those that change server config. require password.
   Oct 26 1998 version 1.9a - server was sending it's own email as finder to upstream server instead of client's email.
                            - Changed 2900000*5250 to 3000000*5100 curves in ecm_list::get_bestb1
  Oct 27 1998 version 1.9b Fixed bug when server sends 'down' a new factor -- sigma info was being lost.
  Oct 28 1998 version 1.9b - get_sumb1 now returns the better of upstream server totals, or downstream totals.
                           - default error timeout changed to 5 minutes
                           - Added support for server specifed 'max # curves' to process
                           - Sped up 'getwork' when using very large INI files.
                           - Cleaned up info that's logged to screen/file to be more readable (well, slightly more ;)
  Oct 30 1998 version 1.9c - Sped up communications to upstream server
  Nov 2 1998 version 1.9d - Support for multiple simultaneous strategies.
  Nov 2 1998 version 1.9d - Added support for "GETGREETING"
  Nov 4 1998 version 1.9e - Added ability for server to send mail when new factor is found.
  Nov 6 1998 version 1.9f - Added forced upstream server contact when factor returned
  Nov 7 1998 version 1.9f - Fixed getwork, where strategy 3 was hanging under gcc/linux (gcc wouldn't
                            recognize two doubles as equal when it should have)
  Nov 8 1998 version 2.0 - Minor cleanups, unix compile now works again (broken when mail added)
             version 2.0a - errtimeout set to 20 minutes
                          - Removed some extraneous messages when no upstream server present
  Nov 9 1998 version 2.0b - Fixed bug in ecmlist::newnumber that was causing 'sourcename's b1 information to not be copied
                            to the new number.
  Nov 10 1998 version 2.0c - Added ability to sort INI file by name, b1, sum(b1), work, len(composite)
  Nov 11 1998 version 2.0d - Fixed minor bug in strategy handling
                           - Made output of admin_status() more readable
  Apr 15 1999 Version 2.0g - Allowed specification of server names using name (instead of IP address)
  Apr 15 1999 Version 2.0h - server names > 20 characters weren't working properly.
  Jun 20 1999 Version 2.0i - Server drops connections from client if no composites are available
                             (factored or unfactored composites) (Courtesy of RZG <gevaryah@netaxs.com>
                             Server can be started in slave mode with no INI file available.
  Jun 20 1999 Version 2.0i - Fixed server crash when GETBASE10 asked about non-existent number. (courtesy of Paul Abelian)
  Jun 21 1999 Version 2.0j - Fixed possible crash when processing returning a factor. (courtesy of Paul Abelian)
                           - Fixed command line parsing when last parameter is incomplete (courtesy of Paul Abelian)
                           - Fixed misc. problems with getstring() NULL/"" return values and strlen()/free() etc.
  Jun 21 1999 Version 2.0k - Chained server code was broken (affected downstrem server only)

The most recent version of this source is available from http://www.interlog.com/~tcharron/ecm.html

*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <math.h>

#ifdef WIN32
   #include <winsock.h>
   #include <conio.h>
   #include <direct.h>
#endif

#ifdef UNIX
   #include <unistd.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <arpa/inet.h>
   #include <fcntl.h>
   #include <sys/stat.h>
   #include <signal.h>
   int actionflag=0;
#endif

#include "defs.h"
#include "ecm_list.h"
#include "common.h"
#include "users.h"
#include "mail.h"

int go_listen(int listenport)
{
   struct sockaddr_in sin;
   int s;

   s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
   if ( s == INVALID_SOCKET ) {
      perror("socket");
      return (-1);
   }

   /* try to reuse sockets */
   int mytrue = 1;
   if ( setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char*)&mytrue, sizeof(int)) != 0 )
      perror("Error setting socket reuse flag.");

   /*
    * bind the socket to address and port given
    */
   memset(&sin, 0, sizeof(sin));
   sin.sin_family = AF_INET;
   sin.sin_port = htons(listenport);
   sin.sin_addr.s_addr = inet_addr( "0.0.0.0" );

   if ( bind(s, (struct sockaddr *) &sin, sizeof(sin)) != 0 ) {
      perror("bind");
      return (-1);
   }

   /*
    * set up to receive connections on this socket
    */
   if ( listen(s, 5) != 0 ) {
      perror("listen");
      closesocket(s);
      return (-1);
   }

   /*
   * Put the socket into non-blocking mode and set keepalive
   */
   unsigned long optval = 1;
   if ( setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (char*)&optval, sizeof(optval)) != 0 ) {
      perror("Warning: setsockopt(SO_KEEPALIVE) failed");
      return (-1);
   }

   optval = 1;
#ifdef WIN32
   if ( ioctlsocket(s, FIONBIO, &optval) != 0 ) {
      log(logname,"Warning: Couldn't set non-blocking mode");
      return (-1);
   }
#else
   if ( fcntl(s, F_SETFL, O_NONBLOCK ) == -1) {
      log(logname,"Warning: Couldn't set non-blocking mode");
      return (-1);
   }
#endif

   return (s);
}

#ifdef UNIX
   void gotusr1(int x) {
      actionflag=1;
   }
   void gotdie(int x) {
      actionflag=2;
   }
#endif

int acceptwork(int s, ecm_list * ecmlist, int * totcurves, double * totb1, double * totwork, char * email,
               user * users1, user * users2a, user * users2b, user * curvelist, user * dailywork) {
   // "RETURNWORK" will expect four rows to be provided.
   //
   // 1...return_ECMname:  name_of_number
   // 2...return_ECMnumber: base 10 representation of number
   // 3...return_B1:        b1 level tested
   // 4...return_Curves:    How many curves of level b1 were tested.
   //

   char * buf2;
   char * ptr;
   char * ptr2;
   char name[100];
   char * numbuffer;
   double b1;
   int curves;
   char * tempstring;

   int err=1;
   numbuffer = NULL;

   buf2 = getstring(s);
   if ( strncmp(buf2, "return_ECMname: ", 16)==0 ) {
      strncpy(name, buf2+16, 99);
      name[99] = 0;
      numbuffer = getstring(s);
      if ( strncmp(numbuffer, "return_ECMnumber: ", 18)==0 ) {
         free(buf2);
         buf2 = getstring(s);
         if ( strncmp(buf2, "return_B1: ", 11) ==0 ) {
            b1 = atol(buf2+11);
            free(buf2);
            buf2 = getstring(s);
            if ( strncmp(buf2, "return_Curves: ", 15) ==0 ) {
               curves = atoi(buf2+15);
               err=0;
            }
         }
      }
   }
   if (buf2 != NULL) free(buf2);

   if (err) {
      log(logname,"Returnwork Error.\n");
      getstring(-1);
      if (numbuffer!=NULL) free(numbuffer);
      return -1;
   } else {
      buf2 = ecmlist->get_number_base10rep( name );
      if (buf2 != NULL) {
         if ( strcmp(buf2 , numbuffer+18) != 0 ) {
            tempstring=new char[strlen(name)+100];
            sprintf(tempstring, "ERR: Returned base10 representation for %s doesn't match stored copy.\n",name);
            log(logname, tempstring);
            putstring(s, tempstring);
            delete tempstring;

            free(numbuffer);
            return -1;
         }
      }
      ecmlist->Add_to_b1details(name, numbuffer+18, b1, curves);

      tempstring = new char[strlen(name)+250];
      sprintf(tempstring, "<<< %s / B1=%.0lf * %d curves\n", name, b1, curves);
      log(logname,tempstring);
      delete tempstring;

      (*totb1)     += b1*curves;
      (*totcurves) += curves   ;
      (*totwork)   += b1*curves*strlen(name)*strlen(name)/1000000.;
      if (ecmlist->is_active( name )) {
         putstring(s, "OK.\n");
      } else {
         putstring(s, "INFO: Server copy of number is labelled 'inactive'\n");
      }

      double work = curves * b1 * strlen(numbuffer+18) * strlen(numbuffer+18);

      ptr = strchr(email, ':');
      if (ptr != NULL) *ptr=0;
      users2a->adduser((const char *) email, curves, curves * b1, work, 0, Time() );
      if (ptr != NULL) {
         *ptr=':';
         ptr2 = strchr(ptr+1, ':');
         if (ptr2 != NULL) *ptr2=0;
      } else {
         ptr2 = NULL;
      }
      users2b->adduser((const char *) email, curves, curves * b1, work, 0, Time() );
      if (ptr2 != NULL) *ptr2=':';

      users1->   adduser((const char *) email,   curves, curves * b1, work, 0, Time() );
      curvelist->adduser((const char *) name,    curves, curves * b1, work, 0, Time() );
      dailywork->adduser((const char *) Date() , curves, curves * b1, work, 0, Time() );

      free(numbuffer);
      return 0;
   }
}

char * returnfactor(int s, ecm_list * ecmlist, int noremove, char * fromname, int * totfactors,
                 user * users1, user * users2a, user * users2b, user * curvelist, user * dailywork,
                 int recurse, char * * returnfinderstring, char * * factorname, int * plength) {
   // "RETURNFACTOR" will expect five rows to be provided.
   //
   // 1...factor_ECMname:  name_of_number
   // 2...factor_ECMnumber: base 10 representation of number
   // 3...factor_FACTOR:   base 10 representation of factor
   //                      (optionally, appended with ":type:cofactor:cofactortype")
   // 4...factor_FINDER: finder's email address
   // 5...factor_B1: b1 level used to run gmp-ecm
   // 6...factor_sigma: sigma used when factor was found.
   //
   // It will return a character string that includes details of the new factor.  The
   // Calling routine must destroy this string.
   // The calling routine must also destroy the string pointed to by 'finder'.

   char * tempstring;
   char * buf2;
   char * ptr, *ptr1, *ptr2, *ptr3, *ptr4;
   char name[100];
   char finder[250];
   char b1level[50];
   char sigma[50];
   char * fac_number;
   char * fac_factor;
   int k;

   int err=1;
   fac_number=fac_factor=NULL;
   *returnfinderstring=NULL;
   *factorname=NULL;
   *plength=0;

   buf2 = getstring(s);
   if ( strncmp(buf2, "factor_ECMname: ", 16)==0 ) {
      strncpy(name, buf2+16, 99);
      name[99] = 0;
      fac_number=getstring(s);
      if ( strncmp(fac_number, "factor_ECMnumber: ", 18)==0 ) {
         fac_factor=getstring(s);
         if ( strncmp(fac_factor, "factor_FACTOR: ", 15) ==0 ) {
            free(buf2);
            buf2=getstring(s);
            if ( strncmp(buf2, "factor_FINDER: ", 15) ==0 ) {
               strncpy(finder, buf2+15, 249);
               finder[249] = 0;
               free(buf2);
               buf2=getstring(s);
               if ( strncmp(buf2, "factor_B1: ", 11) ==0 ) {
                  strncpy(b1level, buf2+11, 49);
                  b1level[49] = 0;
                  free(buf2);
                  buf2=getstring(s);
                  if ( strncmp(buf2, "factor_sigma: ", 14) ==0 ) {
                     strncpy(sigma, buf2+14, 49);
                     sigma[49] = 0;
                     err=0;
                  }
               }
            }
         }
      }
   }
   if (buf2 != NULL) free(buf2);

   if (err) {
      log(logname,"ReturnFactor Error.\n");
      getstring(-1);
      if (fac_number!=NULL) free(fac_number);
      if (fac_factor!=NULL) free(fac_factor);
      *returnfinderstring=NULL;
      *factorname=NULL;
      *plength=0;
      return NULL;
   } else {
      if ( strcmp(ecmlist->get_number_base10rep( name ) , fac_number+18) != 0 ) {

         tempstring = new char[strlen(name)+100];
         sprintf(tempstring, "ERR: Returned base10 representation for %s doesn't match stored copy.\n",name);
         log(logname, tempstring);
         putstring(s, tempstring);
         delete tempstring;

         tempstring = new char[100+strlen(fromname)+strlen(fac_factor+15)+strlen(finder)];
         sprintf(tempstring, "Factor returned (from %s ) was %s (finder: %s)\n",fromname, fac_factor+15, finder);
         log(logname,tempstring);
         delete tempstring;

         tempstring = new char[1500+strlen(fromname)+strlen(fac_number+18)+strlen(fac_factor+15)+strlen(finder)];
         sprintf(tempstring, "Factor returned from %s.\n\n"
                 "Base 10 representation of composite DOES NOT MATCH server copy.\n\n"
                 " Composite name: %s\n"
                 " Composite number: %s\n\n"
                 " Factor returned: %s\n\n"
                 " B1: %s\n"
                 " Sigma: %s\n\n"
                 " Finder: %s\n"
                 ,fromname, name, fac_number+18, fac_factor+15, b1level, sigma, finder);

         free(fac_number);

         ptr=strchr(fac_factor+15, ':');
         if (ptr != NULL) *ptr=0;
         *plength = strlen(fac_factor+15);

         free(fac_factor);

         *returnfinderstring=new char[strlen(finder)+1];
         strcpy(*returnfinderstring, finder);
         ptr=strchr(*returnfinderstring, ':');
         if (ptr != NULL) *ptr=0;

         *factorname=new char[strlen(name)+1];
         strcpy(*factorname, name);

         return tempstring;
      } else {
         if (ecmlist->Add_Factor(name, fac_number+18, fac_factor+15, noremove, finder, atol(b1level), atol(sigma))) {
            putstring(s, "OK.\n");

            tempstring = new char[100+strlen(fromname)+strlen(name)+strlen(fac_factor+15)+strlen(finder)+strlen(b1level)+strlen(sigma)];
            sprintf(tempstring,"Factor returned by %s!  %s / %s  finder: %s B1:%s sigma: %s\n", fromname, name, fac_factor+15, finder, b1level, sigma );
            log(logname,tempstring);
            logfile("Factors.log",tempstring);
            delete tempstring;
            (*totfactors) += 1;

            // Add to the totals by user/machine/etc...
            ptr = strchr(fromname, ':');
            if (ptr != NULL) *ptr=0;
            users2a->adduser((const char *) fromname, 0, 0, 0, 1, Time() );
            if (ptr != NULL) {
               *ptr=':';
               ptr2 = strchr(ptr+1, ':');
               if (ptr2 != NULL) *ptr2=0;
            } else {
               ptr2 = NULL;
            }
            users2b->adduser((const char *) fromname, 0, 0, 0, 1, Time() );
            if (ptr2 != NULL) *ptr2=':';

            users1->adduser(   (const char *) fromname, 0, 0, 0, 1, Time() );
            curvelist->adduser((const char *) name,     0, 0, 0, 1, Time() );
            dailywork->adduser((const char *) Date(),   0, 0, 0, 1, Time() );

            // See if fac_factor includes information on it's type (composite, prime, probable),
            // as well as cofactor information and type...
            if (recurse && (NULL != (ptr2=strchr(fac_factor, ':')) ) ) {
               // format of fac_factor is factor:type:cofactor:type
               ptr1=nextword(fac_factor+15);
               ptr2=nextword(fac_factor+15+strlen(ptr1)+1);
               ptr3=nextword(fac_factor+15+strlen(ptr1)+1+strlen(ptr2)+1);
               ptr4=nextword(fac_factor+15+strlen(ptr1)+1+strlen(ptr2)+1+strlen(ptr3)+1);
               if (0 == stricmp(ptr2, "Composite")) {
                  k = ecmlist->newnumber(name, ptr1);
                  tempstring = new char[250+strlen(name)+strlen(ecmlist->get_number_base10rep(k)) ];
                  sprintf(tempstring, "Composite factor of %s (%s) added to server list (number is %s)\n",
                          name,
                          ecmlist->get_number_shortname(k),
                          ecmlist->get_number_base10rep(k) );
                  log(logname,tempstring);
                  delete tempstring;
               }
               if (0 == stricmp(ptr4, "Composite")) {
                  k = ecmlist->newnumber(name, ptr3);
                  tempstring = new char[250+strlen(name)+strlen(ecmlist->get_number_base10rep(k)) ];
                  sprintf(tempstring, "Composite factor of %s (%s) added to server list (number is %s)\n",
                          name,
                          ecmlist->get_number_shortname(k),
                          ecmlist->get_number_base10rep(k) );
                  log(logname,tempstring);
                  delete tempstring;
               }
               free(ptr1);
               free(ptr2);
               free(ptr3);
               free(ptr4);
            }

            tempstring = new char[1500+strlen(fromname)+strlen(fac_number+18)+strlen(fac_factor+15)+strlen(finder)];
            sprintf(tempstring, "Factor returned from %s.\n\n"
                    " Composite name: %s\n"
                    " Composite number: %s\n\n"
                    " Factor returned: %s\n\n"
                    " B1: %s\n"
                    " Sigma: %s\n\n"
                    " Finder: %s\n"
                    ,fromname, name, fac_number+18, fac_factor+15, b1level, sigma, finder);

            free(fac_number);

            ptr=strchr(fac_factor+15, ':');
            if (ptr != NULL) *ptr=0;
            *plength = strlen(fac_factor+15);

            free(fac_factor);

            *returnfinderstring=new char[strlen(finder)+1];
            strcpy(*returnfinderstring, finder);
            ptr=strchr(*returnfinderstring, ':');
            if (ptr != NULL) *ptr=0;

            *factorname = new char[strlen(name)+1];
            strcpy(*factorname, name);

            return tempstring;
         } else {
            putstring(s, "INFO: Factor was already known.\n");

            tempstring = new char[100+strlen(fromname)+strlen(name)+strlen(fac_factor+15)+strlen(finder)+strlen(b1level)+strlen(sigma)];
            sprintf(tempstring,"Dup. Factor returned (from %s) for %s: %s  finder: %s B1: %s sigma: %s\n", fromname, name, fac_factor+15, finder, b1level, sigma );
            log(logname,tempstring);
            delete tempstring;

            tempstring = new char[1500+strlen(fromname)+strlen(fac_number+18)+strlen(fac_factor+15)+strlen(finder)];
            sprintf(tempstring, "Duplicate factor returned from %s.\n\n"
                    " Composite name: %s\n"
                    " Composite number: %s\n\n"
                    " Factor returned: %s\n\n"
                    " B1: %s\n"
                    " Sigma: %s\n\n"
                    " Finder: %s\n"
                    ,fromname, name, fac_number+18, fac_factor+15, b1level, sigma, finder);

            free(fac_number);

            ptr=strchr(fac_factor+15, ':');
            if (ptr != NULL) *ptr=0;
            *plength = strlen(fac_factor+15);

            free(fac_factor);

            *returnfinderstring=new char[strlen(finder)+1];
            strcpy(*returnfinderstring, finder);
            ptr=strchr(*returnfinderstring, ':');
            if (ptr != NULL) *ptr=0;

            *factorname=new char[strlen(name)+1];
            strcpy(*factorname, name);

            return tempstring;
         }
      }
   }
}

void getwork(int s, ecm_list * ecmlist, int strategy[6], double minb1) {
   // "GETWORK" will result in three lines being sent to the server.
   // 1...shortname
   // 2...base 10 representation
   // 3...Suggested B1 level to use.
   // 4...Suggested #curves to process... (currently always set to 1).

   char * tempstring;
   double selec,selec2;
   double b1;
   int rno, this_strategy;

   // First off, choose a strategy from the distribution of strategies passed.
   // strategy[5] is the sum of the strat. weights.  strategy[0]..strategy[4] are the individual
   // weights.
   if (!ecmlist->get_number_of_numbers()) {
      putstring(s, "ERR: No work available\nERR\nERR\nERR\n");
      return;
   }
   rno = rand() % strategy[5]; // number from 0 to sum(strategy weights) - 1
   if (rno >= strategy[0]) {
      rno -= strategy[0];
      if (rno >= strategy[1]) {
         rno -= strategy[1];
         if (rno >= strategy[2]) {
            rno -= strategy[2];
            if (rno >= strategy[3]) {
               this_strategy=4;
            } else {
               this_strategy=3;
            }
         } else {
            this_strategy=2;
         }
      } else {
         this_strategy=1;
      }
   } else {
      this_strategy=0;
   }

   // Choose a random number from those stored...
   rno = 1 + (rand() % ecmlist->get_number_of_numbers() );

   // Avoid "unknown" numbers and non-active numbers...
   if (ecmlist->get_number_of_active() == 0) {
      tempstring = new char[strlen(ecmlist->get_number_shortname(rno))+250];
      sprintf(tempstring, "No 'active' numbers are left!  Sending %s.\n", ecmlist->get_number_shortname(rno));
      log(logname, tempstring);
      delete tempstring;
   } else {
      // Random selection from list...
      while ( ('u' == (ecmlist->get_number_base10rep(rno))[0] ) || (!ecmlist->is_active(rno)) ) {
         rno = 1 + (rno % ecmlist->get_number_of_numbers());
      }
      if (this_strategy == 0) {
         // Use the random one from above.
      } else if ( this_strategy == 1) {
         // Min b1

         // Get a valid "Active" bestb1 value...
         selec = ecmlist->get_bestb1(rno);

         // Get the minimum of all bestb1 values...
         for (int i=0;i<ecmlist->get_number_of_numbers();i++) {
            if ( ('u' != (ecmlist->get_number_base10rep(i+1))[0] )
                  && (ecmlist->is_active(i+1)) ) {
               selec = min(selec, ecmlist->get_bestb1(i+1));
            }
         }

         // Now Go through list from a random starting point until we find one with the same B1...
         rno = 1 + (rand() % ecmlist->get_number_of_numbers() );
         selec2 = ecmlist->get_bestb1(rno);
         while ( (fabs(selec2-selec)>1. )
                  || ('u' == (ecmlist->get_number_base10rep(rno))[0] )
                  || (!ecmlist->is_active(rno)) ) {
            rno = 1 + (rno % ecmlist->get_number_of_numbers());
            selec2 = ecmlist->get_bestb1(rno);
         }

      } else if ( this_strategy == 2) {
         // Min sum(b1)

         // Get a valid "Active" sumb1 value...
         selec = ecmlist->get_sumb1(rno);

         // Get the minimum of all sumb1 values...
         for (int i=0;i<ecmlist->get_number_of_numbers();i++) {
            if ( ('u' != (ecmlist->get_number_base10rep(i+1))[0] )
                  && (ecmlist->is_active(i+1)) ) {
                  selec = min(selec, ecmlist->get_sumb1(i+1));
            }
         }

         // Now Go through list from a random starting point until we find
         // one with the same sum(B1)...
         rno = 1 + (rand() % ecmlist->get_number_of_numbers() );
         selec2 = ecmlist->get_sumb1(rno);
         while ( (fabs(selec2-selec) > 1. )
                  || ('u' == (ecmlist->get_number_base10rep(rno))[0] )
                  || (!ecmlist->is_active(rno)) ) {
            rno = 1 + (rno % ecmlist->get_number_of_numbers());
            selec2 = ecmlist->get_sumb1(rno);
         }
      } else if ( this_strategy == 3) {
         // Min work

         // Get a valid "Active" work value...
         selec = ecmlist->get_work(rno);
         // Get the minimum of all sumb1 values...
         for (int i=0;i<ecmlist->get_number_of_numbers();i++) {
            if ( ('u' != (ecmlist->get_number_base10rep(i+1))[0] )
                  && (ecmlist->is_active(i+1)) ) {
               selec = min(selec, ecmlist->get_work(i+1));
            }
         }
         // Now Go through list from a random starting point until we find
         // one with the same 'work'...
         rno = 1 + (rand() % ecmlist->get_number_of_numbers() );
         selec2 = ecmlist->get_work(rno);
         while ( (fabs(selec2-selec) > 1. )
                  || ('u' == (ecmlist->get_number_base10rep(rno))[0] )
                  || (!ecmlist->is_active(rno)) ) {
            rno = 1 + (rno % ecmlist->get_number_of_numbers());
            selec2 = ecmlist->get_work(rno);
         }
      } else {
         // Min len(n)

         // Get a valid "Active" work value...
         selec = strlen(ecmlist->get_number_base10rep(rno));

         // Get the minimum of the length of all active composites...
         for (int i=0;i<ecmlist->get_number_of_numbers();i++) {
            if ( ('u' != (ecmlist->get_number_base10rep(i+1))[0] )
                  && (ecmlist->is_active(i+1)) ) {
               selec = min(selec, strlen(ecmlist->get_number_base10rep(i+1)) );
            }
         }
         // Now Go through list from a random starting point until we find
         // one with the same # of digits...
         rno = 1 + (rand() % ecmlist->get_number_of_numbers() );
         selec2 = strlen(ecmlist->get_number_base10rep(rno));
         while ( (fabs(selec2-selec) > 1. )
                  || ('u' == (ecmlist->get_number_base10rep(rno))[0] )
                  || (!ecmlist->is_active(rno)) ) {
            rno = 1 + (rno % ecmlist->get_number_of_numbers());
            selec2 = strlen(ecmlist->get_number_base10rep(rno));
         }
      }
   }

   tempstring = new char[20+strlen(ecmlist->get_number_shortname(rno))];
   sprintf(tempstring, "ECMname: %s\n", ecmlist->get_number_shortname(rno));
   putstring(s, tempstring);
   delete tempstring;

   tempstring = new char[20+strlen(ecmlist->get_number_base10rep(rno)) ];
   sprintf(tempstring, "ECMnumber: %s\n", ecmlist->get_number_base10rep(rno));
   putstring(s, tempstring);
   delete tempstring;

   tempstring = new char[BUFFERSIZE]; // how big can a %.0lf actually get?
   int maxncurves=0;
   sprintf(tempstring, "ECMB1: %.0lf\n", (b1 = max(minb1, ecmlist->get_bestb1(rno, &maxncurves))) );
   putstring(s, tempstring);
   delete tempstring;
   tempstring = new char[250];
   if ((ecmlist->get_bestb1(rno) != b1) || (maxncurves==0)) {
      // This must have been because of the minb1 parameter being applied.
      sprintf(tempstring, "ECMCurves: 1\n");
   } else {
      sprintf(tempstring, "ECMCurves: 1:%d\n", maxncurves);
   }
   putstring(s, tempstring);
   delete tempstring;

   tempstring = new char[250+strlen(ecmlist->get_number_shortname(rno)) ];
   sprintf(tempstring, ">>> %s / B1=%.0lf / 1-%d curves\n", ecmlist->get_number_shortname(rno), b1, maxncurves);
   log(logname,tempstring);
   delete tempstring;
}

void admin_query(int s, ecm_list * ecmlist, int k) {
   int i;
   char * tempstring;

   tempstring = new char[100+strlen(ecmlist->get_number_shortname(k))];
   sprintf(tempstring, "%s (%s%s):  _n%d\r\n", ecmlist->get_number_shortname(k),
           (ecmlist->is_active(k)?"Active":"Not Active"),
           (ecmlist->is_LocalControl(k)?" (local control)":""),
           strlen(ecmlist->get_number_base10rep(k) ));
   putstring(s, tempstring);
   delete tempstring;

   putstring(s, ecmlist->get_number_base10rep(k));
   putstring(s, "\r\n");

   tempstring = new char[1000];
   for ( i=0 ; i < ecmlist->get_number_of_b1details( k ) ; i++ ) {
      if ( ecmlist->get_number_b1details_b1( k, i) != 0. ) {
         sprintf(tempstring,"   b1: %.0lf  curves: %d %d %d\r\n",
                 ecmlist->get_number_b1details_b1( k, i ),
                 ecmlist->get_number_b1details_curves( k, i ),
                 ecmlist->get_number_b1details_curves_from_downstream( k, i ),
                 ecmlist->get_number_b1details_curves_for_upstream( k, i ));
         putstring(s, tempstring);
      }
   }

   sprintf(tempstring, "   Sum(B1): %.0lf  work: %.0lf\n",ecmlist->get_sumb1(k),ecmlist->get_work(k));
   putstring(s, tempstring);

   delete tempstring;

   if (ecmlist->get_number_of_factors(k) == 0) {
      putstring(s,"   No known factors.\r\n");
   } else {
      for ( i=0 ; i<ecmlist->get_number_of_factors(k) ; i++ ) {
         tempstring = new char[100+strlen(ecmlist->get_factor_details_factor(k, i))
                        +strlen(ecmlist->get_factor_details_finder(k, i))];
         sprintf(tempstring,"   Factor #%d: %s\r\n     Found by: %s\r\n     B1: %.0lf\r\n     Sigma: %.0lf\r\n",i+1,
                ecmlist->get_factor_details_factor(k, i),
                ecmlist->get_factor_details_finder(k, i),
                ecmlist->get_factor_details_b1level(k, i),
                ecmlist->get_factor_details_sigma(k, i)    );
         putstring(s, tempstring);
         delete tempstring;
      }
   }
}

void admin_status(int s, ecm_list * ecmlist, int activeflag) {
   char * tempstring;

   for (int i = 1 ; i<= ecmlist->get_number_of_numbers() ; i++) {
      if ((!activeflag) || (activeflag && (ecmlist->is_active(i)))  ) {
         tempstring = new char[250+strlen(ecmlist->get_number_shortname(i))];
         sprintf(tempstring, "%17s %s%s: _n%3d B1:%8.0lf F:%d S(B1):%8.0lf Work:%9.0lf\r\n",
                 ecmlist->get_number_shortname(i)             ,
                 ecmlist->is_LocalControl(i)?"(L":" ("        ,
                 ecmlist->is_active(i)?"Act)  ":"InAct)"        ,
                 strlen(ecmlist->get_number_base10rep(i) )    ,
                 ecmlist->get_bestb1(i)                       ,
                 ecmlist->get_number_of_factors(i)            ,
                 ecmlist->get_sumb1(i)                        ,
                 ecmlist->get_work(i)                         );
         putstring(s, tempstring);
         delete tempstring;
      }
   }
}

void admin_sendfile(int s, char * filename, int requirefinalCR) {
   FILE * fp;
   char * line;

   if ( (fp = fopen(filename,"rt")) == NULL ) {
      printf("Can't open file:%s\n",filename);
      return;
   }

   line = (char *) malloc( 10001 );
   if ( line == NULL ) {
      printf("malloc error!\n");
      fclose(fp);
      return;
   }

   while ( fgets(line, 10000 ,fp) != NULL ) putstring(s, line);

   if ((line[strlen(line)-1] != '\n') && (requirefinalCR)) putstring(s, "\n");

   free( line );
   fclose(fp);
   return;
}

void admin(int s, ecm_list * ecmlist, char * fromip, char * fromname,
           char * adminpass, char * pass2) {
   char * buf2;
   char * ptr1;
   int k,quit=0;
   char * tempstring;
   int adminpassok=0;

   // First, make sure that the right admin password was supplied...
   if ( ( strlen(adminpass) > 0 ) && (strcmp(adminpass, pass2) == 0)) {
      tempstring = new char[strlen(fromip)+strlen(fromname)+100];
      sprintf(tempstring, "Admin access from %s/%s\n",fromip, fromname);
      log("Admin.log",tempstring);
      delete tempstring;
      adminpassok=1;
   } else {
      if (strcmp(pass2,"-") != 0) {
         tempstring = new char[100+strlen(pass2)+strlen(fromname)];
         sprintf(tempstring, "Invalid admin password '%s' from %s\n",pass2, fromname);
         log("Admin.log",tempstring);
         delete tempstring;
      }
      adminpassok=0;
   }

   while ( !quit ) {
      buf2 = getstring(s);
		if ( buf2==NULL ) {
			quit=1;
		} else if ( strlen(buf2)==0 ) {
         quit=1;
      } else {

         tempstring = new char[strlen(buf2)+2];
         strcpy(tempstring, buf2);
         strcat(tempstring, "\n");
         log("Admin.log", tempstring);
         delete tempstring;

         if ( strncmp(buf2, "ADMIN_QUIT", 10)==0 ) {
            quit=1;
            strcpy(logmsg,"");
         } else if ( strncmp(buf2, "ADMIN_QUERY NAME ", 17)==0 ) {
            k = ecmlist->get_index( buf2+17 );
            if (k==0) {
               sprintf(logmsg, "ERR: %s Not found.\n",buf2+17);
            } else {
               admin_query(s, ecmlist, k);
               strcpy(logmsg,"OK.\n");
            }
         } else if ( strncmp(buf2, "ADMIN_QUERY NUMBER ", 19)==0 ) {
            k = ecmlist->get_index_base10( buf2+19 );
            if (k==0) {
               strcpy(logmsg, "ERR: Not found.\n");
            } else {
               admin_query(s, ecmlist, k);
               strcpy(logmsg,"OK.\n");
            }
         } else if ( strncmp(buf2, "ADMIN_SETACTIVE ", 16)==0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               k = ecmlist->get_index( buf2+16 );
               if (k==0) {
                  sprintf(logmsg, "ERR: %s Not found.\n",buf2+16);
               } else {
                  if (ecmlist->is_active(k)) {
                     sprintf(logmsg, "ERR: %s is already active.\n", buf2+16);
                  } else {
                     ecmlist->SetActive( k );
                     strcpy(logmsg,"OK.\n");
                  }
               }
            }
         } else if ( strncmp(buf2, "ADMIN_SETINACTIVE ", 18)==0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               k = ecmlist->get_index( buf2+18 );
               if (k==0) {
                  sprintf(logmsg, "ERR: %s Not found.\n",buf2+18);
               } else {
                  if (ecmlist->is_active(k)) {
                     ecmlist->SetInActive( k );
                     strcpy(logmsg,"OK.\n");
                  } else {
                     sprintf(logmsg, "ERR: %s Is already inactive.\n", buf2+18);
                  }
               }
            }
         } else if ( strncmp(buf2, "ADMIN_SETLOCAL ", 15)==0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               k = ecmlist->get_index( buf2+15 );
               if (k==0) {
                  sprintf(logmsg, "ERR: %s Not found.\n",buf2+15);
               } else {
                  if (ecmlist->is_LocalControl(k)) {
                     sprintf(logmsg, "ERR: %s is already under local control.\n", buf2+15);
                  } else {
                     ecmlist->SetLocalControl( k );
                     strcpy(logmsg,"OK.\n");
                  }
               }
            }
         } else if ( strncmp(buf2, "ADMIN_UNSETLOCAL ", 17)==0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               k = ecmlist->get_index( buf2+17 );
               if (k==0) {
                  sprintf(logmsg, "ERR: %s Not found.\n",buf2+17);
               } else {
                  if (ecmlist->is_LocalControl(k)) {
                     ecmlist->UnsetLocalControl( k );
                     strcpy(logmsg,"OK.\n");
                  } else {
                     sprintf(logmsg, "ERR: %s Is not under local control.\n", buf2+17);
                  }
               }
            }
         } else if ( strncmp(buf2, "ADMIN_NEW ", 10)==0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               ptr1 = strchr(buf2+10, ' ');
               if (ptr1 != NULL) {
                  *ptr1=0;
                  if (ecmlist->get_index( buf2+10 ) == 0) {
                     ecmlist->StoreDetails( buf2+10, ptr1+1);
                     strcpy(logmsg,"OK.\n");
                  } else {
                     sprintf(logmsg, "ERR: Already in database.");
                  }
               } else {
                  sprintf(logmsg, "ERR: Badly formed command");
               }
            }
         } else if ( strncmp(buf2, "ADMIN_STATUS_ACTIVE", 19) == 0) {
            admin_status(s, ecmlist,1);
            strcpy(logmsg,"OK.\n");
         } else if ( strncmp(buf2, "ADMIN_STATUS", 12) == 0 ) {
            admin_status(s, ecmlist,0);
            strcpy(logmsg,"OK.\n");
         } else if ( strncmp(buf2, "ADMIN_GETINI", 12) == 0 ) {
            if (!adminpassok) {
               putstring(s, "ERR: Invalid pass\r\n");
            } else {
               admin_sendfile(s, "ecmserver.ini", 0);
               strcpy(logmsg,"OK.\n");
            }
         } else if ( strncmp(buf2, "ADMIN_GETFACTORS", 16) == 0 ) {
            admin_sendfile(s, "Factors.log", 0);
            strcpy(logmsg,"OK.\n");
         } else {
            printf("%s\n", buf2);
            quit=1;
            sprintf(logmsg, "?\n");
         }

         // Send any composed message...
         if (strlen(logmsg) > 0) {
            putstring(s, logmsg);
            log("Admin.log", logmsg);
         }

         // Update the INI file if needed...
         ecmlist->WriteDetails_as_required(); // Commit changes
      }
      if (buf2!=NULL) free(buf2);
   }
   log("Admin.log","Admin control exited\n" );
}

int process_connection(int s, struct sockaddr_in * Sin, ecm_list * ecmlist,
                        int noremove, int * totcurves,
                        double * totb1, double * totwork, int * totfactors, char * adminpass,
                        user * users1, user * users2a, user * users2b,
                        user * curvelist, user * dailywork,
                        int strategy[6], int recurse, double minb1,
                        char * destid, char * smtpserver, int smtpport, char * fromid) {
   char * buf1;
   char * buf2;
   int quit=0;
   char fromname[250];
   char * finderstring;
   char * factorname;
   int plength;
   char * tempstring;
   char * subject;
   int retval=0;

   strcpy(fromname, "");

   // Get some connection information...
   buf2 = getstring(s);
	if (buf2==NULL) {
      sprintf(logmsg,"Dropped connection due to missing 'FROM' identifier.\n");
      log(logname, logmsg);
      putstring(s, "Expected 'FROM' identifier\n");
      closesocket(s);
	} else if ( strncmp(buf2, "FROM ", 5) == 0) {
      strncpy(fromname, buf2+5, 249);
      fromname[249] = 0;
      sprintf(logmsg, "***** %s/%s\n", inet_ntoa(Sin->sin_addr), fromname );
      log(logname,logmsg);

      while ( !quit ) {
         free(buf2);
         buf2 = getstring(s);
			if ( buf2==NULL ) {
				quit=1;
			} else if ( strlen(buf2)==0 ) {
            quit=1;
         } else {
            if ( strncmp(buf2, "QUIT", 4)==0 ) {
               quit=1;
            } else if ( strncmp(buf2, "GETWORK", 7)==0 ) {
               getwork(s, ecmlist, strategy, minb1);
            } else if ( strncmp(buf2, "RETURNWORK", 10)==0 ) {
               acceptwork(s, ecmlist, totcurves, totb1, totwork, fromname, users1, users2a, users2b, curvelist, dailywork);
            } else if ( strncmp(buf2, "RETURNFACTOR", 12)==0 ) {
               plength=0;
               buf1=returnfactor(s, ecmlist, noremove, fromname, totfactors, users1,
                                 users2a, users2b, curvelist, dailywork, recurse,
                                 &finderstring, &factorname, &plength);

               if (buf1 != NULL) {
						if ((smtpserver != NULL) && (finderstring != NULL) && (factorname != NULL)) {
							tempstring = new char[strlen(destid)+strlen(finderstring)+5];
							sprintf(tempstring, "%s,%s", destid, finderstring);

							subject = new char[strlen(factorname)+100];
							sprintf(subject, "p%d factor of %s found by ECMNet!", plength, factorname);

							sendmessage(buf1, subject, tempstring, smtpserver, smtpport, fromid);

							free(subject);
							free(tempstring);
						}
						free(buf1);
					}
               retval=1;

					if (factorname != NULL) free(factorname);
               if (finderstring != NULL) free(finderstring);
            } else if ( strncmp(buf2, "GETB1DET ", 9) == 0) {
               buf1=ecmlist->get_allb1info( buf2+9 );
               putstring(s, buf1);
               putstring(s, "\nOK.\n");
               free(buf1);
            } else if ( strncmp(buf2, "GETBASE10 ", 10) == 0) {
			   buf1=ecmlist->get_number_base10rep( buf2+10 );
			   if (buf1==NULL) {
				   putstring(s, "" );
			   } else {
				   putstring(s, buf1 );
			   }
               putstring(s, "\nOK.\n");
            } else if ( strncmp(buf2, "GETFAC ", 7) == 0) {
               int k = ecmlist->get_index(buf2+7);
               if (k!=0) {
                  for (int i=0 ; i<ecmlist->get_number_of_factors(k) ; i++) {
                     buf1 = ecmlist->get_facinfo( buf2+7, i );
                     putstring(s, buf1);
                     putstring(s, "\n");
                     free(buf1);
                  }
               }
               strcpy(logmsg,"OK.\n");
               putstring(s, logmsg);
            } else if ( strncmp(buf2, "GETACTIVES", 10) == 0) {
               ecmlist->get_activeinfo(logmsg);
               strcat(logmsg, "\n");
               putstring(s, logmsg);
               strcpy(logmsg,"OK.\n");
               putstring(s, logmsg);
            } else if ( strncmp(buf2, "ADMIN ", 6)==0 ) {
               admin(s, ecmlist, inet_ntoa(Sin->sin_addr), fromname, adminpass, buf2+6);
            } else if ( strncmp(buf2, "GETGREETING",11) == 0 ) {
               if (upstreamgreeting[0] != 0) putstring(s, upstreamgreeting);
               if (!ecmlist->get_number_of_numbers()) putstring (s, "Server is not initialized, please try again later\n");
               admin_sendfile(s, "Greeting.txt", 1);
               strcpy(logmsg,"OK.\n");
               putstring(s, logmsg);
            } else {
               printf("%s\n", buf2);
               putstring(s, "?\n");
            }
            ecmlist->WriteDetails_as_required(); // Commit changes
         }
      }
      closesocket(s);
      printf("[%s] ***** Connection closed\r", Time());
   } else {
      sprintf(logmsg,"Dropped connection due to missing 'FROM' identifier.\n");
      log(logname, logmsg);
      putstring(s, "Expected 'FROM' identifier\n");
      closesocket(s);
   }
   if (buf2!=NULL) free(buf2);
   getstring(-1);

   return retval;
}

void Usage(char *name) {
   printf("Usage: %s [-p port#] [-echoini] [-noremove] [-pass pwd] [-idle | -noidle] [-hide] [-loglimit n] [-slave] [-curdir dir] [-strategy n] [-recurse] [-minb1 b1]\n",name);
   printf("    -p port #  Specify port number to listen on.\n");
   printf("    -echoini   Echo information read from ini file to screen.\n");
   printf("    -noremove  prevent numbers from being labelled as\n"
          "               inactive once a factor is returned\n",name);
   printf("    -pass pwd  Configure password for remote server administration\n");
   printf("    -idle      Run in idle priority class\n");
   printf("    -noidle    Do not run in idle priority class\n");
#ifdef WIN32
   printf("    -hide      Remove the console window\n");
#endif
   printf("    -slave     Mirror the upstream server's Active composite list\n");
   printf("    -email id  Set your email id\n");
   printf("    -upstream  Active upstream communications\n");
   printf("    -upstreamserver IP   Set upstream server IP\n");
   printf("    -upstreamport port   Set upstream port\n");
   printf("    -loglimit n          Limit log size to 'n' bytes\n");
   printf("    -curdir dir          Make 'dir' the current directory\n");
   printf("    -strategy n          Specify strategy (see ecmserver.cfg for details)\n");
   printf("    -recurse             Activate any composite cofactors found\n");
   printf("    -minb1 b1            Ensures that no B1 is distributed less than 'b1'\n");
   printf("    -smtpserver server   Specify smtp server name\n");
   printf("    -smtpport port       Specify smtp server port\n");
   printf("    -destid              Specify who to send mail to when factors found\n");
   printf("    -fromid              Specify who mail is 'from'\n");
}

int docomms(int s, ecm_list * ecmlist, int noremove, int slavemode) {
   int errflag=0;
   char * buf;
   char * buf2;
   char * buf3;
	char * buf4;
   char * ptr2;
   char * name;
   int activesstored=0;

   if (!slavemode) {
      errflag = returnwork(s, ecmlist, 1, noremove); // 1 means close the socket
   } else {
      // If we're in 'slave' mode, then...
      // i) Get a list of active numbers from server
      // ii) Get base10 representation of those we don't already have.
      // iii) Ensure all these are 'active' (including whatever already was) (except local control #s)
      // iv) Do the returnwork() (which will update b1 information there, then here (including new factors)).
      // v) Make only those received in (i) active (subject to LocalControl flag)
      putstring(s, "GETACTIVES\n");
      buf2 = getstring(s);
		buf3 = getstring(s);
		if (buf3 != NULL) free( buf3 ); // Throw away "OK."
		if (buf2 == NULL) {
         printf("[%s] Connection dropped.                         \n", Time());
         errflag=-1;
         closesocket(s);
         getstring(-1);
		} else if (strlen(buf2) == 0) {
			free(buf2);
         printf("[%s] Connection dropped.                         \n", Time());
         errflag=-1;
         closesocket(s);
         getstring(-1);
      } else {
         stripCRLF(buf2);
         // Make a copy of the returned string...
         buf3 = new char[strlen(buf2)+1];
         strcpy(buf3, buf2);

         while ((errflag>=0) && ((ptr2=strrchr(buf2, ' ')) != NULL)) {
            name = ptr2+1;
            *ptr2=0;

            if (0 == ecmlist->get_index(name)) {
               // Not in our list
               sprintf(logmsg, "GETBASE10 %s\n",name);
               putstring(s, logmsg);
               buf = getstring(s);
					buf4 = getstring(s);
               if (buf4!=NULL) free( buf4 ); // Throw away "OK"
					if (buf==NULL) {
                  printf("[%s] Connection dropped.                         \n", Time());
                  errflag=-1;
                  closesocket(s);
                  getstring(-1);
					} else if (strlen(buf) != 0) {
                  // Store it and make it active.
                  ecmlist->StoreDetails( name , buf );
                  ecmlist->SetActive( name );
                  activesstored++; // activesstored counts how many in our list will remain active
                  sprintf(logmsg, "%s (new) switched to active to mirror server.\n", name);
                  log(logname, logmsg);
               } else {
                  printf("[%s] Connection dropped.                         \n", Time());
                  errflag=-1;
                  closesocket(s);
                  getstring(-1);
               }
               if (buf!=NULL) free(buf);
            } else {
               if (!ecmlist->is_LocalControl( name )) {
                  // Make it active...
                  if (! ecmlist->is_active( name )) {
                     ecmlist->SetActive( name );
                     sprintf(logmsg, "%s switched to active to mirror server.\n", name);
                     log(logname, logmsg);
                  }
                  activesstored++; // activesstored counts how many in our list will remain active
               }
            }
         } // done parsing GETACTIVES list.
         if (buf2!=NULL) free(buf2);

         if (errflag>=0) {
            errflag = returnwork(s, ecmlist, 1, noremove); // 1 means close the socket
         }

         // Now, ensure that only those which the server had labelled as active remain
         // active in our list...

         // Be careful not to turn everything 'inactive' unless at least one number was
         // properly retrieved from the server as 'active'...
         if ((errflag != -1) && (activesstored > 0) ) {
            for (int i=0 ; i<ecmlist->get_number_of_numbers() ; i++) {
               if (ecmlist->is_active(i+1) && !ecmlist->is_LocalControl(i+1)) {
                  if (NULL == strstr(buf3, ecmlist->get_number_shortname(i+1))) {
                     ecmlist->SetInActive( i+1 );
                     sprintf(logmsg, "%s switched to Inactive to mirror server.\n",
                             ecmlist->get_number_shortname(i+1) );
                     log(logname, logmsg);
                  } else {
                     // This is in the list, but we can deactivate it if there's a known factor...
                     // This section gets called when WE found the factor...the above 'returnwork' will flip
                     // the server's active flag to inactive, but we've already got our list of actives at the
                     // top of this function.
                     if ((ecmlist->get_number_of_factors( i+1 ) > 0 ) && (!noremove)) {
                        ecmlist->SetInActive( i+1 );
                     }
                  }
               }
            }
         }
         delete buf3;
      }
   }
   return errflag;
}

#if defined(NTSERVICE)
int actualmain(int argc, char * argv[])
#else
int main(int argc, char *argv[])
#endif
{
   int sinlen, s, snew, s_upstream, listenport=8194;
   int elapseds=0, echoini=0, noremove=0, totcurves=0, totfactors=0;
   int timeh=0, timem=0, times=0;
   int hide=0;
   int strategy[6];
   strategy[0]=strategy[1]=strategy[2]=strategy[3]=strategy[4]=0; // no distribution strategy yet
   int recurse=0;
   int slavemode=0;
   int allow2=0;
   double minb1=11000;
   double totb1=0.0;
   double totwork=0.0;
   char inifile[200];
   char userfile1[200];
   char userfile2a[200];
   char userfile2b[200];
   char curvelistfile[200];
   char dailyworkfile[200];
   char * ptr;
   char adminpass[200];
   ecm_list ecmlist;
   user users1;
   user users2a;
   user users2b;
   user curvelist;
   user dailywork;
   int userthreshold=0;
   struct sockaddr_in Sin;
   time_t timestart;
   time_t timelast;
   int idle=0;
   int exitflag=0;
   char cfgfile[200];
   FILE * fp;
   char line[240];
   int enableupstream=0;
   int enable_factors_up_immediate=0;
   int uploadreq=0;
   char email[150];
   char curdir[300];
   char upstreamserver[200];
   int upstreamport=8194;
   int maxfreq=720; // 12 hours == 720 minutes
   int i,j,k,errtimeout=20; // 20 minute timeout by default
   double nextupstreamconnect=0;
   int errflag;
   char *smtpserver, *destid, *fromid;
   int smtpport=25;
   int retval;
   int inisorttype=0; // No sorting by default

   smtpserver=destid=fromid=NULL;

   timelast = timestart = time( NULL );
   srand(timestart);

   strcpy(adminpass,""); // Initialize to empty.
   strcpy(upstreamserver, "127.0.0.1");
   strcpy(email,"");
   strcpy(curdir,"");

   logmsg = new char[BUFFERSIZE];
   upstreamgreeting = new char[BUFFERSIZE];
   upstreamgreeting[0]=0;
   loglimit=0;

   // Process any CFG file supplied...
   strcpy(cfgfile, argv[0]);
   ptr = strrchr(cfgfile,'/');
   if (ptr == NULL) {
      ptr = strrchr(cfgfile,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcat(cfgfile, ".cfg");

   if ( (fp = fopen(cfgfile,"r")) == NULL ) {
      printf("'%s' not found\n",cfgfile);
   } else {
      while ( fgets(line,239,fp) != NULL ) {
         stripCRLF(line);
         if ( strncmp(line, "email=", 6) == 0) {
            strcpy(email, line+6);
         } else if ( strncmp(line, "listenport=", 11) == 0) {
            listenport = atoi( line+11 );
         } else if ( strncmp(line, "curdir=", 7) == 0) {
            strcpy(curdir, line+7);
         } else if ( strncmp(line, "idle=1", 6) == 0) {
            idle=1;
         } else if ( strncmp(line, "idle=0", 6) == 0) {
            idle=0;
         } else if ( strncmp(line, "hide=1", 6) == 0) {
            hide=1;
         } else if ( strncmp(line, "strategy=", 9) == 0) {
            // If the row is of the type "strategy=1:10" then the second number is the weight.
            // Otherwise, only one strategy is used.
            k = atoi( line+9 );
            if (k<0) k=0;
            if (k>4) k=4;
            if ((ptr=strchr(line+9, ':')) == NULL) {
               strategy[0]=strategy[1]=strategy[2]=strategy[3]=strategy[4]=0;
               strategy[k] = 1;
            } else {
               strategy[k] = atoi(ptr+1);
            }
         } else if ( strncmp(line, "recurse=1", 9) == 0) {
            recurse = 1;
         } else if ( strncmp(line, "userthreshold=", 14) == 0) {
            userthreshold=atoi(line+14);
         } else if ( strncmp(line, "slave=1", 7) == 0) {
            slavemode=1;
         } else if ( strncmp(line, "debug=1", 7) == 0) {
            setdebug();
         } else if ( strncmp(line, "allow2=1", 8) == 0) {
            allow2=1;
         } else if ( strncmp(line, "minb1=", 6) == 0) {
            minb1=atol(line+6);
         } else if ( strncmp(line, "maxfreq=", 8) == 0) {
            maxfreq = atoi( line+8 );
         } else if ( strncmp(line, "loglimit=", 9) == 0) {
            loglimit = atol( line+9 );
         } else if ( strncmp(line, "errtimeout=",11) == 0) {
            errtimeout = atoi(line+11);
         } else if ( strncmp(line,"noremove=1",10)==0 ) {
            noremove=1;
         } else if ( strncmp(line,"pass=",5) == 0) {
            strcpy(adminpass,line+5);
         } else if ( strncmp(line, "upstream=1",10) == 0) {
            enableupstream=1;
         } else if ( strncmp(line, "upstreamserver=", 15) == 0) {
            strcpy(upstreamserver, line+15);
         } else if ( strncmp(line, "upstreamport=", 13) == 0) {
            upstreamport = atoi( line+13 );
         } else if ( strncmp(line, "upstream_factors_immediate=", 27) == 0 ) {
            enable_factors_up_immediate = atoi(line+27);
         } else if ( strncmp(line, "smtpserver=", 11) == 0) {
            smtpserver = new char[strlen(line+11)+1];
            strcpy(smtpserver, line+11);
         } else if ( strncmp(line, "smtpport=", 9) == 0) {
            smtpport=atoi(line+9);
         } else if ( strncmp(line, "destid=", 7) == 0) {
            destid = new char[strlen(line+7)+1];
            strcpy(destid, line+7);
         } else if ( strncmp(line, "fromid=", 7) == 0) {
            fromid = new char[strlen(line+7)+1];
            strcpy(fromid, line+7);
         } else if ( strncmp(line, "inisorttype=", 12) == 0) {
            inisorttype=atoi(line+12);
         }
      }
      fclose(fp);
   }

   // Process the command line...
   for ( i=1; i<argc; i++ ) {
      if ( strcmp(argv[i],"-echoini")==0 ) {
         echoini=1;
      } else if ( strcmp(argv[i],"-noremove")==0 ) {
         noremove=1;
      } else if ( strcmp(argv[i],"-idle") == 0 ) {
         idle=1;
      } else if ( strcmp(argv[i],"-noidle") == 0 ) {
         idle=0;
      } else if ( strcmp(argv[i], "-hide") == 0) {
         hide=1;
      } else if ( strcmp(argv[i], "-recurse") == 0) {
         recurse=1;
      } else if ( strcmp(argv[i], "-slave") == 0) {
         slavemode=1;
      } else if ( strcmp(argv[i], "-allow2") == 0) {
         allow2=1;
      } else if ( strcmp(argv[i], "-debug") == 0) {
         setdebug();
      } else if ( strcmp(argv[i], "-upstream_factors_immediate") == 0 ) {
         enable_factors_up_immediate = 1;
      } else if ( strcmp(argv[i], "-upstream") == 0) {
         enableupstream=1;
		} else if (i+1 < argc) {
			if ( strcmp(argv[i], "-minb1") == 0) {
				minb1=atol(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-pass") == 0) {
				strcpy(adminpass,argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-maxfreq") == 0) {
				maxfreq = atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-loglimit") == 0) {
				loglimit = atol(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i],"-curdir") == 0 ) {
				strcpy(curdir, argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-email") == 0) {
				strcpy(email,argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-upstreamserver") == 0) {
				strcpy(upstreamserver,argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-upstreamport") == 0) {
				upstreamport = atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-smtpserver") == 0) {
				smtpserver = new char[strlen(argv[i+1])+1];
				strcpy(smtpserver, argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-smtpport") == 0) {
				smtpport=atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-destid") == 0) {
				destid = new char[strlen(argv[i+1])+1];
				strcpy(destid, argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-fromid") == 0) {
				fromid = new char[strlen(argv[i+1])+1];
				strcpy(fromid, argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-inisorttype") == 0) {
				inisorttype=atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i],"-p")==0 ) {
				listenport=atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-userthreshold") == 0) {
				userthreshold=atoi(argv[i+1]);
				i++;
			} else if ( strcmp(argv[i], "-strategy") == 0) {
				// Command line strategy means use only the one strategy...
				strategy[0]=strategy[1]=strategy[2]=strategy[3]=strategy[4]=0;
				k = atoi(argv[i+1]);
				if (k<0) k=0;
				if (k>4) k=4;
				strategy[ k ] = 1;
				i++;
			}
		} else {
         Usage(argv[0]);
         return (0);
      }
   }

   if (strlen(email) == 0) {
      printf("An email address must be configured with '-e'.  '%s -help' for help.\n",argv[0]);
      exit(-1);
   }
   if (NULL==strchr(email,'@') ) {
      printf("Email address supplied (%s) is not valid.\n",email);
      exit(-1);
   }

   strcat(email,":server:");
   sprintf(logmsg, "v%d.%d%c", VERSIONMAJOR, VERSIONMINOR,VERSIONMINOR2);
   strcat(email, logmsg);

   if (strlen(curdir) > 0) chdir(curdir);

#ifdef WIN32
   if (idle) {
      SetPriorityClass( GetCurrentProcess(), IDLE_PRIORITY_CLASS );
      SetThreadPriority(GetCurrentThread() ,THREAD_PRIORITY_IDLE );
      printf("Server will run in idle class.\n");
   }

   if (hide) FreeConsole();
#endif

#ifdef UNIX
   // Courtesy of RZG <gevaryah@netaxs.com> October 2, 1998...
   if (idle) {
     if (nice(20) == -1) printf("Warning: Could not nice!\n");
   }
   /* Ignore SIGHUP, as to not die on logout.
      We log to file in most cases anyway. */
   signal(SIGHUP, SIG_IGN);
   signal(SIGUSR1, gotusr1);
   signal(SIGTERM, gotdie);
   signal(SIGINT, gotdie);
#endif

   if (loglimit<0) loglimit = 0;
   if (userthreshold<0) userthreshold=0;
   if (maxfreq<15) maxfreq=15;

   if (errtimeout<1) errtimeout=1;

   strcpy(logname, argv[0]);
   ptr = strrchr(logname,'/');
   if (ptr == NULL) {
      ptr = strrchr(logname,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcat(logname, ".log");

   /* read in the configuration settings */
   strcpy(inifile, argv[0]);
   ptr = strrchr(inifile,'/');
   if (ptr == NULL) {
      ptr = strrchr(inifile,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcat(inifile, ".ini");

   ecmlist.sorttype=inisorttype;
   if ( ecmlist.LoadDetails( inifile )) {
      sprintf(logmsg, "Couldn't open %s\n", inifile );
      log(logname,logmsg);
	  if (!slavemode) {
		  return (0);
	  } else {
		  sprintf(logmsg, "No composites will be distributed until an upstream server connection is completed.\n");
		  log(logname,logmsg);
          nextupstreamconnect = difftime(time(NULL), timestart)+15.; // 15s from now
	  }
   }

   if ( echoini ) {
      ecmlist.printnumberlist(1);                // 1 means don't actually print the numbers.
      fflush(stdout);
   }

   /* read in the user stats settings */
   /* This WILL NEED TO BE REMOVED when the # of users is too big */
   strcpy(userfile1, argv[0]);
   ptr = strrchr(userfile1,'/');
   if (ptr == NULL) {
      ptr = strrchr(userfile1,'.');
   } else {
      ptr = strchr(ptr+1, '.');
   }
   if ( ptr!=NULL ) *ptr=0;
   strcpy(userfile2a, userfile1);
   strcpy(userfile2b, userfile1);
   strcpy(curvelistfile, userfile1);
   strcpy(dailyworkfile, userfile1);
   strcat(userfile1, ".usr");
   strcat(userfile2a, ".us2");
   strcat(userfile2b, ".us1");
   strcat(curvelistfile, ".crv");
   strcat(dailyworkfile, ".daily");


   if (userthreshold > 0) {
      if ( users1.LoadUsers( userfile1, userthreshold ) ) {
         sprintf(logmsg, "Couldn't open %s\n", userfile1 );
         log(logname,logmsg);
      }
      users1.sorttype=1;

      if ( users2a.LoadUsers( userfile2a, userthreshold ) ) {
         sprintf(logmsg, "Couldn't open %s\n", userfile2a );
         log(logname,logmsg);
      }
      users2a.sorttype=2;

      if ( users2b.LoadUsers( userfile2b, userthreshold ) ) {
         sprintf(logmsg, "Couldn't open %s\n", userfile2b );
         log(logname,logmsg);
      }
      users2b.sorttype=2;
   }
   if ( curvelist.LoadUsers( curvelistfile, 1 ))  {
      sprintf(logmsg, "Couldn't open %s\n", curvelistfile );
      log(logname, logmsg);
   }
   curvelist.sorttype=2;
   if ( dailywork.LoadUsers( dailyworkfile, 1 )) {
      sprintf(logmsg, "Couldn't open %s\n", dailyworkfile );
      log(logname, logmsg);
   }
   dailywork.sorttype=0;

#ifdef WIN32
   /* miscellaneous windows initializations */
   ///////////////////////////////////////////////////////////////////////////
   WSADATA wsaData;
   WSAStartup(MAKEWORD(1,1), &wsaData);

   /* prevent multiple copies from running... */
   if (!allow2) {
      void * Sem = CreateMutex(NULL, FALSE, "EcmServer");
      if ( !Sem || ERROR_ALREADY_EXISTS == GetLastError() ) {
         fprintf(stderr, "Unable to run multiple copies of this application.\n");
         return (0);
      }
   }
   ///////////////////////////////////////////////////////////////////////////
#endif

   strategy[5] = strategy[0]+strategy[1]+strategy[2]+strategy[3]+strategy[4]; // Sum of strategies.
   if (strategy[5] == 0) {
      strategy[0]=strategy[5]=1; // Random distribution strategy
   }

   sprintf(logmsg, "ECMnet Server application v%d.%d%c started.\n",VERSIONMAJOR, VERSIONMINOR, VERSIONMINOR2);
   log(logname,logmsg);
   log(logname,"Please visit http://www.interlog.com/~tcharron/ecm.html for information.\n");

   s = go_listen(listenport);
   if ( s < 0 ) exit(-1);

   sprintf(logmsg, "Waiting for connections on port %d\n",listenport);
   log(logname,logmsg);

   if (nextupstreamconnect==0) { // non-zero if no INI file was found.
	   nextupstreamconnect = difftime( time( NULL ) , timestart)
			 + 60. * maxfreq * 0.90
			 + 60. * maxfreq * 0.20 * rand() / RAND_MAX;
   }

   sinlen = sizeof(struct sockaddr);
   while ( !exitflag ) {
      getstring(-1); // Purge any old data in the buffer.
      if ( (snew = accept(s, (struct sockaddr *) &Sin, &sinlen)) != INVALID_SOCKET ) {
         retval=process_connection(snew, &Sin, &ecmlist, noremove, &totcurves,
                            &totb1, &totwork, &totfactors, adminpass,
                            &users1, &users2a, &users2b, &curvelist, &dailywork,
                            strategy, recurse, minb1,
                            destid, smtpserver, smtpport, fromid);

         elapseds = (int) difftime( time( NULL ) , timestart);
         timeh = elapseds/3600;
         timem = (elapseds - timeh*3600) / 60;
         times = elapseds - timeh*3600 - timem*60;
         sprintf(logmsg, "El:%3d:%02d:%02d Crvs: %d totwork: %.0lf Fac: %d\n",
                                  timeh, timem, times, totcurves, totwork, totfactors);
         log(logname, logmsg);

         if ((retval != 0) && (enable_factors_up_immediate) && enableupstream) {
            printf("[%s] Server upload forced due to factor returned.\n", Time());
            if (10+difftime(timelast, timestart) < nextupstreamconnect) {
               nextupstreamconnect = max(difftime(time(NULL), timestart), 10+difftime(timelast, timestart));
            }
         }

      } else {
         Sleep(5000);                               // pause a bit
      }
      fflush(stdout);

#if (defined(__WATCOMC__) || defined(__TURBOC__))
      while ( kbhit() )
      {
        int keyboardkey = getch();
        if (keyboardkey == 'X' || keyboardkey == 'x') exitflag=1;
        if ((keyboardkey == 'U' || keyboardkey == 'u') && enableupstream) {
           printf("[%s] 'U' key struck.  Server upload requested.\n", Time());
           if (120+difftime(timelast, timestart) < nextupstreamconnect) {
              nextupstreamconnect = max(difftime(time(NULL), timestart), 120+difftime(timelast, timestart));
           }
        }
      }
#endif
#ifdef UNIX
      if (actionflag > 0){
         if (actionflag == 2) exitflag=1;
         if ((actionflag == 1) && enableupstream) {
            printf("[%s] SIGUSR1 recieved.  Server upload requested.\n", Time());
            if (120+difftime(timelast, timestart) < nextupstreamconnect) {
               nextupstreamconnect = max(difftime(time(NULL), timestart), 120+difftime(timelast, timestart));
            }
         }
         actionflag=0;
         signal(SIGUSR1, gotusr1);
         signal(SIGINT, gotdie);
         signal(SIGTERM, gotdie);
      }
#endif
      if (enableupstream) {
         if (difftime(time(NULL),timestart) > nextupstreamconnect) {

            // Check if any new B1 information or factors to upload...
            uploadreq=0;
            for (i = 0 ; i< ecmlist.get_number_of_numbers(); i++) {
               // Check if any new B1 information to upload...
               for (j=0 ; j< ecmlist.get_number_of_b1details(i+1) ; j++) {
                  if (ecmlist.get_number_b1details_curves_for_upstream(i+1,j) > 0) uploadreq++;
               }
                  // Check for any factors that need upload...
               for (j=0 ; j< ecmlist.get_number_of_factors(i+1) ; j++) {
                  if (ecmlist.get_factor_details_needs_upstream(i+1, j) > 0) uploadreq++;
               }
            }

            if (uploadreq || slavemode) {
               // get/return any results...
               s_upstream = open_server(upstreamserver, upstreamport, email);
               if ( s_upstream == -1 ) {
                  nextupstreamconnect = difftime( time( NULL ) , timestart)
                        + 60. * errtimeout * 0.90
                        + 60. * errtimeout * 0.20 * rand() / RAND_MAX;
                  printf("[%s] Error connecting upstream.  Will retry in %d minutes\n",Time(),
                        (int) (nextupstreamconnect-difftime(time(NULL), timestart))/60);
               } else {
                  errflag = docomms(s_upstream, &ecmlist, noremove, slavemode);
                  if (-1 == errflag ) {
                     nextupstreamconnect = difftime( time( NULL ) , timestart)
                           + 60. * errtimeout * 0.90
                           + 60. * errtimeout * 0.20 * rand() / RAND_MAX;
                     printf("[%s] Upstream connect error.  Will retry in %d minutes\n",Time(),
                           (int) (nextupstreamconnect-difftime(time(NULL), timestart))/60);
                  } else {
                     nextupstreamconnect = difftime( time( NULL ) , timestart)
                           + 60. * maxfreq * 0.90
                           + 60. * maxfreq * 0.20 * rand() / RAND_MAX;
                     printf("[%s] Upstream connection completed.  Next connect in %d minutes\n",Time(),
                           (int) (nextupstreamconnect-difftime(time(NULL), timestart))/60);
                  }
               }
            } else {
               // Not in slave mode, and nothing new to send upstream, so no connection required/occurred.
               nextupstreamconnect = difftime( time( NULL ) , timestart)
                     + 60. * maxfreq * 0.90
                     + 60. * maxfreq * 0.20 * rand() / RAND_MAX;
            }
            ecmlist.WriteDetails_as_required(); // Commit changes
         }// Done talking to upstream server

         printf("[%s] Next upstream connection in %d minutes\r",Time(),
                (int) (nextupstreamconnect-difftime(time(NULL), timestart))/60);
         fflush(stdout);
      } // if (enableupstream)
   } // Main while(1) loop

   delete logmsg;
   closesocket(s);
   log(logname,"Server shutdown complete\n");
   return (0);
}

