// thread.h/thread.cpp
//
// Written by Tim Charron November 12, 1998
// Copyright Tim Charron

#ifndef _THREAD_H_
   #define _THREAD_H_

   #ifdef WIN32
      #include <windef.h>
      #include <winbase.h>
      #include <process.h>
      typedef unsigned long THREADID;
   #endif

   #ifdef UNIX
      #include <pthread.h>
      typedef pthread_t THREADID;
   #endif
   #include "defs.h"

   struct _thread_info {
      int status;           // 0=inactive. 1=starting up.  2=started.  3=finished
      void (*func)(void *);
      void *params;
   };
   typedef struct _thread_info _threadinfo;

   struct _thread_handle {
      THREADID threadid;
      _thread_info threadinfo;
   };
   typedef struct _thread_handle _thread_handle;

   void MakeThread( _thread_handle * thandle,  void (*proc)(void *), void *params);
   void EndThread( _thread_handle * thandle );

#endif

