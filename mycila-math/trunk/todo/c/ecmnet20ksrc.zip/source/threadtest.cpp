// threadtest.cpp
//
// Written by Tim Charron November 12, 1998
// Copyright Tim Charron

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "thread.h"
#include "defs.h"

void counter(void * voidptr) {
   // Parameters are passed via voidptr.
   // This case uses 3 integers.  Alternatively, this could be any
   // number of addresses, each of which could be a different type.
   int * params = (int *) voidptr;
   int i;
   char buffer[1000];
   
   int start    = params[0];
   int end      = params[1];
   int avgdelay = params[2];
   int threadnum= params[3];

   strcpy(buffer, "");
   for ( i=0;i<threadnum;i++) strcat(buffer, "    ");

   for ( i=start ; i<=end ; i++ ) {
      printf("%s%d\n", buffer,i);fflush(stdout);
      Sleep(rand()*avgdelay/32767);              // random delay
   }
}

void main(int argc, char * argv[]) {
   int i, running=0;
   int myparams[4];

   if ( argc==1 ) {
      printf("Usage: 'threadtest n' to spawn n threads\n");
      exit(-1);
   }
   int numthreads=atoi(argv[1]);

   // We need to keep track of the threads.  This is done with the thandles array...
   _thread_handle * * thandles;
   thandles = (_thread_handle * *) calloc( sizeof(_thread_handle *), numthreads );

   for ( i=0;i<numthreads;i++ ) {
      // Store the parameters in an integer array.
      myparams[0] =  1;
      myparams[1] = 10;
      myparams[2] = (i==0?3000:1500);
      myparams[3] = i;
      printf("Starting thread #%d counting from %d to %d (avg delay %d ms).\n",
             i+1, myparams[0], myparams[1], myparams[2]);
      fflush(stdout);
      running++;

      // Call MakeThread to start the thread.  Pass the function and the parameter list.
      // Get the handle to the thread.  We must destroy this when done.
      thandles[i] = new _thread_handle;
      MakeThread( thandles[i], &counter , (void *) (&myparams) );

      Sleep(4000/numthreads);          // All threads started within 4 seconds.
   }

   // Check for any finishing threads...

   while ( running != 0 ) {
      Sleep(1);                                  // 1 millisecond
      for ( i=0 ; i<numthreads ; i++ ) {
         // Check for status==3 (finished)
         if ( thandles[i]->threadinfo.status == 3 ) {
            // Delete it if done.
            EndThread( thandles[i] );
            printf("Thread #%d finished.\n",i+1);
            fflush(stdout);

            // Set the status to 0 (inactive)
            thandles[i]->threadinfo.status=0;
            running--;
         }
      }
   }

   // Clean up the pointers to the threads.
   for ( i=0;i<numthreads;i++ ) free((void *)thandles[i]);
   // Clean up the array that held the pointers.
   free(thandles);
}
