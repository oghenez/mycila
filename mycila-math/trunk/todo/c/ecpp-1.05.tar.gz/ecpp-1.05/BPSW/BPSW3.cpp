#include <stdio.h>
#include <string.h>

#include <iostream.h>

#include <gmpxx.h>
#include <gmp.h>

extern "C" { int     iPrP(mpz_t mpzN, unsigned long ulNMR, unsigned long ulMaxDivisor); }

bool ProbBPSWPrime(mpz_class n);


// added JGW 081127
bool ProbBPSWPrime(mpz_class n) {
	return iPrP(n.get_mpz_t(), 1, 1000);
}

mpz_class nextp(mpz_class n)
/* returns next prime after n */
{
	mpz_t temp;
	mpz_init(temp);
	mpz_nextprime(temp, n.get_mpz_t());
	mpz_class temp_class(temp);
	mpz_clear(temp);
	return temp_class;
}

int main(int argc, char*argv[]) {

    mpz_class N;
	mpz_class ONE = 1;

    long bits = 0;
    if (argc > 1) {
        bits = atoi(argv[1]);
        if (bits < 32)
            bits = 48;

        if (bits==89 || bits==107 || bits==127 || bits==521 || bits==607 || bits==1279 || bits==2203)
            N = (ONE << bits) - 1;
        else
            N = nextp(ONE << bits);
    }

    else cin >> N;
	
	if (ProbBPSWPrime(N))
		cout << "BPSW prime" << "\n";
	else
		cout << "composite\n";
	
	
	return 0;
}
		


