#include <stdio.h>
#include <string.h>

#include <iostream.h>

#include <gmp.h>

#include <NTL/ZZ.h>


extern "C" { int     iPrP(mpz_t mpzN, unsigned long ulNMR, unsigned long ulMaxDivisor); }

bool ProbBPSWPrime(ZZ n);


// added JGW 081117
// changed JGW 081127
bool ProbBPSWPrime(ZZ n) {

cout << "n = " << n << "\n";

	int l = NumBytes(n);
	unsigned char *nstr = new unsigned char[l];
	mpz_t ngmp;
	mpz_init(ngmp);
	
	BytesFromZZ(nstr, n, l);
	
printf("nstr = ");
printf((char *)nstr);
printf("\n");
fflush(stdout);
	
	mpz_set_str(ngmp, (char *)nstr, 10);

printf("ngmp = ");
mpz_out_str (stdout, 10, ngmp);
printf("\n");
fflush(stdout);

	bool isBPSWPrime;
	isBPSWPrime = (bool)iPrP(ngmp, 1, 1000);
	mpz_clear(ngmp);
	return isBPSWPrime;
}


int main(int argc, char*argv[]) {

    ZZ N;

    long bits = 0;
    if (argc > 1) {
        bits = atoi(argv[1]);
        if (bits < 32)
            bits = 48;

        if (bits==89 || bits==107 || bits==127 || bits==521 || bits==607 || bits==1279 || bits==2203)
            N = (to_ZZ(1) << bits) - 1;
        else
            RandomPrime(N, bits);
    }

    else cin >> N;
	
	if (ProbBPSWPrime(N))
		cout << "BPSW prime" << "\n";
	else
		cout << "composite\n";
	
	
	return 0;
}
		


