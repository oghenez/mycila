/*
  Author:  James Wanless (c) 2008

  Cube root extraction - NTL version.
  GPL license.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <iostream.h>
#include <NTL/ZZ.h>


ZZ root3(ZZ in)
{
	ZZ out, factor1, factor2, swapfactor;
	
	factor1 = 1;
	factor2 = in;
	
	do {
		factor1 = (factor1 + factor2) / 2;
		factor2 = (in / factor1) / factor1;
		
		if (factor1 > factor2) {
			swapfactor = factor1;
			factor1 = factor2;
			factor2 = swapfactor;
		}
	} while (factor2 - factor1 > 1);
	
	out = factor1;
	
	return out;
}

int main(void)
{
	ZZ n, Root3, diff;

	while (true) {
		cin >> n;
		Root3 = root3(n);
		diff = n - Root3*Root3*Root3;
		cout << "n=" << n << " Root3=" << Root3 << " diff=" << diff << "\n";
	}
	
	return 0;
}
		
