#include <stdio.h>
#include "gmp.h"

int
main ()
{
  printf ("gmp version: %s\n", gmp_version);
  return 0;
}
